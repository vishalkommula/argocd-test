﻿using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.Banking.IAdapter.Infrastructure.Services;
using JackHenry.Banking.IAdapter.Tests.Constants;
using JackHenry.Enterprise.BusinessObjects.Jes;
using Microsoft.Extensions.Logging;

using Moq;

using System.Linq;
using System.Threading.Tasks;

using Xunit;

namespace JackHenry.Banking.IAdapter.Tests.UnitTests;

public class TransportServiceUnitTests
{
    private Mock<ILogger<TransportService>> logger = new();

    [Fact]
    [Trait(TestContants.TestCategory, TestContants.UnitTest)]
    public async Task Can_Create()
    {
        var adapter = new MasterAdapterSetting
        {
            IAdapterInstitutionId = "2022510",
            Key = "66ce7003ffae1a4293d60004ac1c6f9b",
            Port = 42510,
            Server = "iCoreDev",
            EncryptedKey = "48L8FM1fYnTSfViR9XAPfviKHNiTr04EuZII6bauBA20qSF8ijJSFRSuzEAMnHxw",
            ServicePrincipalName = "iCoreDev.dev.jha"
        };

        var transportService = new TransportService(logger.Object, adapter);

        Assert.Equal(1, transportService.Count()!);

        var transport = transportService[adapter.IAdapterInstitutionId];

        Assert.NotNull(transport);
    }

    [Fact]
    [Trait(TestContants.TestCategory, TestContants.UnitTest)]
    public async Task Throws_exception_on_missing_transport()
    {
        var adapter = new MasterAdapterSetting
        {
            IAdapterInstitutionId = "2022510",
            Key = "66ce7003ffae1a4293d60004ac1c6f9b",
            Port = 42510,
            Server = "iCoreDev",
            EncryptedKey = "48L8FM1fYnTSfViR9XAPfviKHNiTr04EuZII6bauBA20qSF8ijJSFRSuzEAMnHxw",
            ServicePrincipalName = "iCoreDev.dev.jha"
        };

        var transportService = new TransportService(logger.Object, adapter);

        var result = transportService.SendXML<PingRs_MType>(string.Empty, string.Empty, string.Empty) as GenericResponseImpl<PingRs_MType>;

        Assert.Equal("Error processing Transport Request and response for JackHenry.Enterprise.BusinessObjects.Jes.PingRs_MType type.", result?.Exception.Message);
    }
}
