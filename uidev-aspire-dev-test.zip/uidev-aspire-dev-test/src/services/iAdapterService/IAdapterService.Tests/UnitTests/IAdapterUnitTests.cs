using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.Banking.IAdapter.Infrastructure.Services;
using JackHenry.Banking.IAdapter.Tests.Constants;
using JackHenry.Banking.IAdapter.Tests.TestCases;
using JackHenry.Banking.IAdapter.Tests.Utilities;
using JackHenry.JHAContractTypes;

using Moq;

using System;
using System.Threading.Tasks;

using Xunit;

namespace JackHenry.Banking.IAdapter.Tests.UnitTests;

[Trait(TestContants.TestCategory, TestContants.UnitTest)]
public class IAdapterUnitTests
{
    public IAdapterUnitTests()
    {
        Adapter = new Mock<IMasterAdapterSetting>();
        TransportService = new Mock<ITransportService>();
    }

    public Mock<IMasterAdapterSetting> Adapter { get; }

    public Mock<ITransportService> TransportService { get; }

    public IIAdapterService IAdapterService { get; set; }

    [Fact]    
    public async Task Can_Call_Ping_Async()
    {
        ResetMocks();

        var ping = new PingRq_MType()
        {
            PingRq = SampleiAdapter.ServicePrincipalName
        };

        var requestXml = JhaSerializer.Serialize(ping);
        var expectedResponse = new GenericResponseImpl<PingRs_MType>();

        var setup = TransportService.Setup(x => x.SendXML<PingRs_MType>(
            It.Is<string>(v => v.Equals(requestXml)), 
            It.Is<string>(v => v.Equals(IAdapterTrafficLiterals.MSGSEARCH)), 
            It.Is<string>(v => v == null)))
            .Returns(expectedResponse);

        IAdapterService = new IAdapterService(Adapter.Object, TransportService.Object);

        var actualResponse = await IAdapterService
            .PingAsync<PingRs_MType>(requestXml, SampleiAdapter.IAdapterInstitutionId);

        Assert.Equal(expectedResponse, actualResponse);
    }

    [Fact]
    public async Task Can_Do_Acct_Search_Async()
    {
        ResetMocks();

        var requestXml = TestUtils.LoadSampleRequest("AcctSrch.xml");
        var expectedResponse = new GenericResponseImpl<AcctSrchRs_MType>();

        var setup = TransportService.Setup(x => x.SendXML<AcctSrchRs_MType>(
            It.Is<string>(v => v.Equals(requestXml)),
            It.Is<string>(v => v.Equals(IAdapterTrafficLiterals.SEARCH)),
            It.Is<string>(v => v.Equals(SampleiAdapter.IAdapterInstitutionId))))
            .Returns(expectedResponse);

        IAdapterService = new IAdapterService(Adapter.Object, TransportService.Object);

        var actualResponse = await IAdapterService
            .SearchAsync<AcctSrchRs_MType>(requestXml, SampleiAdapter.IAdapterInstitutionId);

        Assert.Equal(expectedResponse, actualResponse);
    }

    [Fact]
    public async Task Can_Do_Acct_Inquiry_Async()
    {
        ResetMocks();

        IAdapterService = new IAdapterService(Adapter.Object, TransportService.Object);

        var requestXml = TestUtils.LoadSampleRequest("AcctInq.xml");
        var expectedResponse = new GenericResponseImpl<AcctInqRs_MType>();

        var setup = TransportService.Setup(x => x.SendXML<AcctInqRs_MType>(
            It.Is<string>(v => v.Equals(requestXml)),
            It.Is<string>(v => v.Equals(IAdapterTrafficLiterals.INQUIRY)),
            It.Is<string>(v => v.Equals(SampleiAdapter.IAdapterInstitutionId))))
            .Returns(expectedResponse);

        IAdapterService = new IAdapterService(Adapter.Object, TransportService.Object);

        var actualResponse = await IAdapterService
            .InquireAsync<AcctInqRs_MType>(requestXml, SampleiAdapter.IAdapterInstitutionId);

        Assert.Equal(expectedResponse, actualResponse);
    }

    [Fact]
    public async Task If_Inquiry_Throws_Exception()
    {
        ResetMocks();

        IAdapterService = new IAdapterService(Adapter.Object, TransportService.Object);

        var setup = TransportService.Setup(x => x.SendXML<AcctInqRs_MType>(
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<string>())).Throws<Exception>(() => new Exception(Guid.NewGuid().ToString()));

        var actualResponse = await IAdapterService
            .InquireAsync<AcctInqRs_MType>(String.Empty, SampleiAdapter.IAdapterInstitutionId);

        Assert.IsType<GenericResponseImpl<AcctInqRs_MType>>(actualResponse);

        var genEx = actualResponse as GenericResponseImpl<AcctInqRs_MType>;

        Assert.IsType<GenericException>(genEx!.Exception);
    }

    [Fact]
    public async Task If_Search_Throws_Exception()
    {
        ResetMocks();

        IAdapterService = new IAdapterService(Adapter.Object, TransportService.Object);

        var setup = TransportService.Setup(x => x.SendXML<AcctSrchRs_MType>(
            It.IsAny<string>(),
            It.IsAny<string>(),
            It.IsAny<string>())).Throws<Exception>(() => new Exception(Guid.NewGuid().ToString()));

        var actualResponse = await IAdapterService
            .InquireAsync<AcctSrchRs_MType>(String.Empty, SampleiAdapter.IAdapterInstitutionId);

        Assert.IsType<GenericResponseImpl<AcctSrchRs_MType>>(actualResponse);

        var genEx = actualResponse as GenericResponseImpl<AcctSrchRs_MType>;

        Assert.IsType<GenericException>(genEx!.Exception);
    }

    private void ResetMocks()
    {
        Adapter.Reset();
        Adapter.SetupGet(x => x.IsSSL).Returns(SampleiAdapter.IsSSL);
        Adapter.SetupGet(x => x.IAdapterInstitutionId).Returns(SampleiAdapter.IAdapterInstitutionId);
        Adapter.SetupGet(x => x.Key).Returns(SampleiAdapter.Key);
        Adapter.SetupGet(x => x.Port).Returns(SampleiAdapter.Port);
        Adapter.SetupGet(x => x.Server).Returns(SampleiAdapter.Server);
        Adapter.SetupGet(x => x.EncryptedKey).Returns(SampleiAdapter.EncryptedKey);
        Adapter.SetupGet(x => x.ServicePrincipalName).Returns(SampleiAdapter.ServicePrincipalName);
        Adapter.SetupGet(x => x.HeaderVersion).Returns(SampleiAdapter.HeaderVersion);

        TransportService.Reset();
    }
}
