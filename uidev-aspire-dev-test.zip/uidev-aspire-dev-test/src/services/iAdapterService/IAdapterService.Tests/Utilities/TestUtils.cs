﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace JackHenry.Banking.IAdapter.Tests.Utilities;

public class TestUtils
{
    public static string LoadSampleRequest(string fileName)
    {
        var assembly = Assembly.GetExecutingAssembly();
        var filePath = $"{assembly.GetName().Name}.SampleRequest.{fileName}";
        var stream = assembly.GetManifestResourceStream(filePath);

        using var reader = new StreamReader(stream);
        var result = reader.ReadToEnd();
        reader.Close();
        return result;
    }
}
