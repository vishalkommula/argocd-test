﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JackHenry.Banking.IAdapter.Tests.TestCases;

public class SampleiAdapter
{
    public const bool IsSSL = false;
    public const string IAdapterInstitutionId = "2022510";
    public const string Key = "66ce7003ffae1a4293d60004ac1c6f9b";
    public const int Port = 42510;
    public const string Server = "iCoreDev";
    public const string EncryptedKey = "48L8FM1fYnTSfViR9XAPfviKHNiTr04EuZII6bauBA20qSF8ijJSFRSuzEAMnHxw";
    public const string ServicePrincipalName = "iCoreDev.dev.jha";
    public const string HeaderVersion = "2008.1";
}
