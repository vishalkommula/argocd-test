﻿// -----------------------------------------------------------------------
// <copyright file="ExtensionMethods.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright ? 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Extensions;

using JackHenry.JHAContractTypes;

using System.Collections;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;

public static class ExtensionMethods
{
    public static bool IsNullOrEmpty<T>(this IEnumerable<T> l)
    {
        return l == null || !l.Any();
    }

    public static bool IsNotNullOrEmpty(this string s)
    {
        return !string.IsNullOrEmpty(s);
    }

    public static SecureString ToSecureString(this string source)
    {
        if (string.IsNullOrWhiteSpace(source))
        {
            return null;
        }
        else
        {
            SecureString result = new SecureString();
            foreach (char c in source.ToCharArray())
            {
                result.AppendChar(c);
            }

            return result;
        }
    }

    public static bool IsCaseInsensativeEqual(this string s, string value)
    {
        return string.Compare(s, value, true) == 0;
    }

    public static string GetDecryptedValue(this SecureString source)
    {
        string result = null;
        int length = source.Length;
        IntPtr pointer = IntPtr.Zero;
        char[] chars = new char[length];

        try
        {
            pointer = Marshal.SecureStringToBSTR(source);
            Marshal.Copy(pointer, chars, 0, length);

            result = string.Join(string.Empty, chars);
        }
        finally
        {
            if (pointer != IntPtr.Zero)
            {
                Marshal.ZeroFreeBSTR(pointer);
            }
        }

        return result;
    }

    public static void DisposeCollection(this IList collection, bool disposeCollectionViewSource = false)
    {
        if (collection == null)
        {
            return;
        }

        try
        {
            if (collection is IDisposable)
            {
                (collection as IDisposable).Dispose();
            }
            else
            {
                foreach (object item in collection)
                {
                    if (item is IDisposable)
                    {
                        (item as IDisposable).Dispose();
                    }
                }
            }

            if (collection.Count > 0)
            {
                collection.Clear();
            }

            collection = null;
        }
        catch
        {
        }
    }

    public static string MessagesToString(this IEnumerable<IResultInfoMessage> messages)
    {
        if (messages == null || !messages.Any())
        {
            return string.Empty;
        }

        StringBuilder message = new StringBuilder();

        foreach (IResultInfoMessage result in messages)
        {
            var searchRegex = new Regex(Regex.Escape(result.ErrDesc));

            if (!searchRegex.IsMatch(message.ToString()))
            {
                message.AppendLine(result.ErrDesc);
            }
        }

        return message.ToString();
    }

    public static bool IsDateUnset(this DateTime dateToCheck)
    {
        return dateToCheck.Year == DateTime.MinValue.Year;
    }

    public static bool IsDateSet(this DateTime dateToCheck)
    {
        return !dateToCheck.IsDateUnset();
    }

    public static bool IsDateUnset(this DateTimeOffset dateToCheck)
    {
        return dateToCheck.Year == DateTimeOffset.MinValue.Year;
    }

    public static bool IsDateSet(this DateTimeOffset dateToCheck)
    {
        return !dateToCheck.IsDateUnset();
    }

    public static DateTimeOffset ToDateTimeOffset(this DateTime dateToConvert)
    {
        return new DateTimeOffset(dateToConvert, TimeZoneInfo.Local.GetUtcOffset(dateToConvert));
    }
}
