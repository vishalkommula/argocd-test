﻿// -----------------------------------------------------------------------
// <copyright file="StaticEnums.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright ? 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace JackHenry.Banking.IAdapter.Infrastructure.Enums;

public class StaticEnums
{
    public enum LogType
    {
        Error,
        Warning,
        Audit,
        Security,
        Trace
    }
}
