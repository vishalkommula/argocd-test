﻿// -----------------------------------------------------------------------
// <copyright file="ServiceProvider.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;

public class ServiceProvider
{
    public const string Generic = "Service Provider";
    public const string Jxchange = "jXchange";
    public const string IAdapter = "iAdapter";
    public const string BusinessServices = "Business Services";
}
