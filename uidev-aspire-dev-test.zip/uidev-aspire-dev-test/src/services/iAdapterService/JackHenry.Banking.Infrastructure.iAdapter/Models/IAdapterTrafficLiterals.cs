﻿// -----------------------------------------------------------------------
// <copyright file="IAdapterTrafficLiterals.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace JackHenry.Banking.IAdapter.Infrastructure.Models;

public static class IAdapterTrafficLiterals
{
    public const string SEARCH = "Search";

    public const string MSGSEARCH = "Message Search";

    public const string ADDMOD = "Add/Mod";

    public const string INQUIRY = "Inquiry";

    public const string MSGINQUIRY = "Message Inquiry";

    public const string MessageBus = "Message Bus";
}
