// -----------------------------------------------------------------------
// <copyright file="ResultMessage.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;
using Jes = JackHenry.Enterprise.BusinessObjects.Jes;
using SL = JHAContractTypes;
using Tpg = JackHenry.Enterprise.BusinessObjects.Tpg;

public class ResultMessage : SL.IResultInfoMessage
{
    public ResultMessage(Tpg.MsgRec_CType message)
    {
        this.ErrCat = message.ErrCat;
        this.ErrCode = message.ErrCode;
        this.ErrDesc = message.ErrDesc;
        this.ErrElem = message.ErrElem;
        this.ErrElemVal = message.ErrElemVal;
        this.ErrLoc = message.ErrLoc;
    }

    public ResultMessage(Jes.MsgRec_CType message)
    {
        this.ErrCat = message.ErrCat;
        this.ErrCode = message.ErrCode;
        this.ErrDesc = message.ErrDesc;
        this.ErrElem = message.ErrElem;
        this.ErrElemVal = message.ErrElemVal;
        this.ErrLoc = message.ErrLoc;
    }

    public ResultMessage(SL.MsgRec_CType message)
    {
        this.ErrCat = message.ErrCat;
        this.ErrCode = message.ErrCode;
        this.ErrDesc = message.ErrDesc;
        this.ErrElem = message.ErrElem;
        this.ErrElemVal = message.ErrElemVal;
        this.ErrLoc = message.ErrLoc;
    }

    public ResultMessage(Tpg.FaultMsgRec_CType message)
    {
        this.ErrCat = message.ErrCat;
        this.ErrCode = message.ErrCode;
        this.ErrDesc = message.ErrDesc;
        this.ErrElem = message.ErrElem;
        this.ErrElemVal = message.ErrElemVal;
        this.ErrLoc = message.ErrLoc;
    }

    public ResultMessage(Jes.FaultMsgRec_CType message)
    {
        this.ErrCat = message.ErrCat;
        this.ErrCode = message.ErrCode;
        this.ErrDesc = message.ErrDesc;
        this.ErrElem = message.ErrElem;
        this.ErrElemVal = message.ErrElemVal;
        this.ErrLoc = message.ErrLoc;
    }

    public ResultMessage(SL.FaultMsgRec_CType message)
    {
        this.ErrCat = message.ErrCat;
        this.ErrCode = message.ErrCode;
        this.ErrDesc = message.ErrDesc;
        this.ErrElem = message.ErrElem;
        this.ErrElemVal = message.ErrElemVal;
        this.ErrLoc = message.ErrLoc;
    }

    public string ErrCat
    {
        get;
        private set;
    }

    public string ErrCode
    {
        get;
        private set;
    }

    public string ErrDesc
    {
        get;
        private set;
    }

    public string ErrElem
    {
        get;
        private set;
    }

    public string ErrElemVal
    {
        get;
        private set;
    }

    public string ErrLoc
    {
        get;
        private set;
    }
}
