// -----------------------------------------------------------------------
// <copyright file="MasterAdapterSetting.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2013 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;
using System;
using System.Xml.Serialization;

using JackHenry.Banking.IAdapter.Infrastructure.Extensions;
using JackHenry.Enterprise.Security;
using JackHenry.JHAContractTypes;

/// <summary>
/// MasterAdapterSetting Class
/// </summary>
public class MasterAdapterSetting : IMasterAdapterSetting
{
    private readonly string magicStringThatCannotBeChanged = "efb4c95e-50b4-46ec-89ff-3818817d1165";
    private string key;

    /// <summary>
    /// Gets the display name.
    /// </summary>
    /// <value>
    /// The display name.
    /// </value>
    [XmlIgnore]
    public string DisplayName
    {
        get
        {
            return string.Format("{0}, Port {1}", this.Server, this.Port);
        }
    }

    /// <summary>
    /// Gets the header version.
    /// </summary>
    [XmlIgnore]
    public string HeaderVersion
    {
        get
        {
            return "2008.1";
        }
    }

    /// <summary>
    /// Gets or sets the iAdapter institution id.
    /// </summary>
    public string IAdapterInstitutionId
    {
        get;
        set;
    }

    public string TLSDateTimeString
    {
        get;
        set;
    }

    [XmlIgnore]
    public DateTime TLSDateTime
    {
        get
        {
            if (DateTimeOffset.TryParse(this.TLSDateTimeString, out DateTimeOffset dateTimeOffset))
            {
                return dateTimeOffset.LocalDateTime;
            }

            return DateTime.MinValue;
        }
    }

    /// <summary>
    /// Gets or sets a value indicating whether this instance is SSL.
    /// </summary>
    /// <value>
    ///   <c>true</c> if this instance is SSL; otherwise, <c>false</c>.
    /// </value>
    [XmlIgnore]
    public bool IsSSL
    {
        get
        {
            if (this.TLSDateTime.IsDateUnset())
            {
                return this.IsSSLSerialized;
            }

            return DateTime.UtcNow >= this.TLSDateTime.ToDateTimeOffset().UtcDateTime;
        }
    }

    [XmlElement(nameof(IsSSL))]
    public bool IsSSLSerialized { get; set; }

    [XmlIgnore]
    public bool IsNonSSL
    {
        get => !this.IsSSL;
    }

    /// <summary>
    /// Gets or sets the key.
    /// </summary>
    [XmlIgnore]
    public string Key { get; set; }

    /// <summary>
    /// Gets or sets the encrypted key.
    /// </summary>
    /// <value>
    /// The encrypted key.
    /// </value>
    public string EncryptedKey
    {
        get
        {
            if (this.key != null)
            {
                return EncryptionHelper.EncryptString(this.key, this.magicStringThatCannotBeChanged);
            }
            else
            {
                return null;
            }
        }

        set
        {
            string val = null;

            if (value != null)
            {
                val = EncryptionHelper.DecryptString(value, this.magicStringThatCannotBeChanged);
            }

            this.Key = val;
        }
    }

    /// <summary>
    /// Gets or sets the port.
    /// </summary>
    public int Port
    {
        get;
        set;
    }

    /// <summary>
    /// Gets or sets the server.
    /// </summary>
    public string Server
    {
        get;
        set;
    }

    /// <summary>
    /// Gets or sets the name of the service principal.
    /// </summary>
    /// <value>
    /// The name of the service principal.
    /// </value>
    public string ServicePrincipalName
    {
        get;
        set;
    }

    public string SocketHeaderVersion { get; set; }
}
