// -----------------------------------------------------------------------
// <copyright file="SerializedException.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;
using System;

[Serializable]
public class SerializedException
{
    public SerializedException()
    {
        this.ExceptionTime = DateTime.Now;
    }

    public SerializedException(Exception ex)
        : this()
    {
        this.SafeExceptionInformation = ex.Message;
        this.Stack = ex.StackTrace;
        this.Source = ex.Source;
        this.InnerException = ex.InnerException != null ? ex.InnerException.ToString() : null;
    }

    public DateTime ExceptionTime
    {
        get;
        set;
    }

    public string ExceptionType
    {
        get;
        set;
    }

    public string ExtraInformation
    {
        get;
        set;
    }

    public string InnerException
    {
        get;
        set;
    }

    public string SafeExceptionInformation
    {
        get;
        set;
    }

    public string Source
    {
        get;
        set;
    }

    public string Stack
    {
        get;
        set;
    }

    public override string ToString()
    {
        return string.Format("Date/Time: {0} Message: {1} Stack: {1} Source: {2} InnerException: {3}", this.ExceptionTime.ToLongDateString(), this.SafeExceptionInformation, this.Stack, this.Source, this.InnerException);
    }
}
