// ----------------------------------------------------------------------
// <copyright file="iAdapterTransport.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// ----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.Banking.IAdapter.Infrastructure.Extensions;
using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
using JackHenry.JHAContractTypes;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Text;

public class IAdapterTransport
{
    private static readonly object Locker = new object();

    private IPEndPoint endPoint;
    private ITrustedCertificateSettings certificateSettings;

    public IAdapterTransport(IIAdapter iadapter)
    {
        if (iadapter != null)
        {
            this.ReInitializeIAdapter(iadapter);
        }
    }

    public int ServerPort { get; set; }

    protected string Command { get; set; }

    protected string InstitutionId { get; set; }

    protected bool IsSslMode { get; set; }

    protected string SecurityKey { get; set; }

    protected string ServerName { get; set; }

    protected string SocketHeaderVersion { get; set; }

    public object LockCache { get; private set; }

    public void ReInitializeIAdapter(IIAdapter iadapter)
    {
        try
        {
            lock (Locker)
            {
                this.Command = string.Empty;
                this.ServerName = iadapter.Server;
                this.ServerPort = iadapter.Port;
                this.SecurityKey = iadapter.Key ?? string.Empty;
                this.InstitutionId = iadapter.IAdapterInstitutionId;
                this.SocketHeaderVersion = iadapter.HeaderVersion;
                this.IsSslMode = iadapter.IsSSL;
                this.SetupEndPoint();
            }
        }
        catch (Exception ex)
        {
            throw new Exception(string.Format("Error in ReInitializeIAdapter: {0}", ex.Message), ex);
        }
    }

    public string SendRequest(string request)
    {
        StringBuilder messageSizeResponse = new StringBuilder(string.Empty);
        StringBuilder requestBuilder;

        TcpClient tcpClient = null;
        SslStream sslStream = null;
        BinaryWriter writer = null;
        BinaryReader reader = null;
        string responseData = string.Empty;

        try
        {
            requestBuilder = this.BuildRequestString(request);

            int versionLength = 0;
            int fieldLength = 0;
            if (this.SocketHeaderVersion == "2008.1")
            {
                versionLength = 6;
                fieldLength = 9;
            }

            for (int i = 0; i < 3; i++)
            {
                try
                {
                    tcpClient = this.CreateClient();
                    break;
                }
                catch (SocketException)
                {
                    tcpClient?.Close();
                }
            }

            using (NetworkStream stream = tcpClient.GetStream())
            {
                this.InternalGetSslStream(stream, ref sslStream);

                writer = new BinaryWriter(sslStream == null ? stream : sslStream, Encoding.UTF8);
                reader = new BinaryReader(sslStream == null ? stream : sslStream, Encoding.UTF8);

                writer.Write(Encoding.UTF8.GetBytes(requestBuilder.ToString()));

                int headerLengthToRead = versionLength + fieldLength;
                byte[] receiveBuffer = new byte[headerLengthToRead];

                int bytesReceived = reader.Read(receiveBuffer, 0, headerLengthToRead);

                int numberOfBytesReceived = bytesReceived;

                messageSizeResponse.Append(Encoding.UTF8.GetString(receiveBuffer, 0, bytesReceived));

                int bytesLeftToReceive;
                while (numberOfBytesReceived < headerLengthToRead && stream.DataAvailable)
                {
                    bytesLeftToReceive = headerLengthToRead - numberOfBytesReceived;

                    bytesReceived = reader.Read(receiveBuffer, 0, bytesLeftToReceive);

                    if (bytesReceived > 0)
                    {
                        messageSizeResponse.Append(Encoding.UTF8.GetString(receiveBuffer, 0, bytesReceived));

                        numberOfBytesReceived += bytesReceived;
                    }
                }

                int messageLength = Convert.ToInt32(messageSizeResponse.ToString().Substring(versionLength)) - headerLengthToRead;

                receiveBuffer = new byte[messageLength];

                bytesReceived = reader.Read(receiveBuffer, 0, messageLength);

                numberOfBytesReceived = bytesReceived;

                // create a memory stream to store all received bytes.
                using (MemoryStream responseStream = new(messageLength))
                {
                    responseStream.Write(receiveBuffer, 0, bytesReceived);

                    while (numberOfBytesReceived < messageLength)
                    {
                        bytesLeftToReceive = messageLength - numberOfBytesReceived;

                        bytesReceived = reader.Read(receiveBuffer, 0, bytesLeftToReceive);

                        if (bytesReceived > 0)
                        {
                            responseStream.Write(receiveBuffer, 0, bytesReceived);
                            numberOfBytesReceived = numberOfBytesReceived + bytesReceived;
                        }
                    }

                    byte[] data = TrimMessageHeader(responseStream);

                    if (data != null && data.Length > 1 && IsCompressed(data[0], data[1]))
                    {
                        responseData = CompressionHelper.ZlibDecompress(data).TrimEnd();
                    }
                    else
                    {
                        responseData = Encoding.UTF8.GetString(data).TrimEnd();
                    }
                }

                CloseClient(stream, tcpClient);
            }

            return responseData;
        }
        catch (SocketException se)
        {
            throw new IAdapterCommunicationException("Unable to communicate with IAdapter.", new Exception("A socket communication problem occurred : Error Code - " + Enum.GetName(typeof(SocketError), se.ErrorCode), se));
        }
        catch (AuthenticationException aex)
        {
            throw aex;
        }
        catch (Exception e)
        {
            throw new IAdapterCommunicationException("Unable to communicate with IAdapter.", new Exception("A communication problem occurred : " + e.Message, e));
        }
        finally
        {
            writer?.Close();
            reader?.Close();
            sslStream?.Close();
            tcpClient?.Close();
        }
    }

    protected void SetupEndPoint()
    {
        string debugServerName = string.Empty;
        int debugServerPort = -1;

        string useServerName = (debugServerName != string.Empty) ? debugServerName : this.ServerName;
        int useServerPort = (debugServerPort != -1) ? debugServerPort : this.ServerPort;

        try
        {
            IPAddress ipaddress;

            string[] machinePieces = useServerName.Split(new char[] { '@' });
            useServerName = machinePieces[0];
            IPHostEntry hostEntry = null;

            // going to make this backwards compatible with the previous solution as
            // well incase there is some type of unforseen crazy.
            try
            {
                hostEntry = Dns.GetHostEntry(useServerName);
            }
            catch
            {
                machinePieces = useServerName.Split(new char[] { '.', '@' });
                useServerName = machinePieces[0];
                hostEntry = Dns.GetHostEntry(useServerName);
            }

            IPAddress[] ipaddresses = hostEntry.AddressList;

            if (ipaddresses.Length >= 1)
            {
                ipaddress = ipaddresses[0];

                if (ipaddress.AddressFamily == AddressFamily.InterNetworkV6)
                {
                    if (!Socket.OSSupportsIPv6)
                    {
                        IEnumerable<IPAddress> ips = from ip in ipaddresses
                                                     where ip.AddressFamily != AddressFamily.InterNetworkV6
                                                     select ip;
                        ipaddress = ips.ElementAt(0);
                    }
                }
            }
            else
            {
                throw new Exception("The IP address was unable to be resolved");
            }

            this.endPoint = new IPEndPoint(ipaddress, useServerPort);
        }
        catch (ArgumentNullException ane)
        {
            throw new Exception("A configuration error has occurred in the socket transport", ane);
        }
        catch (SocketException se)
        {
            if (se.ErrorCode == 11001)
            {
                throw new Exception(string.Format("Unable to establish a valid connection to the host '{0}'", useServerName));
            }
            else
            {
                throw new Exception("A socket endpoint was unable to be created", se);
            }
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected StringBuilder BuildRequestString(string xmlRequest)
    {
        StringBuilder requestString = new();
        requestString.Append(this.SocketHeaderVersion.PadRight(6));

        // add the length of the message
        byte[] byteArray = Encoding.UTF8.GetBytes(xmlRequest);
        requestString.Append((byteArray.Length + 66).ToString().PadRight(9));

        requestString.Append(this.SecurityKey.PadRight(32));

        requestString.Append(this.InstitutionId.PadRight(9));

        requestString.Append(this.Command.PadRight(10));

        requestString.Append(xmlRequest);

        return requestString;
    }

    private bool CertificateValidationCallback(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
    {
        try
        {
            bool trust = false;
            bool chainValidated = false;
            bool certificatePinned = false;

            ITrustedCertificateSettings trustedCertificateSettings = this.LoadTrustedCertificateSettings();

            if (trustedCertificateSettings.TLSSecurityStrength == TLSSecurityOptions.CertificateChain ||
                trustedCertificateSettings.TLSSecurityStrength == TLSSecurityOptions.CertifiateChainandTrustedCertificate)
            {
                // Check all properties
                chain.ChainPolicy.VerificationFlags = X509VerificationFlags.NoFlag;

                chain.ChainPolicy.RevocationMode = X509RevocationMode.Online;
                chain.ChainPolicy.RevocationFlag = X509RevocationFlag.EntireChain;

                // Build the chain
                chain.Build(new X509Certificate2(certificate));

                // Are there any failures from building the chain?
                if (chain.ChainStatus.Length == 0)
                {
                    chainValidated = true;
                }
                else
                {
                    // If there is a status, verify the status is NoError
                    if (chain.ChainStatus[0].Status == X509ChainStatusFlags.NoError)
                    {
                        chainValidated = true;
                    }
                    else
                    {
                        StringBuilder statArray = new();
                        foreach (X509ChainStatus stat in chain.ChainStatus)
                        {
                            statArray.AppendFormat(stat.Status.ToString() + " --> " + stat.StatusInformation, Environment.NewLine);
                        }

                        throw new AuthenticationException(string.Format("iAdapter - SSL Certificate Validation Error: {0}", sslPolicyErrors + Environment.NewLine + statArray.ToString()));
                    }
                }
            }

            if (trustedCertificateSettings.TLSSecurityStrength == TLSSecurityOptions.TrustedCertificate ||
                trustedCertificateSettings.TLSSecurityStrength == TLSSecurityOptions.CertifiateChainandTrustedCertificate)
            {
                // Verify against known public key within the certificate
                TrustedCertificateModel cert = new(new X509Certificate2(certificate));

                if (trustedCertificateSettings.TrustedCerts.Any(c => c.PublicKey.GetDecryptedValue() == cert.PublicKey.GetDecryptedValue()))
                {
                    certificatePinned = true;
                }
                else
                {
                    throw new AuthenticationException(string.Format("iAdapter - SSL Certificate Validation Error: The certificate does not match a Pinned Certificate from System Maintenance."));
                }
            }

            switch (trustedCertificateSettings.TLSSecurityStrength)
            {
                case TLSSecurityOptions.None:
                    trust = true;
                    break;

                case TLSSecurityOptions.CertificateChain:
                    trust = chainValidated;
                    break;

                case TLSSecurityOptions.TrustedCertificate:
                    trust = certificatePinned;
                    break;

                case TLSSecurityOptions.CertifiateChainandTrustedCertificate:
                    trust = chainValidated && certificatePinned;
                    break;
            }

            return trust;
        }
        catch (AuthenticationException aex)
        {
            throw new AuthenticationException($"{aex.Message} Certificate Common Name: {new X509Certificate2(certificate).GetNameInfo(X509NameType.SimpleName, false)}");
        }
    }

    private ITrustedCertificateSettings LoadTrustedCertificateSettings(string serverPort = null, Action<string, bool> logging = null)
    {
        string xmlSettings = string.Empty;
        try
        {
            ITrustedCertificateSettings trustedCertificateSettings = null;

            bool log = logging == null ? false : true;

            if (log)
            {
                logging("Enter LoadTrustedCertificateSettings. Sending Read Req to Xp.", false);
            }

            if (log)
            {
                logging("Retrieving trusted certificate setting.", false);
            }

            string applicationName = "SilverLake";
            string productName = "SilverLake";

            ////IResponse<PSInqRs_MType> userResponse = new IInquiryResponse<PSInqRs_MType>(); ////xperienceHelper.GetCertificateSetting(SLPersistentStorageKeys.TrustedCertificateKey, null, applicationName, serverPort, productName);

            ////if (userResponse != null && userResponse.HasException)
            ////{
            ////    if (log)
            ////    {
            ////        logging(string.Format("An exception occurred while retrieving trusted certificate settings: {0} ", userResponse.Exception.Message), true);
            ////    }
            ////}
            ////else if (userResponse != null && userResponse.Payload_Rs != null &&
            ////    userResponse.Payload_Rs.PSPkg != null && userResponse.Payload_Rs.PSPkg.PSContent != null &&
            ////    userResponse.Payload_Rs.PSPkg.PSContent.PSContents != null)
            ////{
            ////    if (log)
            ////    {
            ////        logging("Deserializing retrieved trusted certificate setting.", false);
            ////    }

            ////    trustedCertificateSettings = JhaSerializer.XmlDeserialize<TrustedCertificateSettings>(userResponse.Payload_Rs.PSPkg.PSContent.PSContents);

            ////    foreach (TrustedCertificateModel cert in trustedCertificateSettings.TrustedCerts)
            ////    {
            ////        cert.PublicKey = cert.SerializablePublicKey.ToSecureString();
            ////        cert.SerializablePublicKey = null;
            ////    }

            ////    if (log)
            ////    {
            ////        logging("trusted certificate setting deserialized.", false);
            ////    }
            ////}

            if (trustedCertificateSettings == null)
            {
                trustedCertificateSettings = new TrustedCertificateSettings
                {
                    TLSSecurityStrength = TLSSecurityOptions.None
                };

                foreach (TrustedCertificateModel cert in trustedCertificateSettings.TrustedCerts)
                {
                    cert.PublicKey = cert.SerializablePublicKey.ToSecureString();
                    cert.SerializablePublicKey = null;
                }
            }

            return trustedCertificateSettings;
        }
        catch (Exception ex)
        {
            throw new Exception(string.Format("Error in LoadTrustedCertificateSettings: {0} Settings Xml: {1}", ex.Message, xmlSettings), ex);
        }
    }

    private TcpClient CreateClient()
    {
        TcpClient tcpClient;
        try
        {
            tcpClient = new TcpClient(this.endPoint.AddressFamily)
            {
                ReceiveTimeout = 120000,
                SendTimeout = 120000
            };

            tcpClient.LingerState.Enabled = false;
            tcpClient.Connect(this.endPoint);
        }
        catch (ArgumentNullException ane)
        {
            throw new /*ConfigurationErrorsException*/Exception("A configuration error has occurred in the socket transport.", ane);
        }
        catch (SocketException se)
        {
            throw new /*Connection*/Exception("A socket was unable to be created.", se);
        }

        return tcpClient;
    }

    private void InternalGetSslStream(NetworkStream inputStream, ref SslStream sslStream)
    {
        try
        {
            if (this.IsSslMode)
            {
                sslStream = new SslStream(inputStream, false, new RemoteCertificateValidationCallback(this.CertificateValidationCallback), null);
                sslStream.AuthenticateAsClient(this.ServerName, null, SslProtocols.Tls12, false);
            }
        }
        catch (AuthenticationException aex)
        {
            throw aex;
        }
        catch (Exception ex)
        {
            throw new Exception("There is a communications setup mismatch with the iAdapter. Please change the host socket or the setup information for this port.", ex);
        }
    }

    private static void CloseClient(Stream stream, TcpClient client)
    {
        try
        {
            stream?.Close();
            client?.Close();
        }
        catch (SocketException se)
        {
            throw new Exception("A socket was unable to be closed.", se);
        }
    }

    private static bool IsCompressed(byte firstByte, byte secondByte)
    {
        if (firstByte == 120 && (secondByte == 156 || secondByte == 1 || secondByte == 218))
        {
            return true;
        }

        return false;
    }

    private static byte[] TrimMessageHeader(MemoryStream responseStream)
    {
        byte[] data;

        if (responseStream.Length > 50)
        {
            data = new byte[responseStream.Length - 51];
            responseStream.Seek(51, SeekOrigin.Begin);
            responseStream.Read(data, 0, (int)(responseStream.Length - 51));
        }
        else
        {
            data = new byte[responseStream.Length];
            responseStream.Seek(0, SeekOrigin.Begin);
            responseStream.Read(data, 0, (int)responseStream.Length);
        }

        return data;
    }
}
