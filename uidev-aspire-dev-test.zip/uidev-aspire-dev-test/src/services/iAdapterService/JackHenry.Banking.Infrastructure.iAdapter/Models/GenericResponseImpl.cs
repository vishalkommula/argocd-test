// ----------------------------------------------------------------------
// <copyright file="GenericResponseImpl.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// ----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;
using System;
using System.Collections.Generic;
using System.Linq;

using JackHenry.Banking.IAdapter.Infrastructure.Extensions;
using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
using JackHenry.JHAContractTypes;

public class GenericResponseImpl<T> : ITypedResponse<T>
{
    private List<IResultInfoMessage> allMessages = new List<IResultInfoMessage>();
    private bool disposedValue = false;
    private List<IResultInfoMessage> overrideErrors = new List<IResultInfoMessage>();

    public GenericResponseImpl()
    {
    }

    public GenericResponseImpl(T payload_rs)
    {
        this.Payload_Rs = payload_rs;

        if (payload_rs as IJhaiAdapterMsgResponse != null)
        {
            if ((payload_rs as IJhaiAdapterMsgResponse).MsgRsHdr != null)
            {
                this.AddMessages((payload_rs as IJhaiAdapterMsgResponse).MsgRsHdr.MsgRecInfoArray);
            }
        }

        if (payload_rs as IJhaiAdapterSearchResponse != null)
        {
            if ((payload_rs as IJhaiAdapterSearchResponse).SrchMsgRsHdr != null)
            {
                this.AddMessages((payload_rs as IJhaiAdapterSearchResponse).SrchMsgRsHdr.MsgRecInfoArray);

                this.MoreRecords = (payload_rs as IJhaiAdapterSearchResponse).SrchMsgRsHdr.MoreRec.GetValueOrDefault().IsCaseInsensativeEqual("true");
            }
        }

        this.ResponseStatSuccess = false;

        if ((payload_rs as IJhaiAdapterAddModResponse) != null)
        {
            this.ResponseStatSuccess = (payload_rs as IJhaiAdapterAddModResponse).RsStat == "Success" ? true : false;
        }
    }

    public GenericResponseImpl(IAccount account, T payload_rs)
        : this(payload_rs)
    {
        this.Account = account;
    }

    public GenericResponseImpl(List<IResultInfoMessage> allMessages)
    {
        this.AddMessages(allMessages);
    }

    ~GenericResponseImpl()
    {
        this.Dispose(false);
    }

    public IAccount Account
    {
        get;
        set;
    }

    public List<IResultInfoMessage> AllMessages
    {
        get
        {
            return this.allMessages;
        }
    }

    public bool Delete
    {
        get;
        set;
    }

    public bool DoOverrideErrors
    {
        get;
        set;
    }

    public IEnumerable<IResultInfoMessage> Errors
    {
        get
        {
            return this.allMessages.Where(m => m.ErrCat.IsCaseInsensativeEqual("error"));
        }
    }

    public GenericException Exception
    {
        get;
        set;
    }

    public IEnumerable<IResultInfoMessage> Faults
    {
        get
        {
            return this.allMessages.Where(m => m.ErrCat.IsCaseInsensativeEqual("fault"));
        }
    }

    public bool HasException
    {
        get
        {
            return this.Exception != null;
        }
    }

    public bool HasFaults
    {
        get
        {
            return !this.Faults.IsNullOrEmpty();
        }
    }

    public bool HasMalady
    {
        get
        {
            if (this.HasException || this.allMessages.Count > 0)
            {
                return true;
            }

            return false;
        }
    }

    public bool HasMaladyExcludeWarnings
    {
        get
        {
            if (this.HasException || this.allMessages.Where(m => !m.ErrCat.IsCaseInsensativeEqual("warning")).Count() > 0)
            {
                return true;
            }

            return false;
        }
    }

    public bool HasOverrides
    {
        get
        {
            return !this.Overrides.IsNullOrEmpty();
        }
    }

    public bool HasResultErrors
    {
        get
        {
            return !this.Errors.IsNullOrEmpty();
        }
    }

    public bool HasUndefinedErrors
    {
        get
        {
            return !this.UndefinedErrors.IsNullOrEmpty();
        }
    }

    public bool HasWarnings
    {
        get
        {
            return !this.Warnings.IsNullOrEmpty();
        }
    }

    public bool MoreRecords
    {
        get;
        set;
    }

    public List<IResultInfoMessage> OverrideErrors
    {
        get
        {
            return this.overrideErrors;
        }

        set
        {
            this.overrideErrors = value;
        }
    }

    public IEnumerable<IResultInfoMessage> Overrides
    {
        get
        {
            return this.allMessages.Where(m => m.ErrCat.IsCaseInsensativeEqual("override"));
        }
    }

    public T Payload_Rs
    {
        get;
        set;
    }

    public bool ResponseStatSuccess
    {
        get;
        set;
    }

    public object ReturnValue
    {
        get;
        set;
    }

    public IEnumerable<IResultInfoMessage> UndefinedErrors
    {
        get
        {
            return this.allMessages.Where(m => m.ErrCat.IsCaseInsensativeEqual("undefined"));
        }
    }

    public IEnumerable<IResultInfoMessage> Warnings
    {
        get
        {
            return this.allMessages.Where(m => m.ErrCat.IsCaseInsensativeEqual("warning"));
        }
    }

    public static GenericResponseImpl<T> CreateExceptionResponse(GenericException ex)
    {
        return new GenericResponseImpl<T>()
        {
            Exception = ex
        };
    }

    public static GenericResponseImpl<T> CreateExceptionResponse(string endUserSafeMessage, string detailedMessage, Exception innerException)
    {
        return CreateExceptionResponse(new GenericException(detailedMessage, endUserSafeMessage, innerException));
    }

    public static GenericResponseImpl<T> CreateExceptionResponse(string endUserSafeMessage, string detailedMessage)
    {
        return CreateExceptionResponse(new GenericException(detailedMessage, endUserSafeMessage));
    }

    public static GenericResponseImpl<T> CreateFaultedResponse(IEnumerable<IResultInfoMessage> messages)
    {
        GenericResponseImpl<T> response = new GenericResponseImpl<T>();
        response.allMessages.AddRange(messages);

        return response;
    }

    public void AddMessage(string errCode, string errCat, string errElemVal, string errElem, string errLoc, string errDesc)
    {
        this.AddMessage(new Internal_impl()
        {
            ErrCode = errCode,
            ErrCat = errCat,
            ErrElemVal = errElemVal,
            ErrElem = errElem,
            ErrLoc = errLoc,
            ErrDesc = errDesc
        });
    }

    public void AddMessage(IResultInfoMessage message)
    {
        if (message == null)
        {
            return;
        }

        this.allMessages.Add(message);
    }

    public void AddMessages(IEnumerable<IResultInfoMessage> messages)
    {
        if (messages.IsNullOrEmpty())
        {
            return;
        }

        this.allMessages.AddRange(messages);
    }

    public GenericResponseImpl<IAccountResponse> CloneAsIAccountResponse()
    {
        GenericResponseImpl<IAccountResponse> newReturn = new GenericResponseImpl<IAccountResponse>();
        if ((this.Payload_Rs as IAccountResponse) != null)
        {
            newReturn.Payload_Rs = this.Payload_Rs as IAccountResponse;
        }
        else if ((this.Payload_Rs as IAccount) != null)
        {
            newReturn.Payload_Rs = (this.Payload_Rs as IAccount).ToIAccountResponse();
        }

        newReturn.AllMessages.AddRange(this.allMessages);
        newReturn.Exception = this.Exception;
        newReturn.Account = this.Account;
        newReturn.MoreRecords = this.MoreRecords;

        return newReturn;
    }

    public GenericResponseImpl<IPrvdUsrOptRs> CloneAsIPrvdUsrOptRsInterface()
    {
        GenericResponseImpl<IPrvdUsrOptRs> newReturn = new GenericResponseImpl<IPrvdUsrOptRs>();
        if (this.Payload_Rs is IPrvdUsrOptRs)
        {
            newReturn.Payload_Rs = this.Payload_Rs as IPrvdUsrOptRs;
        }

        newReturn.AllMessages.AddRange(this.allMessages);
        newReturn.Exception = this.Exception;
        if (this.Account != null)
        {
            newReturn.Account = this.Account;
        }

        newReturn.MoreRecords = this.MoreRecords;

        return newReturn;
    }

    public GenericResponseImpl<IAccountSearchResponse> CloneAsISearchResponse()
    {
        GenericResponseImpl<IAccountSearchResponse> newReturn = new GenericResponseImpl<IAccountSearchResponse>();
        if ((this.Payload_Rs as IAccountSearchResponse) != null)
        {
            newReturn.Payload_Rs = this.Payload_Rs as IAccountSearchResponse;
        }
        else if ((this.Payload_Rs as IAccount) != null)
        {
            newReturn.Payload_Rs = (this.Payload_Rs as IAccountSearchResponse).ToIAccountSearchResponse();
        }

        newReturn.AllMessages.AddRange(this.allMessages);
        newReturn.Exception = this.Exception;
        newReturn.Account = this.Account;
        newReturn.MoreRecords = this.MoreRecords;

        return newReturn;
    }

    public void Dispose()
    {
        this.Dispose(true);
        GC.SuppressFinalize(this);
    }

    public string ErrorsToString()
    {
        return this.InternalMessageHandler(this.Errors);
    }

    public string FaultsToString()
    {
        return this.InternalMessageHandler(this.Faults);
    }

    public IResultInfoMessage MessageByCode(string code)
    {
        return this.allMessages.FirstOrDefault(p => code.Contains(p.ErrCode));
    }

    public string OverridesToString()
    {
        return this.InternalMessageHandler(this.Overrides);
    }

    public string UndefinedErrorsToString()
    {
        return this.InternalMessageHandler(this.UndefinedErrors);
    }

    public string WarningsToString()
    {
        return this.InternalMessageHandler(this.Warnings);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!this.disposedValue)
        {
            if (disposing)
            {
                // TODO: dispose managed state (managed objects).
                this.Account = null;
                this.allMessages?.DisposeCollection();
                this.allMessages = null;

                this.Exception = null;

                if (this.Payload_Rs is IDisposable)
                {
                    (this.Payload_Rs as IDisposable).Dispose();
                }

                this.Payload_Rs = default(T);
            }

            this.disposedValue = true;
        }
    }

    private string InternalMessageHandler(IEnumerable<IResultInfoMessage> messages)
    {
        return messages.MessagesToString();
    }

    private class Internal_impl : IResultInfoMessage
    {
        public string ErrCat
        {
            get;
            internal set;
        }

        public string ErrCode
        {
            get;
            internal set;
        }

        public string ErrDesc
        {
            get;
            internal set;
        }

        public string ErrElem
        {
            get;
            internal set;
        }

        public string ErrElemVal
        {
            get;
            internal set;
        }

        public string ErrLoc
        {
            get;
            internal set;
        }
    }
}
