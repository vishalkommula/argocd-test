// ----------------------------------------------------------------------
// <copyright file="TrustedCertificateModel.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// ----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Models;

using System;
using System.Security;
using System.Security.Cryptography.X509Certificates;
using System.Xml.Serialization;

using JackHenry.Banking.IAdapter.Infrastructure.Extensions;
using JackHenry.Enterprise.Security;

public class TrustedCertificateModel
{
    private readonly string magicStringThatCannotBeChanged = "efb4c95e-50b4-46ec-89ff-3818817d1165";

    private string subject;
    private string issuer;
    private int version;
    private DateTime? notBefore;
    private DateTime? notAfter;
    private string thumbPrint;
    private string serialNumber;
    private SecureString publicKey;
    private string commonName;
    private string serializablePublicKey;

    public TrustedCertificateModel()
    {
    }

    public TrustedCertificateModel(X509Certificate2 certificate)
    {
        this.commonName = certificate.GetNameInfo(X509NameType.SimpleName, false);
        this.subject = certificate.Subject;
        this.issuer = certificate.Issuer;
        this.version = certificate.Version;
        this.notBefore = certificate.NotBefore;
        this.notAfter = certificate.NotAfter;
        this.thumbPrint = certificate.Thumbprint;
        this.serialNumber = certificate.SerialNumber;
        this.publicKey = EncryptionHelper.EncryptString(certificate.GetPublicKeyString(), this.magicStringThatCannotBeChanged).ToSecureString();
    }

    public string CommonName
    {
        get
        {
            return this.commonName;
        }

        set
        {
            this.commonName = value;
        }
    }

    public string Subject
    {
        get
        {
            return this.subject;
        }

        set
        {
            this.subject = value;
        }
    }

    public string Issuer
    {
        get
        {
            return this.issuer;
        }

        set
        {
            this.issuer = value;
        }
    }

    public int Version
    {
        get
        {
            return this.version;
        }

        set
        {
            this.version = value;
        }
    }

    public DateTime? NotBefore
    {
        get
        {
            return this.notBefore;
        }

        set
        {
            this.notBefore = value;
        }
    }

    public DateTime? NotAfter
    {
        get
        {
            return this.notAfter;
        }

        set
        {
            this.notAfter = value;
        }
    }

    public string Thumbprint
    {
        get
        {
            return this.thumbPrint;
        }

        set
        {
            this.thumbPrint = value;
        }
    }

    public string SerialNumber
    {
        get
        {
            return this.serialNumber;
        }

        set
        {
            this.serialNumber = value;
        }
    }

    [XmlIgnore]
    public SecureString PublicKey
    {
        get
        {
            return this.publicKey;
        }

        set
        {
            this.publicKey = value;
        }
    }

    public string SerializablePublicKey
    {
        get
        {
            return this.serializablePublicKey;
        }

        set
        {
            this.serializablePublicKey = value;
        }
    }
}
