// -----------------------------------------------------------------------
// <copyright file="IIAdapterService.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright ? 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace JackHenry.Banking.IAdapter.Infrastructure.Interfaces;

public interface IIAdapterService
{
    Task<ITypedResponse<TRs>> AddModAsync<TRs>(string requestXML, string institution);

    Task<ITypedResponse<TRs>> InquireAsync<TRs>(string requestXML, string institution);

    Task<ITypedResponse<TRs>> SearchAsync<TRs>(string requestXML, string institution);

    Task<ITypedResponse<TRs>> PingAsync<TRs>(string requestXML, string institution);
}
