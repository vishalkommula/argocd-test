﻿// ----------------------------------------------------------------------
// <copyright file="ITypedResponse.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// ----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
using System.Collections.Generic;

using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.JHAContractTypes;

public interface ITypedResponse<TPayload>
{
    IAccount Account
    {
        get;
        set;
    }

    List<IResultInfoMessage> AllMessages
    {
        get;
    }

    IEnumerable<IResultInfoMessage> Errors
    {
        get;
    }

    IEnumerable<IResultInfoMessage> Faults
    {
        get;
    }

    bool ResponseStatSuccess
    {
        get;
        set;
    }

    bool HasFaults
    {
        get;
    }

    bool HasMalady
    {
        get;
    }

    bool HasMaladyExcludeWarnings
    {
        get;
    }

    bool HasOverrides
    {
        get;
    }

    bool HasResultErrors
    {
        get;
    }

    bool HasUndefinedErrors
    {
        get;
    }

    bool HasWarnings
    {
        get;
    }

    bool MoreRecords
    {
        get;
        set;
    }

    IEnumerable<IResultInfoMessage> Overrides
    {
        get;
    }

    TPayload Payload_Rs { get; set; }

    object ReturnValue { get; set; }

    IEnumerable<IResultInfoMessage> UndefinedErrors { get; }

    IEnumerable<IResultInfoMessage> Warnings { get; }

    void AddMessage(IResultInfoMessage message);

    void AddMessage(string errCode, string errCat, string errElemVal, string errElem, string errLoc, string errDesc);

    void AddMessages(IEnumerable<IResultInfoMessage> messages);

    GenericResponseImpl<IAccountResponse> CloneAsIAccountResponse();

    GenericResponseImpl<IPrvdUsrOptRs> CloneAsIPrvdUsrOptRsInterface();

    GenericResponseImpl<IAccountSearchResponse> CloneAsISearchResponse();

    string ErrorsToString();

    string FaultsToString();

    IResultInfoMessage MessageByCode(string code);

    string OverridesToString();

    string UndefinedErrorsToString();

    string WarningsToString();
}
