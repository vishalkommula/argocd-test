// -----------------------------------------------------------------------
// <copyright file="ILoggingService.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2016 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Interfaces;

using System;

using static JackHenry.Banking.IAdapter.Infrastructure.Enums.StaticEnums;

public interface ILoggingService
{
    bool CanAddPerformanceLogging { get; }

    void EndPerformanceMonitoringSession();

    void LogException(Exception exception);

    void LogException(string endUserSafeMessage, string detailedMessage, Exception exception);

    void LogMessage(string message, LogType logType);
}
