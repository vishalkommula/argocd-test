// -----------------------------------------------------------------------
// <copyright file="IInquiryResponse.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2016 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace JackHenry.Banking.IAdapter.Infrastructure.Interfaces;

using System;
using System.Collections.Generic;

using JackHenry.JHAContractTypes;

/// <summary>
/// This interface if for handling inquiry response errors back from the
/// iAdapter.
/// </summary>
/// <typeparam name="TPayload">The type of the payload.</typeparam>
public interface IInquiryResponse<TPayload> : IResponse<TPayload>, IDisposable
{
    /// <summary>
    /// Gets the errors.
    /// </summary>
    IEnumerable<IResultInfoMessage> Errors
    {
        get;
    }

    /// <summary>
    /// Gets the faults.
    /// </summary>
    IEnumerable<IResultInfoMessage> Faults
    {
        get;
    }

    /// <summary>
    /// Gets the warnings.
    /// </summary>
    IEnumerable<IResultInfoMessage> Warnings
    {
        get;
    }

    /// <summary>
    /// Gets the overrides.
    /// </summary>
    IEnumerable<IResultInfoMessage> Overrides
    {
        get;
    }

    /// <summary>
    /// Gets the undefined errors.
    /// </summary>
    IEnumerable<IResultInfoMessage> UndefinedErrors
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether this instance has faults.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance has faults; otherwise, <c>false</c>.
    /// </value>
    bool HasFaults
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether this instance has warnings.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance has warnings; otherwise, <c>false</c>.
    /// </value>
    bool HasWarnings
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether this instance has overrides.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance has overrides; otherwise, <c>false</c>.
    /// </value>
    bool HasOverrides
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether this instance has malady.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance has malady; otherwise, <c>false</c>.
    /// </value>
    bool HasMalady
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether this instance has undefined errors.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance has undefined errors; otherwise, <c>false</c>.
    /// </value>
    bool HasUndefinedErrors
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether this instance has malady exclude warnings.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance has malady exclude warnings; otherwise, <c>false</c>.
    /// </value>
    bool HasMaladyExcludeWarnings
    {
        get;
    }

    /// <summary>
    /// Gets all messages.
    /// </summary>
    List<IResultInfoMessage> AllMessages
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether this instance has result errors.
    /// </summary>
    /// <value>
    /// <c>true</c> if this instance has result errors; otherwise, <c>false</c>.
    /// </value>
    bool HasResultErrors
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether [more records].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [more records]; otherwise, <c>false</c>.
    /// </value>
    bool MoreRecords
    {
        get;
    }

    /// <summary>
    /// Gets the cursor.
    /// </summary>
    /// <value>
    /// The cursor.
    /// </value>
    string Cursor
    {
        get;
    }

    /// <summary>
    /// Gets the total records.
    /// </summary>
    /// <value>
    /// The total records.
    /// </value>
    int TotalRecords
    {
        get;
    }

    /// <summary>
    /// Gets a value indicating whether [response stat success].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [response stat success]; otherwise, <c>false</c>.
    /// </value>
    bool ResponseStatSuccess
    {
        get;
    }

    /// <summary>
    /// Faultses to string.
    /// </summary>
    /// <returns>string of faults</returns>
    string FaultsToString();

    /// <summary>
    /// Warningses to string.
    /// </summary>
    /// <returns>string of warnings.</returns>
    string WarningsToString();

    /// <summary>
    /// Overrideses to string.
    /// </summary>
    /// <returns>string of overrides.</returns>
    string OverridesToString();

    /// <summary>
    /// Undefineds the errors to string.
    /// </summary>
    /// <returns>string of undefined errors.</returns>
    string UndefinedErrorsToString();

    /// <summary>
    /// Errorses to string.
    /// </summary>
    /// <returns>string of errors.</returns>
    string ErrorsToString();

    /// <summary>
    /// All messages (faults, warnings, overrides, errors, undefined errors) to string.
    /// </summary>
    /// <returns>string of all messages.</returns>
    string AllMessagesToString();

    /// <summary>
    /// Adds the messages.
    /// </summary>
    /// <param name="messages">The messages.</param>
    void AddMessages(IEnumerable<IResultInfoMessage> messages);
}
