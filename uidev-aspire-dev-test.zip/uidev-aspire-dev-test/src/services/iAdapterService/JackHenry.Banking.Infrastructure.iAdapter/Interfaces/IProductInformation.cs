// -----------------------------------------------------------------------
// <copyright file="IProductInformation.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------
namespace JackHenry.Banking.IAdapter.Infrastructure.Interfaces;

public interface IProductInformation
{
    string AdministrativeAliasName
    {
        get;
    }

    bool AllowJWalkJumps
    {
        get;
    }

    string ApplicationName
    {
        get;
    }

    string CommonApplicationDataPath
    {
        get;
    }

    string IAdapterApplicationName
    {
        get;
    }

    string LocalStoragePath
    {
        get;
    }

    string LocalLogPath
    {
        get;
    }

    string ProductName
    {
        get;
    }

    string Version
    {
        get;
    }

    string XperienceProxyName
    {
        get;
    }

    string HelpProduct
    {
        get;
        set;
    }
}
