// -----------------------------------------------------------------------
// <copyright file="IAdapterService.cs" company="Jack Henry &amp; Associates, Inc.">
//     Copyright © 2022 Jack Henry &amp; Associates, Inc.
//     All right reserved.
// </copyright>
// -----------------------------------------------------------------------

namespace JackHenry.Banking.IAdapter.Infrastructure.Services;

using System;
using System.Collections.Generic;

using JackHenry.Banking.IAdapter.Infrastructure.Interfaces;
using JackHenry.Banking.IAdapter.Infrastructure.Models;
using JackHenry.JHAContractTypes;

public class IAdapterService : IIAdapterService
{
    public ITransportService TransportService { get; }

    public IAdapterService(IMasterAdapterSetting adapter, ITransportService transportService)
    {
        TransportService = transportService;
        TransportService.SetTransport(adapter);
    }

    public async Task<ITypedResponse<TRs>> AddModAsync<TRs>(string requestXML, string institution)
    {
        return await Task.Run(() => AddMod<TRs>(requestXML, institution)).ConfigureAwait(false);
    }

    public async Task<ITypedResponse<TRs>> InquireAsync<TRs>(string requestXML, string institution)
    {
        return await Task.Run(() => Inquire<TRs>(requestXML, institution)).ConfigureAwait(false);
    }

    public async Task<ITypedResponse<TRs>> SearchAsync<TRs>(string requestXML, string institution)
    {
        return await Task.Run(() => Search<TRs>(requestXML, institution)).ConfigureAwait(false);
    }

    public async Task<ITypedResponse<TRs>> PingAsync<TRs>(string requestXML, string institution)
    {
        return await Task.Run(() => TransportService.SendXML<TRs>(requestXML, IAdapterTrafficLiterals.MSGSEARCH, null)).ConfigureAwait(false);
    }

    private ITypedResponse<TRs> AddMod<TRs>(string requestXML, string institution)
    {
        try
        {
            return TransportService.SendXML<TRs>(requestXML, IAdapterTrafficLiterals.ADDMOD, institution);
        }
        catch (Exception ex)
        {
            GenericException genEx = new("Unable to execute add/mod with adapter message request.",
                $"Unable to execute add/mod {typeof(TRs)}: {ex.Message}");

            return GenericResponseImpl<TRs>.CreateExceptionResponse(genEx);
        }
    }

    private ITypedResponse<TRs> Inquire<TRs>(string requestXML, string institution)
    {
        try
        {
            return TransportService.SendXML<TRs>(requestXML, IAdapterTrafficLiterals.INQUIRY, institution);
        }
        catch (Exception ex)
        {
            GenericException genEx = new("Unable to execute inquiry with adapter message request.",
                $"Unable to execute inquiry {typeof(TRs)}: {ex.Message}");

            return GenericResponseImpl<TRs>.CreateExceptionResponse(genEx);
        }
    }

    private ITypedResponse<TRs> Search<TRs>(string requestXML, string institution)
    {
        try
        {
            ITypedResponse<TRs> response = TransportService.SendXML<TRs>(requestXML, IAdapterTrafficLiterals.SEARCH, institution);

            ////TODO: Figure out why Payload doesn't contain SrchMsgRsHdr
            ////response.MoreRecords = response?.Payload_Rs?.SrchMsgRsHdr?.MoreRec.GetValueOrDefault().IsCaseInsensativeEqual("true");

            return response;
        }
        catch (Exception ex)
        {
            GenericException genEx = new("Unable to execute search with adapter message request.",
                $"Unable to execute search {typeof(TRs)}: {ex.Message}");

            return GenericResponseImpl<TRs>.CreateExceptionResponse(genEx);
        }
    }
}
