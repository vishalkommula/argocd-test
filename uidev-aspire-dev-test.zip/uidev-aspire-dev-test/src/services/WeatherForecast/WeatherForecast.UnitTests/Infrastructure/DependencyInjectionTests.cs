﻿// ----------------------------------------------------------------------
// <copyright file="DependencyInjectionTests.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.UnitTests.Infrastructure
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Runtime.CompilerServices;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Moq;
    using WeatherForecast.Infrastructure;
    using Xunit;

    [ExcludeFromCodeCoverage]
    public class DependencyInjectionTests
    {
        public static IEnumerable<object[]> DependencyImplementations { get; } = typeof(DependencyInjection).Assembly.GetTypes()
            .Where(t =>
            {
                return t.FullName.StartsWith("WeatherForecast.Infrastructure.Services") ||
                       t.FullName.StartsWith("WeatherForecast.Infrastructure.Repositories");
            })
            .Where(t => !t.GetCustomAttributes(typeof(CompilerGeneratedAttribute), false).Any())
            .Select(t => new object[] { t })
            .ToList();

        [Theory]
        [MemberData(nameof(DependencyImplementations))]
        public void AddInfrastructure_AllDependenciesAdded(Type implementationType)
        {
            var services = new ServiceCollection();
            var configMock = new Mock<IConfiguration>();

            DependencyInjection.AddInfrastructure(services, configMock.Object);

            Assert.Contains(services, sd => sd.ImplementationType == implementationType);
        }
    }
}
