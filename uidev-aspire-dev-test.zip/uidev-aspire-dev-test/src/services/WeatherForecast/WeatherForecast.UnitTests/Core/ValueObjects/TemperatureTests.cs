﻿// ----------------------------------------------------------------------
// <copyright file="TemperatureTests.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.UnitTests.Core.ValueObjects
{
    using System.Diagnostics.CodeAnalysis;
    using WeatherForecast.Core.ValueObjects;
    using Xunit;

    [ExcludeFromCodeCoverage]
    public class TemperatureTests
    {
        [Theory]
        [InlineData(-1)]
        [InlineData(0)]
        [InlineData(1)]
        [InlineData(100)]
        public void ValueProperty_ConstructorValue_Matches(decimal value)
        {
            Temperature temperature = new Temperature(value, default);
            Assert.Equal(value, temperature.Value);
        }

        [Theory]
        [InlineData(Temperature.UnitOfMeasure.Celsius)]
        [InlineData(Temperature.UnitOfMeasure.Fahrenheit)]
        public void UnitProperty_ConstructorUnit_Matches(Temperature.UnitOfMeasure unit)
        {
            Temperature temperature = new Temperature(default, unit);
            Assert.Equal(unit, temperature.Unit);
        }

        [Theory]
        [InlineData(nameof(Temperature.UnitOfMeasure.Celsius), 0)]
        [InlineData(nameof(Temperature.UnitOfMeasure.Fahrenheit), 1)]
        [InlineData("2", 2)]
        public void UnitOfMeasureEnum_UnderlyingValue_Matches(string enumName, int value)
        {
            Assert.Equal(enumName, ((Temperature.UnitOfMeasure)value).ToString());
        }
    }
}
