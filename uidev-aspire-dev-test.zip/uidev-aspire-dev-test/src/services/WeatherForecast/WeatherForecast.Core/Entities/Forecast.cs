﻿// ----------------------------------------------------------------------
// <copyright file="Forecast.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Core.Entities
{
    using System;
    using WeatherForecast.Core.Exceptions;
    using WeatherForecast.Core.ValueObjects;

    public class Forecast
    {
        private DateTime forecastDate;
        private string summary;

        public Forecast()
        {
        }

        public DateTime ForecastDate
        {
            get => this.forecastDate;
            set
            {
                if (value.TimeOfDay != TimeSpan.Zero)
                {
                    throw new InvalidForecastDateException();
                }

                this.forecastDate = value;
            }
        }

        public string Summary
        {
            get => this.summary;
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException();
                }

                this.summary = value;
            }
        }

        public Temperature CurrentTemperature { get; private set; }

        public Temperature FeelsLikeTemperature { get; private set; }

        public Temperature HighTemperature { get; private set; }

        public Temperature LowTemperature { get; private set; }

        public void UpdateCurrentTemperature(Temperature current, Temperature feelsLike)
        {
            _ = current ?? throw new ArgumentNullException(nameof(current));
            _ = feelsLike ?? throw new ArgumentNullException(nameof(feelsLike));

            this.CurrentTemperature = current;
            this.FeelsLikeTemperature = feelsLike;
        }

        public void UpdateHighAndLow(Temperature high, Temperature low)
        {
            _ = high ?? throw new ArgumentNullException(nameof(high));
            _ = low ?? throw new ArgumentNullException(nameof(low));

            if (high.Value < low.Value)
            {
                throw new InvalidHighAndLowTempException();
            }

            this.HighTemperature = high;
            this.LowTemperature = low;
        }
    }
}
