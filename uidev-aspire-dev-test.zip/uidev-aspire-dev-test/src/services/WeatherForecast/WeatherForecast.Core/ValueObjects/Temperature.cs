﻿// ----------------------------------------------------------------------
// <copyright file="Temperature.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Core.ValueObjects
{
    public class Temperature
    {
        public Temperature(decimal value, UnitOfMeasure unit)
        {
            this.Value = value;
            this.Unit = unit;
        }

        public enum UnitOfMeasure
        {
            Celsius,
            Fahrenheit
        }

        public decimal Value { get; }

        public UnitOfMeasure Unit { get; }
    }
}
