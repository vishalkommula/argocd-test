﻿// ----------------------------------------------------------------------
// <copyright file="IWeatherForecastRepository.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Core.Interfaces
{
    using System;
    using System.Threading.Tasks;
    using WeatherForecast.Core.Entities;
    using WeatherForecast.Core.ValueObjects;

    public interface IWeatherForecastRepository
    {
        public Task<Forecast> GetWeatherForecastForDate(DateTime forecastDate, Temperature.UnitOfMeasure unitOfMeasure);
    }
}