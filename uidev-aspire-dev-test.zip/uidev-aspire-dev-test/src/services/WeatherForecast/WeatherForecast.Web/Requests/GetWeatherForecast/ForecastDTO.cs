﻿// ----------------------------------------------------------------------
// <copyright file="ForecastDTO.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Web.Requests.GetWeatherForecast
{
    using System;
    using WeatherForecast.Core.Entities;
    using WeatherForecast.Web.Mappings;

    public class ForecastDTO : IMapFrom<Forecast>
    {
        public DateTime ForecastDate { get; set; }

        public string Summary { get; set; }

        public TemperatureDTO CurrentTemperature { get; set; }

        public TemperatureDTO FeelsLikeTemperature { get; set; }

        public TemperatureDTO HighTemperature { get; set; }

        public TemperatureDTO LowTemperature { get; set; }
    }
}
