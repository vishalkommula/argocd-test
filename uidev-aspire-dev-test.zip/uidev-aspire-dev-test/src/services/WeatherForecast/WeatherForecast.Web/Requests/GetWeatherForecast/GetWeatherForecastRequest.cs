﻿// ----------------------------------------------------------------------
// <copyright file="GetWeatherForecastRequest.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Web.Requests.GetWeatherForecast
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using AutoMapper;
    using MediatR;
    using WeatherForecast.Core.Interfaces;
    using WeatherForecast.Core.ValueObjects;

    public class GetWeatherForecastRequest : IRequest<ForecastDTO>
    {
        public DateTime ForecastDate { get; set; }

        public string TemperatureUnit { get; set; }
    }

    public class GetWeatherForecastRequestHandler : IRequestHandler<GetWeatherForecastRequest, ForecastDTO>
    {
        public GetWeatherForecastRequestHandler(
            IMapper mapper,
            IWeatherForecastRepository repository)
        {
            this.Mapper = mapper;
            this.Repository = repository;
        }

        private IMapper Mapper { get; }

        private IWeatherForecastRepository Repository { get; }

        public async Task<ForecastDTO> Handle(GetWeatherForecastRequest request, CancellationToken cancellationToken)
        {
            Core.Entities.Forecast rs = await this.Repository.GetWeatherForecastForDate(
                request.ForecastDate,
                Enum.Parse<Temperature.UnitOfMeasure>(request.TemperatureUnit));

            return this.Mapper.Map<ForecastDTO>(rs);
        }
    }
}
