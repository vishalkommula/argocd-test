﻿// ----------------------------------------------------------------------
// <copyright file="GetWeatherForecastValidator.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Web.Requests.GetWeatherForecast
{
    using FluentValidation;
    using WeatherForecast.Core.Interfaces;
    using WeatherForecast.Core.ValueObjects;

    public class GetWeatherForecastValidator : AbstractValidator<GetWeatherForecastRequest>
    {
        public GetWeatherForecastValidator(IDateTime dateTime)
        {
            this.RuleFor(v => v.ForecastDate)
                .Must(x => x >= dateTime.Now.Date)
                .NotEmpty();

            this.RuleFor(v => v.TemperatureUnit)
                .IsEnumName(typeof(Temperature.UnitOfMeasure), caseSensitive: false)
                .NotEmpty();
        }
    }
}
