﻿// ----------------------------------------------------------------------
// <copyright file="TemperatureDTO.cs" company="Jack Henry &amp; Associates, Inc.">
// Copyright (c) 2021 Jack Henry &amp; Associates, Inc.
// All rights reserved.
// </copyright>
// ----------------------------------------------------------------------

namespace WeatherForecast.Web.Requests.GetWeatherForecast
{
    using WeatherForecast.Core.ValueObjects;
    using WeatherForecast.Web.Mappings;

    public class TemperatureDTO : IMapFrom<Temperature>
    {
        public decimal Value { get; set; }

        public string Unit { get; set; }
    }
}
