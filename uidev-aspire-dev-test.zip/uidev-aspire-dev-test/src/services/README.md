## Development server

For first time setup, Visual Studio should ask to install a development certificate. If you're using another IDE, you may need to run the command `dotnet dev-certs https --trust` before you can start debugging. You may also need to install the [Azure Artifacts Credential Provider](https://github.com/microsoft/artifacts-credprovider).

To start debugging, make sure Docker Desktop is running, choose `docker-compose` as the start up project, then click start. Swagger is accessible from https://localhost:5001/swagger/index.html.

## Generate a microservice

The `WeatherForecast` sample app can be used as a template for the `dotnet new` command. 

For first time setup, navigate to the `services` folder in your preferred terminal and run:

    dotnet new -i WeatherForecast

Then you can create new microservices with the command:

    dotnet new uid-microservice --name MicroserviceName

## Running unit tests

To run unit tests, check out the [Test Explorer](https://docs.microsoft.com/en-us/visualstudio/test/run-unit-tests-with-test-explorer) feature built into Visual Studio.

## References

I borrowed a lot of ideas from the clean architecture repos of [Jason Taylor](https://github.com/jasontaylordev/CleanArchitecture) and [Steve Smith](https://github.com/ardalis/CleanArchitecture). Props to those guys.
