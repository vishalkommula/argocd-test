export interface InqAccessTrakRecItemModel{
    custId: string;
    acctId: string;
    acctType?: string;
    acctRstr?: string;
    inqApp: string;
    inqPgm: string;
    inqDt: string;
    inqTime: string;
    purgeDt: string;
    userId: string;
    userName: string;
    workstationId: string;
    pincode?: string;
};
