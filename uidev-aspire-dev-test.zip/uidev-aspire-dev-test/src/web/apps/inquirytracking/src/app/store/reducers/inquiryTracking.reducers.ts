import { createReducer, on } from '@ngrx/store';
import { InquiryTrackingState } from '../state/inquiryTracking.state';
import * as InquiryTrackingActions from '../actions/inquiryTracking.actions';

export const initialInquiryTrackingState: InquiryTrackingState = {
    inqAccessTrakSrchResponse: {} as any,
    currentInquiryModule: 'A',
    currentCustomerId: 'A000013',
    currentAccountId: '88880',
    currentAccountType: 'L'
};

export const inquiryTrackingReducer = createReducer(
    initialInquiryTrackingState,

    // reducer for inquiry tracking search records success
    on(InquiryTrackingActions.getInqAccessTrakSrchSuccess,(state,action): InquiryTrackingState=>({
        ...state,
        inqAccessTrakSrchResponse: action.inqAccessTrakSrchResponse,
    }))
);
