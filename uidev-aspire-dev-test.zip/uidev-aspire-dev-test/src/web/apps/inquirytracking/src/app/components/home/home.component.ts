import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { InqAccessTrakRecItemModel } from '../../models/inquiry-access-track-record-item.model';
import * as InquiryTrackingActions from '../../store/actions/inquiryTracking.actions';
import * as InquiryTrackingSelectors from '../../store/selectors/inquiryTracking.selectors';

const selectedTab = {
  account: 'Account',
  customer: 'Customer'
};

const selectedInquiryModule = {
  account: 'A',
  customer: 'C'
};

@Component({
  selector: 'uid-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {

  inquiryTrackSearchRecords$: Observable<InqAccessTrakRecItemModel> = of();
  currentSelectedInquiryModule$: Observable<string> = of();
  currentSelectedAccountId$: Observable<string> = of();
  currentSelectedAccountType$: Observable<string> = of();
  currentSelectedCustomerId$: Observable<string> = of();

  inquiryTrackingActions = InquiryTrackingActions;
  inquiryTrackingSelectors = InquiryTrackingSelectors;
  currentSelectedTab = '';
  // constant values
  selectedTab = selectedTab;
  selectedInquiryModule = selectedInquiryModule;

  constructor(private store: Store) {

    this.currentSelectedInquiryModule$ = this.store.select(this.inquiryTrackingSelectors.selectCurrentInquiryModule);
    this.currentSelectedAccountType$ = this.store.select(this.inquiryTrackingSelectors.selectCurrentAccountType);
    this.currentSelectedCustomerId$ = this.store.select(this.inquiryTrackingSelectors.selectCurrentCustomerId);
    this.currentSelectedAccountId$ = this.store.select(this.inquiryTrackingSelectors.selectCurrentAccountId);
  }

  // to change the current selected tab value
  tabChange(event: any){
  if(this.currentSelectedTab === ''){
    this.currentSelectedTab = this.selectedTab.account;
    return;
  }
  this.currentSelectedTab = this.currentSelectedTab === this.selectedTab.account ? this.selectedTab.customer : this.selectedTab.account;
  }

}
