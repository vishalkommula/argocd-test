import { Component, Input, OnInit, ViewChild } from '@angular/core';

// Ag grid
import { ColDef, GridApi, GridOptions } from 'ag-grid-enterprise';
import { GridReadyEvent, GridSizeChangedEvent, SideBarDef } from 'ag-grid-community';

// UID
import { UidGridAngular, WatchColumnActionsEnum, WatchColumnDefinitionModel } from '@uid/uid-directives';

// NGRX
import { Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import * as InquiryTrackingActions from '../../store/actions/inquiryTracking.actions';
import * as InquiryTrackingSelectors from '../../store/selectors/inquiryTracking.selectors';

import { InquiryTrackingGridsDef } from './inquiry-tracking-grid.def';
import { InqAccessTrakRecItemModel } from '../../models/inquiry-access-track-record-item.model';
import { InqAccessTrakSrchRequestModel } from '../../models/inquiry-access-track-search-request.model';



@Component({
  selector: 'uid-inquiry-tracking-grid-details',
  templateUrl: './inquiry-tracking-grid-details.component.html',
  styleUrls: ['./inquiry-tracking-grid-details.component.scss']
})
export class InquiryTrackingGridDetailsComponent implements OnInit {

  @ViewChild('uidGrid')
  uidGrid = {} as UidGridAngular;
  // boolean value sets to true if the inquiry tracking is called from account inquiry
  @Input() isCustomerInquiry = false;
  @Input() currentSelectedCustomerId!: string;
  @Input() currentSelectedAccountId!: string;
  @Input() currentSelectedAccountType!: string;
  public colDefs!: ColDef[];
  public defaultColDefs!: ColDef;
  public gridOptions!: GridOptions;
  gridApi: GridApi = {} as GridApi;
  sideBar: SideBarDef;
  // to hide columns
  watchColumns!: WatchColumnDefinitionModel;

  inquiryTrackingActions = InquiryTrackingActions;
  inquiryTrackingSelectors = InquiryTrackingSelectors;

  inquiryTrackSearchRecords$: Observable<InqAccessTrakRecItemModel[]> = of();

  constructor(private store: Store, private gridDef: InquiryTrackingGridsDef) {
    this.colDefs = this.gridDef.columns;
    this.defaultColDefs = this.gridDef.defautColDef;
    this.gridOptions = this.gridDef.gridOptions;
    this.gridApi = this.uidGrid.api;
    this.sideBar = this.gridDef.sideBar;
    this.inquiryTrackSearchRecords$ = this.store.select(this.inquiryTrackingSelectors.selectInquiryTrackingSearchRecords);
  }

  ngOnInit(): void {
    // to hide or show customer id and account id columns
    this.watchColumns = {
      records: [
        {
          action: WatchColumnActionsEnum.hide,
          fieldName: 'custId',
          value: this.isCustomerInquiry
        },
        {
          action: WatchColumnActionsEnum.hide,
          fieldName: 'acctId',
          value: !this.isCustomerInquiry
        },
      ]
    };
    // request model
    const requestModel: InqAccessTrakSrchRequestModel = {
      srchMsgRqHdr: {
        jXLogTrackingId: '32c26a3e-157d-4f70-b96b-295f3b0ce4cc',
        instEnv: '562',
        maxRec: '250',
        cursor: '0'
      },
      custId: this.currentSelectedCustomerId
    };
    requestModel.acctId = !this.isCustomerInquiry ? this.currentSelectedAccountId : undefined;
    requestModel.acctType = !this.isCustomerInquiry ? this.currentSelectedAccountType : undefined;
    this.store.dispatch(this.inquiryTrackingActions.getInqAccessTrakSrch({ inqAccessTrakSrchRequest: requestModel }));
  }

  onGridReady(event: GridReadyEvent) {
    this.gridApi = event.api;
    event.api.closeToolPanel();
    event.api.sizeColumnsToFit();
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
    event.api.sizeColumnsToFit();
  }
}
