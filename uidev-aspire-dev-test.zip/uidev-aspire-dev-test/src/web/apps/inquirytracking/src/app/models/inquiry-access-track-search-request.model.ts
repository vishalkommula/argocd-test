import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface InqAccessTrakSrchRequestModel{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    custId: string;
    acctId?: string;
    acctType?: string;
};
