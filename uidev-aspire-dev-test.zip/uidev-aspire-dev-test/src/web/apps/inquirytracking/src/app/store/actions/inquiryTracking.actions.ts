import { createAction, props } from '@ngrx/store';
import { InqAccessTrakSrchRequestModel } from '../../models/inquiry-access-track-search-request.model';
import { InqAccessTrakSrchResponseModel } from '../../models/inquiry-access-track-search-response.model';

// get inquiry track search records
export const getInqAccessTrakSrch = createAction('[Inquiry Tracking] Get Inquiry Tracking Search Records',
    props<{inqAccessTrakSrchRequest: InqAccessTrakSrchRequestModel}>());

// get inquiry track search records success response
export const getInqAccessTrakSrchSuccess = createAction('[Inquiry Tracking] Get Inquiry Tracking Search Records Success',
    props<{inqAccessTrakSrchResponse: InqAccessTrakSrchResponseModel}>());

// get inquiry track search records failure response
export const getInqAccessTrakSrchFailure = createAction('[Inquiry Tracking] Get Inquiry Tracking Search Records Failure',
    props<{error: Error}>());

