import { createFeatureSelector, createSelector } from '@ngrx/store';
import { InquiryTrackingState } from '../state/inquiryTracking.state';

export const selectRoot = createFeatureSelector<InquiryTrackingState>('inquiryTracking');

// get inquiry access tracking search records array
export const selectInquiryTrackingSearchRecords = createSelector(selectRoot,(state)=> state.inqAccessTrakSrchResponse.inqAccessTrakRecArray);

// get inquiry tracking selected from module
export const selectCurrentInquiryModule = createSelector(selectRoot,(state)=> state.currentInquiryModule);

// get the current selected customer id
export const selectCurrentCustomerId = createSelector(selectRoot,(state)=> state.currentCustomerId);

// get the current selected account number
export const selectCurrentAccountId = createSelector(selectRoot,(state)=> state.currentAccountId);

// get the current selected account type
export const selectCurrentAccountType = createSelector(selectRoot,(state)=> state.currentAccountType);


