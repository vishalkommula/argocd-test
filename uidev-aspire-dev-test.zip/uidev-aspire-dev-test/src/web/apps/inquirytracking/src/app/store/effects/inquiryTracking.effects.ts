import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { DataService } from '../../service/data.service';
import * as InquiryTrackingActions from '../actions/inquiryTracking.actions';

@Injectable()
export class InquiryTrackingEffects{
    constructor(private dataservice: DataService, private action$: Actions){}

    loadInquiryAccessTrakSearchRecords$ = createEffect(() => this.action$.pipe(
        ofType(InquiryTrackingActions.getInqAccessTrakSrch),
        switchMap((action)=>
            this.dataservice.getInquiryAccessTrackRecords(action.inqAccessTrakSrchRequest)
            .pipe(
                map((inqAccessTrakSrchResponse) => InquiryTrackingActions.getInqAccessTrakSrchSuccess({inqAccessTrakSrchResponse})),
                catchError((error) => of(InquiryTrackingActions.getInqAccessTrakSrchFailure(error)))
            )
        )
    ));
}
