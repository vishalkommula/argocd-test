import { InqAccessTrakSrchResponseModel } from '../../models/inquiry-access-track-search-response.model';

export interface InquiryTrackingState{
    inqAccessTrakSrchResponse: InqAccessTrakSrchResponseModel;
    // TODO: access these properties from root store
    currentInquiryModule: string;
    currentCustomerId: string;
    currentAccountId: string;
    currentAccountType: string;
};
