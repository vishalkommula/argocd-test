import { DataService } from './data.service';

let service: DataService;
const httpMock = {
  get:jest.fn(),
  post:jest.fn()
};

describe('Data Service Test',()=>{
  beforeEach(()=>{
    service = new DataService(httpMock as any);
  });

  it('component should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getInquiryAccessTrackRecords should be executed to get customer records',()=>{
    const request = {} as any;
    const inqTrackSrchResponse = service.getInquiryAccessTrackRecords(request);
    expect(inqTrackSrchResponse).not.toBeNull();
    expect(inqTrackSrchResponse.toPromise()).toBeTruthy();
  });

  it('getInquiryAccessTrackRecords should be executed to get account records',()=>{
    const request = {acctId: '88880'} as any;
    const inqTrackSrchResponse = service.getInquiryAccessTrackRecords(request);
    expect(inqTrackSrchResponse).not.toBeNull();
    expect(inqTrackSrchResponse.toPromise()).toBeTruthy();
  });
});
