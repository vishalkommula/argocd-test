import { ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import InquriyTrackSearchRecordsMock from '../../mock-data/inquiryAccessAccountTrackSearchResponse.mock.json';
import { InquiryTrackingEffects } from './inquiryTracking.effects';
import * as InquiryTrackingActions from '../actions/inquiryTracking.actions';

const inqTrakRecMockData = InquriyTrackSearchRecordsMock;

const dataServiceSuccessMock = {
    getInquiryAccessTrackRecords: ()=> of(inqTrakRecMockData)
};

const dataServiceFailureMock = {
    getInquiryAccessTrackRecords: ()=> throwError('Error - get inquiry track search records')
};

let actions: ActionsSubject;
let effects: InquiryTrackingEffects;

describe('Inquiry Tracking Effects Test',()=>{
    beforeEach(()=>{
        actions = new ActionsSubject();
    });

    it('loadInquiryAccessTrakSearchRecords should be executed with success response',()=>{
        effects = new InquiryTrackingEffects(dataServiceSuccessMock as any, actions);
        effects.loadInquiryAccessTrakSearchRecords$.subscribe((dispatchedAction)=>{
            expect(dispatchedAction).toEqual(InquiryTrackingActions.getInqAccessTrakSrchSuccess({} as any));
        });
        const action = InquiryTrackingActions.getInqAccessTrakSrch({inqAccessTrakSrchRequest: {} as any});
        actions.next(action);
    });

    it('loadInquiryAccessTrakSearchRecords should be executed with failure response',()=>{
        effects = new InquiryTrackingEffects(dataServiceFailureMock as any, actions);
        effects.loadInquiryAccessTrakSearchRecords$.subscribe((dispatchedAction)=>{
            expect(dispatchedAction).toEqual(InquiryTrackingActions.getInqAccessTrakSrchFailure({error: {} as any}));
        });
        const action = InquiryTrackingActions.getInqAccessTrakSrch({inqAccessTrakSrchRequest: {} as any});
        actions.next(action);
    });
});
