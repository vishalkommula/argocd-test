import { HomeComponent } from './home.component';

let component: HomeComponent;

const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(),
};

const inquiryTrackingSelectors = {
  selectCurrentInquiryModule: jest.fn(),
  selectCurrentAccountType: jest.fn(),
  selectCurrentCustomerId: jest.fn(),
  selectCurrentAccountId: jest.fn()
};

describe('Inquiry Tracking Home Component Test',()=>{
  beforeEach(()=>{
    component = new HomeComponent(storeMock as any);
    component.inquiryTrackingSelectors = inquiryTrackingSelectors as any;
  });

  it('Component should be created',()=>{
    expect(component).toBeTruthy();
  });

  it('tabChange should be executed if current selected tab is empty',()=>{
    const currentTab = '';
    component.currentSelectedTab = currentTab;
    component.tabChange({} as any);
    expect(component.currentSelectedTab).toEqual('Account');
  });

  it('tabChange should be executed if current selected tab is customer',()=>{
    const currentTab = 'Account';
    component.currentSelectedTab = currentTab;
    component.tabChange({} as any);
    expect(component.currentSelectedTab).toEqual('Customer');
  });

  it('tabChange should be executed if current selected tab is account',()=>{
    const currentTab = 'Customer';
    component.currentSelectedTab = currentTab;
    component.tabChange({} as any);
    expect(component.currentSelectedTab).toEqual('Account');
  });
});
