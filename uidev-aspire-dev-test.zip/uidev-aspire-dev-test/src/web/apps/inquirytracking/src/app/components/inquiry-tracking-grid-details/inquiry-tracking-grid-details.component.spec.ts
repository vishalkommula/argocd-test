import { InquiryTrackingGridDetailsComponent } from './inquiry-tracking-grid-details.component';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());


let component: InquiryTrackingGridDetailsComponent;

const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(),
};

const gridDef = {
  columns: [],
  defautColDef: {},
  gridOptions: {}
};

const inquiryTrackingSelectorsMock = {
  selectInquiryTrackingSearchRecords: jest.fn()
};

const inquiryTrackingActionsMock = {
  getInqAccessTrakSrch: jest.fn()
};

describe('Inquiry Tracking Grid Details Component Test',()=>{
  beforeEach(()=>{
    component = new InquiryTrackingGridDetailsComponent(storeMock as any, gridDef as any);
    component.inquiryTrackingActions = inquiryTrackingActionsMock as any;
    component.inquiryTrackingSelectors = inquiryTrackingSelectorsMock as any;
  });

  it('Component should be created',()=>{
    expect(component).toBeTruthy();
  });

  it('onInit should be executed for customer inquiry',()=>{
    component.isCustomerInquiry = true;
    component.currentSelectedCustomerId = 'A000013';
    const requestModel = {
      srchMsgRqHdr: {
        jXLogTrackingId: '32c26a3e-157d-4f70-b96b-295f3b0ce4cc',
        instEnv: '562',
        maxRec: '250',
        cursor: '0'
      },
      custId: 'A000013'
    };
    component.ngOnInit();
    expect(inquiryTrackingActionsMock.getInqAccessTrakSrch).toBeCalledWith({inqAccessTrakSrchRequest: requestModel});
  });

  it('onInit should be executed for account inquiry',()=>{
    component.isCustomerInquiry = false;
    component.currentSelectedCustomerId = 'A000013';
    component.currentSelectedAccountId = '88880';
    component.currentSelectedAccountType = 'L';
    const requestModel = {
      srchMsgRqHdr: {
        jXLogTrackingId: '32c26a3e-157d-4f70-b96b-295f3b0ce4cc',
        instEnv: '562',
        maxRec: '250',
        cursor: '0'
      },
      custId: 'A000013',
      acctId: '88880',
      acctType: 'L'
    };
    component.ngOnInit();
    expect(inquiryTrackingActionsMock.getInqAccessTrakSrch).toBeCalledWith({inqAccessTrakSrchRequest: requestModel});
  });

  it('onGridReady should be executed',()=>{
    const event = {api: {
      closeToolPanel: jest.fn(),
      sizeColumnsToFit: jest.fn()
    }};
    component.onGridReady(event as any);
    expect(component.gridApi).toEqual(event.api);
  });

  it('onGridSizeChanged should be executed',()=>{
    const event = {api: { sizeColumnsToFit: jest.fn()}};
    component.onGridSizeChanged(event as any);
  });

});
