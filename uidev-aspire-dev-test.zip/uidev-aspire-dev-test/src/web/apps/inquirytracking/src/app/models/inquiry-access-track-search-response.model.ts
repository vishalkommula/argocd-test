import { SearchMessageResponseHeaderModel } from '@uid/uid-models';
import { InqAccessTrakRecItemModel } from './inquiry-access-track-record-item.model';

export interface InqAccessTrakSrchResponseModel{
    srchMsgRsHdr:    SearchMessageResponseHeaderModel;
    inqAccessTrakRecArray: InqAccessTrakRecItemModel[];
};
