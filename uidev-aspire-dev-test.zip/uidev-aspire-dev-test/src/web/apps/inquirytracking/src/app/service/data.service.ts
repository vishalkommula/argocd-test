import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { InqAccessTrakSrchRequestModel } from '../models/inquiry-access-track-search-request.model';
import { InqAccessTrakSrchResponseModel } from '../models/inquiry-access-track-search-response.model';
import accountInquiryTrackRecordsMock from '../mock-data/inquiryAccessAccountTrackSearchResponse.mock.json';
import customerInquiryTrackRecordsMock from '../mock-data/inquiryAccessCustomerTrackSearchResponse.mock.json';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private httpClient: HttpClient) { }

  // get inquiry track search records
  getInquiryAccessTrackRecords(request: InqAccessTrakSrchRequestModel): Observable<InqAccessTrakSrchResponseModel>{
    let response;
    if(request.acctId !== undefined){
      response = JSON.parse(JSON.stringify(accountInquiryTrackRecordsMock));
    }else{
      response = JSON.parse(JSON.stringify(customerInquiryTrackRecordsMock));
    }
    return of(response);
  }
}
