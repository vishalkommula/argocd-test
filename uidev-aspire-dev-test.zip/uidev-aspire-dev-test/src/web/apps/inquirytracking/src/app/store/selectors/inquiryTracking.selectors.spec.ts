import * as InquiryTrackingSelector from '../selectors/inquiryTracking.selectors';

describe('Inquiry Tracking Selector Test',()=>{
    it('selectInquiryTrackingSearchRecords should be executed',()=>{
        const mockData = {inqAccessTrakSrchResponse: {inqAccessTrakRecArray: [{} as any]}};
        const selector = InquiryTrackingSelector.selectInquiryTrackingSearchRecords.projector(mockData);
        expect(selector).toEqual(mockData.inqAccessTrakSrchResponse.inqAccessTrakRecArray);
    });

    it('selectCurrentInquiryModule should be executed',()=>{
        const mockData = {currentInquiryModule: 'A'};
        const selector = InquiryTrackingSelector.selectCurrentInquiryModule.projector(mockData);
        expect(selector).toEqual(mockData.currentInquiryModule);
    });

    it('selectCurrentCustomerId should be executed',()=>{
        const mockData = {currentCustomerId: 'A000013'};
        const selector = InquiryTrackingSelector.selectCurrentCustomerId.projector(mockData);
        expect(selector).toEqual(mockData.currentCustomerId);
    });

    it('selectCurrentAccountId should be executed',()=>{
        const mockData = {currentAccountId: '88880'};
        const selector = InquiryTrackingSelector.selectCurrentAccountId.projector(mockData);
        expect(selector).toEqual(mockData.currentAccountId);
    });

    it('selectCurrentAccountType should be executed',()=>{
        const mockData = {currentAccountType: 'L'};
        const selector = InquiryTrackingSelector.selectCurrentAccountType.projector(mockData);
        expect(selector).toEqual(mockData.currentAccountType);
    });
});
