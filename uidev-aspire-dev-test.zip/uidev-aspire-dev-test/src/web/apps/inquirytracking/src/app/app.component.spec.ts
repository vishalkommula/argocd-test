import { AppComponent } from './app.component';

let component: AppComponent;

describe('App Component Test',()=>{
  beforeEach(()=>{
    component = new AppComponent();
  });

  it('Component should be created',()=>{
    expect(component).toBeTruthy();
  });
});
