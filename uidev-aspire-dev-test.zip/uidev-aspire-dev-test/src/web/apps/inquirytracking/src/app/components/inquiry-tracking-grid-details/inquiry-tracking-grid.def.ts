import { Injectable } from '@angular/core';

// Ag grid
import { ColDef, GridOptions, SideBarDef, ValueFormatterParams, ValueGetterParams } from 'ag-grid-community';

// UID
import { AgGridHyperlinkCellRendererComponent } from '@uid/uid-angular-controls';
import { formatDate } from '@uid/uid-utilities';

@Injectable({ providedIn: 'root' })
export class InquiryTrackingGridsDef {

    // custom calendar filter
    filterParams = {
        // provide comparator function
        comparator: (filterLocalDateAtMidnight: any, cellValue: any) => {
            if (cellValue == null) {
                return 0;
            }
            const dateAsString = cellValue;
            // In the example application, dates are stored as yyyy-mm-dd
            // We create a Date object for comparison against the filter date
            const dateParts = dateAsString.split('-');
            const year = Number(dateParts[0]);
            const month = Number(dateParts[1]) - 1;
            const day = Number(dateParts[2]);
            const cellDate = new Date(year, month, day);
             console.log(cellDate, 'celldate');
            // Now that both parameters are Date objects, we can compare
            if (cellDate < filterLocalDateAtMidnight) {
                return -1;
            } else if (cellDate > filterLocalDateAtMidnight) {
                return 1;
            }
            return 0;
        }
    };

    public columns: ColDef[] = [
        {
            field: 'userId',
            headerName: 'User ID',
            hide: true
        },
        {
            headerName: 'Date',
            field: 'inqDt',
            valueFormatter: this.dateFormatter,
            filter: 'agDateColumnFilter',
            filterParams: this.filterParams,
        },
        {
            field: 'userName',
            headerName: 'User Name',
        },
        {
            field: 'custId',
            headerName: 'Customer',
            cellRenderer: AgGridHyperlinkCellRendererComponent,
        },
        {
            field: 'acctId',
            headerName: 'Account',
            valueGetter: this.getAccountId,
            cellRenderer: AgGridHyperlinkCellRendererComponent,
        },
        {
            field: 'workstationId',
            headerName: 'Workstation'
        },
        {
            field: 'inqPgm',
            headerName: 'Program'
        }
    ];

    public gridOptions: GridOptions = {
        columnDefs: this.columns,
        paginationPageSize: 25,
        rowSelection: 'single',
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        suppressDragLeaveHidesColumns: true,
        suppressCellFocus: true,
        suppressMovableColumns: true

    };

    public defautColDef: ColDef = {
        sortable: true,
        filter: true,
        resizable: true,
    };

    public sideBar: SideBarDef = {
        toolPanels: [
            {
                id: 'columns',
                labelDefault: 'Columns',
                labelKey: 'columns',
                iconKey: 'columns',
                toolPanel: 'agColumnsToolPanel',
                toolPanelParams: {
                    suppressRowGroups: true,
                    suppressValues: true,
                    suppressPivots: true,
                    suppressPivotMode: true,
                },
            },
            'filters',
        ],
        defaultToolPanel: 'columns',
    };

    constructor(){}

    // append the inquiry date and time
    dateFormatter(params: ValueFormatterParams){
        const date = params.data.inqDt +'T'+ params.data.inqTime;
        return Date.parse(date) ? formatDate(date,'MM/dd/yyyy t') : '';
    }

    // return account id as empty if account id is 0
    getAccountId(params: ValueGetterParams){
        return params.data.acctId >0 ? params.data.acctId : '';
    }

}
