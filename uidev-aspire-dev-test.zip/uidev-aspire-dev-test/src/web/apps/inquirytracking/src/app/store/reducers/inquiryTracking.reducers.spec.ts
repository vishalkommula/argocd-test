import { initialInquiryTrackingState, inquiryTrackingReducer } from './inquiryTracking.reducers';
import * as InquiryTrackingActions from '../actions/inquiryTracking.actions';

const expectedState = {
    inqAccessTrakSrchResponse: {} as any,
    currentInquiryModule: 'A',
    currentCustomerId: 'A000013',
    currentAccountId: '88880',
    currentAccountType: 'L'
};

describe('Inquiry Tracking Reducer test',()=>{
    it('getInqAccessTrakSrchSuccess should be executed',()=>{
        const state = inquiryTrackingReducer(initialInquiryTrackingState,InquiryTrackingActions.getInqAccessTrakSrchSuccess({inqAccessTrakSrchResponse: {} as any}));
        expect(state).toEqual(expectedState);
    });
});
