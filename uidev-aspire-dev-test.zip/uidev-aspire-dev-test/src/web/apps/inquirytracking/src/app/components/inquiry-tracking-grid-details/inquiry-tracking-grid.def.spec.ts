import { formatDate } from '@uid/uid-utilities';
import { InquiryTrackingGridsDef } from './inquiry-tracking-grid.def';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

let component: InquiryTrackingGridsDef;

describe('Inquiry Tracking Grid Spec Component Test',()=>{
    beforeEach(()=>{
        component = new InquiryTrackingGridsDef();
    });

    it('Component should be created',()=>{
        expect(component).toBeTruthy();
    });

    it('dateFormatter should be executed for correct date',()=>{
        const params = {
            data:{
                inqDt: '2022-03-22',
                inqTime: '23:54:49-05:00'
            }
        };
        const formattedDate = component.dateFormatter(params as any);
        const date = params.data.inqDt +'T'+ params.data.inqTime;
        expect(formattedDate).toEqual(formatDate(date,'MM/dd/yyyy t'));
    });

    it('dateFormatter should be executed for incorrect date',()=>{
        const params = {
            data:{
                inqDt: '2022-35-22',
                inqTime: '23:54:49-05:00'
            }
        };
        const formattedDate = component.dateFormatter(params as any);
        expect(formattedDate).toEqual('');
    });

    it('getAccountId should be executed for account number greater than 0',()=>{
        const params = {data: {acctId: '88880'}};
        const accountNumber = component.getAccountId(params as any);
        expect(accountNumber).toEqual(params.data.acctId);
    });

    it('getAccountId should be executed for account number equals to 0',()=>{
        const params = {data: {acctId: '0'}};
        const accountNumber = component.getAccountId(params as any);
        expect(accountNumber).toEqual('');
    });
});
