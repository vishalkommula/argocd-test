/* eslint-disable @typescript-eslint/member-ordering */
import {Injectable} from '@angular/core';
import {ButtonRendererModel, ButtonRendererClickParms, ButtonRendererComponent, AgGridHyperlinkCellRendererComponent} from '@uid/uid-angular-controls';
import {ColDef, GridOptions, ICellRendererParams} from 'ag-grid-community';

@Injectable({providedIn: 'root'})
export class AssociatedDemandAccountsGridColDef {
    public buttonRendererList: ButtonRendererModel[] = [
        {
            iconType: 'delete',
            onClick: this.onDelete.bind(this),
        }
    ];

    public default: ColDef = {
        resizable: true,
        sortable: true,
        filter: true,
        enablePivot: false,
    };

    public columns: ColDef[] = [
        {
            field: 'multipleAcctTypeDesc',
            headerName: 'Associated Account Type',
            rowGroup: true,
            hide: true,
            suppressColumnsToolPanel: true,
            suppressFiltersToolPanel: true
        },
        // ag grid hyperlink is not used as margin left is added.
        // TODO: need to review.
        {
            field: 'acctId',
            headerName: 'Account',
            filter: 'agTextColumnFilter',
            cellRenderer: (params: ICellRendererParams) =>
            `<a style="margin-left: 60px;text-decoration: underline !important">${params.value}</a>`,
        },
        {
            field: 'personName',
            headerName: 'Customer Name',
            filter: 'agTextColumnFilter',
        },
        {
            field: 'accountDescription',
            headerName: 'Account Description',
            filter: 'agTextColumnFilter',
        },
        // TODO: add ag right aligned cell
        {
            field: 'currentBalance',
            headerName: 'Balance',
            filter: 'agNumberColumnFilter',
            valueFormatter: this.amountFormatter,
            cellClass: 'ag-right-aligned-cell',
            cellStyle: params => params.value <0 ? { color: 'red' }: null
        },
        {
            field: 'accountStatus',
            headerName: 'Status ',
            filter: 'agTextColumnFilter',
        },
        {
            field: 'actionButtons',
            headerName: '',
            sortable: false,
            filter: false,
            suppressFiltersToolPanel:true,
            pinned: 'right',
            minWidth: 125,
            cellRenderer: ButtonRendererComponent,
            cellRendererParams: {
                buttonList: this.buttonRendererList
            },
            suppressColumnsToolPanel: true,
        }
    ];

    public gridOptions: GridOptions = {
        columnDefs: this.columns,
        rowSelection: 'single',
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        pagination: true,
        paginationPageSize: 25,
        suppressDragLeaveHidesColumns: true,
        suppressCellFocus: true,
        suppressMovableColumns: true
    };

    amountFormatter(event: any): string {
        if (!event || !event.data) {
            return '';
        }

        const currentRecord = event.data;

        const inrFormat = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2,
        });

        if (currentRecord.currentBalance <0) {
            return '('+inrFormat.format(Math.abs(currentRecord.currentBalance)) +')';
        }

        return inrFormat.format(currentRecord.currentBalance);
    }
    onDelete(event: ButtonRendererClickParms): void {
        console.log('clicking Delete!!', event);
    }
};
