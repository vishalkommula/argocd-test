import * as sut from './associateddemandaccount.function';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

describe('Associated Demand Account Functions!', () => {
  it('getAssociatedDemandAccountGroups returns stuff', () => {
    const retVal = sut.getAssociatedDemandAccountGroups();

    expect(retVal).toBeTruthy();
  });

  it('getAssociatedTypeOptions should array of associate Type', () => {
    const retVal = sut.getAssociatedTypeOptions({} as any, { addProtectionAccountTypes: ['data1'] } as any, {} as any);
    expect(retVal).toStrictEqual(['data1']);
  });

  it('getCustomerAccountFunction should array of associate Type', () => {
    const retVal = sut.getCustomerAccountFunction({} as any, { customerAccountFunctions: ['data1'] } as any, {} as any);
    expect(retVal).toStrictEqual(['data1']);
  });

  it('getAccountTypes should array of associate Type', () => {
    const retVal = sut.getAccountTypes({} as any, { addAccountTypes: ['data1'] } as any, {} as any);
    expect(retVal).toStrictEqual(['data1']);
  });

  it('getAssociatedTypeOptions should empty array', () => {
    const retVal = sut.getAssociatedTypeOptions({} as any, {} as any, {} as any);
    expect(retVal).toStrictEqual([]);
  });

  it('getCustomerAccountFunction should empty array', () => {
    const retVal = sut.getCustomerAccountFunction({} as any, { } as any, {} as any);
    expect(retVal).toStrictEqual([]);
  });

  it('getAccountTypes should empty array', () => {
    const retVal = sut.getAccountTypes({} as any, { } as any, {} as any);
    expect(retVal).toStrictEqual([]);
  });

  it('selectCustomerAcccount should update dropdown value of account type', () => {
    const field={form:{get:jest.fn(
      ()=>{
        setValue:jest.fn().mockReturnValueOnce(true);
      }
    )},templateOptions:{options:[{value:'123'}]}} as any;
    const retVal = sut.selectCustomerAcccount(field, { value:'123'} as any);
    expect(field.form.get).toBeCalledTimes(1);
  });

  it('getAssociatedDemandAccountGroups returns the right form group structure', () => {
    const fields = sut.getAssociatedDemandAccountGroups();

    expect(fields.length).toBe(1);
    expect(fields[0].fieldGroup?.length).toBe(3);
  });
});
