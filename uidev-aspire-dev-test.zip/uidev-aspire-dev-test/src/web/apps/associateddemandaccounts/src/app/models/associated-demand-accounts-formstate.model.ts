import { PageMode } from '@uid/uid-models';
import { AccountFunction } from './account-function.model';
import { InquiryType } from './inquiry-type.model';

export interface AssociatedDemandAccountFormState {
    addProtectionAccountTypes: InquiryType[];
    customerAccountFunctions: AccountFunction[];
    addAccountTypes: InquiryType[];
    editMode: PageMode;
};
