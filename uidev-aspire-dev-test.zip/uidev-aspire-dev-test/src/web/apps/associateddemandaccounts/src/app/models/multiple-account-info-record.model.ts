export interface MultipleAccountInfoRecord {
    accountDescription: string;
    accountStatus: string;
    acctId: string;
    acctType: string;
    currentBalance: number;
    amount: number;
    multipleAcctTypeDesc: string;
    originalAccountType: string;
    personName: string;
};
