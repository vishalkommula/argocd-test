import {ButtonRendererClickParms} from '@uid/uid-angular-controls';
import {AssociatedDemandAccountsGridColDef} from './associateddemandaccount-grid-col.def';

jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

let sut: AssociatedDemandAccountsGridColDef;

describe('AssociatedDemandAccountGridColDef', () => {
    beforeEach(() => {
        sut = new AssociatedDemandAccountsGridColDef();
    });

    it('service should be created', () => {
        expect(sut).toBeTruthy();
    });

    it('amountFormatter returns \'\' on falsy input', () => {
        expect(sut.amountFormatter(false)).toBe('');
        expect(sut.amountFormatter({data: false})).toBe('');
    });

    it('amountFormatter shows data as inside bracket for negative amount', () => {
        const event = {
            data: {
                currentBalance: -200
            }
        };
        expect(sut.amountFormatter(event)).toBe('($200.00)');
    });

    it('amountFormatter shows data as $200', () => {
        const event = {
            data: {
                currentBalance: 200
            }
        };
        expect(sut.amountFormatter(event)).toBe('$200.00');
    });

    it('for now, onDelete just cover them up', () => {
        (<any>window).console = {log: jest.fn()};
        sut.onDelete({} as ButtonRendererClickParms);
        expect(console.log).toBeCalledTimes(1);
    });

});
