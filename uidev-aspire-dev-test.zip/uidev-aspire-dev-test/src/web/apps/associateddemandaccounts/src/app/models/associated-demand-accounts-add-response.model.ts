import { SearchMessageRequestHeaderModel } from '@uid/uid-models';
import { AccountFunction } from './account-function.model';
import { InquiryType } from './inquiry-type.model';


export interface AssociatedDemandAccountsAddResponse {
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    customerAccountFunctions: AccountFunction[];
    addAccountTypes: InquiryType[];
};
