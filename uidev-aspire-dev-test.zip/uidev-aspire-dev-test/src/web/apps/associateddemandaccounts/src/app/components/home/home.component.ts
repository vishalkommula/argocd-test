import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
// store
import * as AssociatedDemandAccountsActions from '../../store/action/associateddemandaccounts.action';
import * as AssociatedDemandAccountsSelector from '../../store/selector/associateddemandaccounts.selector';
// ag grid
import { ColDef, GridOptions, GridReadyEvent, GridSizeChangedEvent, PaginationChangedEvent, RowDoubleClickedEvent, RowGroupingDisplayType, RowSelectedEvent, SideBarDef } from 'ag-grid-community';
// libs
import { UidGridAngular } from '@uid/uid-directives';
import { ButtonRendererClickParms, ButtonRendererComponent, ButtonRendererModel, SelectedFaultError } from '@uid/uid-angular-controls';
import { FaultArrayMessages, FaultMsgRec, PageMode } from '@uid/uid-models';
// store
import { Store } from '@ngrx/store';
// models
import { InquiryType } from '../../models/inquiry-type.model';
import { MultipleAccountInfoRecord } from '../../models/multiple-account-info-record.model';
import { AccountFunction } from '../../models/account-function.model';
import { AssociatedDeamdnAccountValueType } from '../../models/associated-demand-accounts.enum';
import { AssociatedDemandAccountsGridColDef } from './associateddemandaccount-grid-col.def';
import { AssociatedDemandAccountsModRequest } from '../../models/associated-demand-accounts-mod-request.model';
import { getAssociatedDemandAccountGroups } from '../associateddemandaccount/associateddemandaccount.function';
import { FormlyFormOptions } from '@ngx-formly/core';
import { AssociatedDemandAccountsAddRequest } from '../../models/associated-demand-accounts-add-request.model';
import { AssociatedDemandAccountFormModel } from '../../models/associated-demand-accounts-form.model';
import { AccountInfo } from '../../models/account-info.model';

@Component({
  selector: 'uid-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit, OnDestroy {
  @ViewChild('uidGrid')
  uidGrid = {} as UidGridAngular;

  public groupDisplayType: RowGroupingDisplayType = 'groupRows';
  groupDefaultExpanded = 0;

  associatedDemandAccountValueTypes = AssociatedDeamdnAccountValueType;
  pageModeEnum = PageMode;

  associatedDemandAccountsActions = AssociatedDemandAccountsActions;
  associatedDemandAccountsSelectors = AssociatedDemandAccountsSelector;
  // formly field config
  associatedDemandAccountGroups = getAssociatedDemandAccountGroups();
  formRendererOptions$!: Observable<FormlyFormOptions>;

  protectionAccountInfoRecords$!: Observable<MultipleAccountInfoRecord[]>;
  addProtectionAccountTypes$!: Observable<InquiryType[]>;
  addAccountTypes$!: Observable<InquiryType[]>;
  customerAccountFunctions$!: Observable<AccountFunction[]>;
  pageMode$!: Observable<any>;
  faultArrayMessages$!: Observable<FaultArrayMessages>;

  defaultColDef!: ColDef;
  columnDefs!: ColDef[];
  gridOptions!: GridOptions;
  sideBar!: SideBarDef;
  pageSize = 25;
  // this property is defined with partial model since associatedType property is set with initial value.
  associatedDemandAccountFormModel!: Partial<AssociatedDemandAccountFormModel>;

  frameworkComponents = {
    buttonRenderer: ButtonRendererComponent,
  };

  subs: Subscription[] = [];

  // showDialogBox displays the dialog box on cancel click and delete click .
  showDialogBox = false;
  // generic dialog box title display for delete and cancel click.
  dialogBoxTitle = '';
  // dialogBoxType defines the type of dialogbox like delete and cencel.
  dialogBoxType = '';
  // dialogBoxText contains the body of dialog box
  dialogBoxText: string[] = [];

  // this property is used to refer the added accounttype for protection account type.
  protectionAccountInfoRecords!: MultipleAccountInfoRecord[];

  showOverrideDialogBox = false;
  // this property used to show the unsaved dialog box.
  showUnsaveDialogBox = false;
  // this property holds the current row Index
  currentRowIndex = -1;
  // this property helps to show validation error.
  showValidationError = false;
  // this property holds the body of validation error message.
  validationErrorMessage = '';

  constructor(private store: Store, gridDef: AssociatedDemandAccountsGridColDef) {
    this.defaultColDef = gridDef.default;
    this.columnDefs = gridDef.columns;
    this.gridOptions = gridDef.gridOptions;

    this.protectionAccountInfoRecords$ = this.store.select(this.associatedDemandAccountsSelectors.selectProtectionAccountInfoRecords);
    this.addProtectionAccountTypes$ = this.store.select(this.associatedDemandAccountsSelectors.selectAddProtectionAccountTypes);
    this.addAccountTypes$ = this.store.select(this.associatedDemandAccountsSelectors.selectAddAccountTypes);
    this.customerAccountFunctions$ = this.store.select(this.associatedDemandAccountsSelectors.selectCustomerAccountFunctions);
    this.pageMode$ = this.store.select(this.associatedDemandAccountsSelectors.selectPageMode);
    // formly options.
    this.formRendererOptions$ = this.store.select(this.associatedDemandAccountsSelectors.selectFormlyOptions);
    this.faultArrayMessages$ = this.store.select(this.associatedDemandAccountsSelectors.selectFaultMessages);
    this.mapGridButtons(gridDef);
    this.mapOnChangeFormFunction();
  }

  ngOnInit(): void {
    const subFaultArrayMessage = this.faultArrayMessages$.subscribe((faultMsgs) => {
      if (faultMsgs !== undefined) {
        this.showOverrideDialogBox = faultMsgs.errorArray.length < 1 && faultMsgs.faultArray.length > 0;
      }
    });
    const subProtectionAccountInfoRecords = this.protectionAccountInfoRecords$.subscribe((accountInfoRecords) => {
      if (accountInfoRecords !== undefined) {
        this.protectionAccountInfoRecords = accountInfoRecords;
      }
    });

    this.subs.push(subFaultArrayMessage, subProtectionAccountInfoRecords);

    this.store.dispatch(this.associatedDemandAccountsActions.getAssociatedDemandAccountRecords({ request: {} as any }));
  }

  ngOnDestroy(): void {
    this.subs.forEach((sub) => sub.unsubscribe());
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
    event.api.sizeColumnsToFit();
  }

  onGridReady(event: GridReadyEvent) {
    if (!event || !event.api || !this.uidGrid) {
      return;
    }
    event.api.closeToolPanel();
    event.api.sizeColumnsToFit();
  }

  onRowSelected(event: RowSelectedEvent) {
    // if the selected node is grouped node, the first child node will be selected by default
    if (event.node.group) {
      event.node.setSelected(false);
      if (event.node.rowIndex !== null) {
        this.uidGrid.uidApi.selectRecord(event.node.rowIndex + 1);
      }
      return;
    }
    if (event.node.isSelected()) {
      this.currentRowIndex = event.rowIndex ?? 0;
    }
  }

  forceHighlightSelectedGridRow() {
    this.uidGrid.uidApi?.selectRecord(0);
  }
  // mapping onchange function of drop down change.
  mapOnChangeFormFunction() {
    const associatedTypeFieldConfig = this.associatedDemandAccountGroups[0].fieldGroup?.find((x) => x.key === 'associatedType');
    // assign current function and instance to formly.
    if (associatedTypeFieldConfig?.templateOptions) {
      associatedTypeFieldConfig.templateOptions.change = this.getAddAssociatedTypeDropDownOptions;
      associatedTypeFieldConfig.templateOptions.change = associatedTypeFieldConfig.templateOptions.change.bind(this);
    }
  }

  // mapping the button click to delete function.
  mapGridButtons(gridDef: AssociatedDemandAccountsGridColDef): void {
    const deleteButton = gridDef.buttonRendererList.find((x: ButtonRendererModel) => x.iconType === 'delete');

    if (deleteButton) {
      deleteButton.onClick = this.deleteButtonClick.bind(this);
    }
  }
  // this event executes on click of view button in grid which nagivates to details screen
  deleteButtonClick(e: ButtonRendererClickParms) {
    if (e.rowIndex !== null && e.rowIndex !== undefined && this.uidGrid && this.uidGrid.uidApi) {
      this.uidGrid.uidApi.selectRecord(e.rowIndex);
    }
    this.dialogBoxType = this.associatedDemandAccountValueTypes.deleteMsg;
    this.dialogBoxTitle = this.associatedDemandAccountValueTypes.deleteDialogBoxTitle;
    this.dialogBoxText = [];
    this.showDialogBox = true;
  }

  cancelButton() {
    this.dialogBoxType = this.associatedDemandAccountValueTypes.cancelMsg;
    this.dialogBoxTitle = this.associatedDemandAccountValueTypes.cancelDialogBoxTitle;
    this.dialogBoxText = [];
    this.dialogBoxText.push(this.associatedDemandAccountValueTypes.cancelDialogBoxText);
    this.showDialogBox = true;
  }
  addAssociatedDemandAccountsRecord() {
    // resetting the validation error message.
    this.validationErrorMessage = '';
    this.associatedDemandAccountFormModel = {
      associatedType: 'ProtectionAccount',
      accountType: null,
    };
    // the call to get dropdown values are blocked when associatedType is null but add screen is not stopped display.
    if (this.associatedDemandAccountFormModel !== undefined && this.associatedDemandAccountFormModel.associatedType !== undefined && this.associatedDemandAccountFormModel.associatedType != null) {
      const addAssociatedDemandAccountRequest: AssociatedDemandAccountsAddRequest = {
        srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
        acctId: '12',
        acctType: 'A',
        associatedAccountType: this.associatedDemandAccountFormModel.associatedType ?? '',
      };
      this.store.dispatch(this.associatedDemandAccountsActions.getAddDropDownsValues({ request: addAssociatedDemandAccountRequest }));
    }
    // default add screen is display
    this.store.dispatch(this.associatedDemandAccountsActions.togglePageMode({ pageMode: this.pageModeEnum.Add }));
  }

  // this function is used to dispatch delete action
  deleteAssociatedDemandAccountsRecord(faultArrayMessages: FaultMsgRec[] = []) {
    const associatedAccountType = this.uidGrid.api.getDisplayedRowAtIndex(this.currentRowIndex)?.data?.multipleAcctTypeDesc;
    const associatedAcctId = this.uidGrid.api.getDisplayedRowAtIndex(this.currentRowIndex)?.data?.acctId;
    const associatedAcctType = this.uidGrid.api.getDisplayedRowAtIndex(this.currentRowIndex)?.data?.acctType;

    const deleteAssociatedDemandAccounts: AssociatedDemandAccountsModRequest = {
      srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
      acctId: '12',
      acctType: 'A',
      associatedAccountInfoRecords: [{ accId: associatedAcctId, acctType: associatedAcctType }],
      associatedAccountType: associatedAccountType,
      dlt: true,
      errOvrRdInfoArray: faultArrayMessages,
    };
    this.store.dispatch(this.associatedDemandAccountsActions.deleteAssociatedDemandAccount({ request: deleteAssociatedDemandAccounts }));
  }
  // this condition executes on click of save in add and edit screen. faultArray is passed when user selected the
  // fault error messages displayed in override dialog box.
  saveAssociatedDemandAccounts(faultArrayMessages: FaultMsgRec[] = []) {
    // resetting the validation error message.
    this.validationErrorMessage = '';
    // validate if account info is selected.
    // checking both accID and account Type is empty
    if (
      (! this.associatedDemandAccountFormModel.accId) &&
      (! this.associatedDemandAccountFormModel.accountType)
    ) {
      this.validationErrorMessage = 'Account Id and Account Type are required.';
      return;
    }
    // checking both accID is empty
    if (!this.associatedDemandAccountFormModel.accId) {
      this.validationErrorMessage = 'Account Id is required.';
      return;
    }
    // checking both accID is empty
    if (! this.associatedDemandAccountFormModel.accountType) {
      this.validationErrorMessage = 'Account Type is required.';
      return;
    }
    const accountInfo: AccountInfo[] = [];
    // validate already account Id is added to protection type.
    if (this.associatedDemandAccountFormModel.associatedType === this.associatedDemandAccountValueTypes.protectionAccount) {
      const protectionTypes = this.protectionAccountInfoRecords.filter((x) => x.multipleAcctTypeDesc === this.associatedDemandAccountValueTypes.protectionAccountDesc);
      if (protectionTypes !== undefined && protectionTypes.length > 0) {
        const arrayAccountInfo = protectionTypes.map((v) => ({ accId: v.acctId, acctType: v.acctType }));
        accountInfo.push(...arrayAccountInfo);
      }
      // blocking save when same accountID is added to protection Account
      if (accountInfo.find((x) => x.accId === this.associatedDemandAccountFormModel.accId)) {
        this.validationErrorMessage = 'Account ' + this.associatedDemandAccountFormModel.accId + ' has already been added.';
        return;
      }
    }
    accountInfo.push({ accId: this.associatedDemandAccountFormModel.accId ?? '', acctType: this.associatedDemandAccountFormModel.associatedType ?? '' });

    const addAssociatedDemandAccounts: AssociatedDemandAccountsModRequest = {
      srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
      acctId: '12',
      acctType: 'A',
      associatedAccountInfoRecords: accountInfo ?? [],
      associatedAccountType: this.associatedDemandAccountFormModel.associatedType ?? '',
      dlt: false,
      errOvrRdInfoArray: faultArrayMessages,
    };
    this.store.dispatch(
      this.associatedDemandAccountsActions.addAssociatedDemandAccount({
        request: addAssociatedDemandAccounts,
      })
    );
  }

  dialogBoxClose(e: any) {
    if (e.detail === this.associatedDemandAccountValueTypes.deleteMsg) {
      this.deleteAssociatedDemandAccountsRecord();
    }
    if (e.detail === this.associatedDemandAccountValueTypes.donotSave) {
      this.store.dispatch(this.associatedDemandAccountsActions.togglePageMode({ pageMode: this.pageModeEnum.Inquiry }));
    }
    this.showDialogBox = false;
  }
  // this event will execute before closing of override dialog box
  // TODO : complete functionality for override dailog box will be implemented when screen is integrated with api.
  overridedialogBoxClose(selectedFaultError: SelectedFaultError) {
    if (selectedFaultError.clickAction === this.associatedDemandAccountValueTypes.overrideMsg) {
      this.saveAssociatedDemandAccounts(selectedFaultError.faultRecInfoArray);
    } else if (selectedFaultError.clickAction === this.associatedDemandAccountValueTypes.cancelMsg) {
      // resetting fault error message in store to show the override dialogbox for same error message again.
      // override dialogbox will not display if same error message is stored again in ngrx store.
      this.store.dispatch(this.associatedDemandAccountsActions.addFaultRecMessages({ faultRec: [] }));
    }
    this.showOverrideDialogBox = false;
  }
  // api call for getting dropdown info
  getAddAssociatedTypeDropDownOptions(field: any, $event: any) {
    const associatedAcctType = $event.value;
    const addAssociatedDemandAccountRequest: AssociatedDemandAccountsAddRequest = {
      srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
      acctId: '12',
      acctType: 'A',
      associatedAccountType: associatedAcctType,
    };
    this.store.dispatch(this.associatedDemandAccountsActions.getAddDropDownsValues({ request: addAssociatedDemandAccountRequest }));
  }
}
