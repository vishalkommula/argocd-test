export interface AccountInfo {
    accId: string;
    acctType: string;
};
