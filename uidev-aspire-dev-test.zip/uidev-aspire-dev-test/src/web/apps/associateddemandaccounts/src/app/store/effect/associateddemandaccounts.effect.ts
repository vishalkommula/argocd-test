/* eslint-disable arrow-body-style */
import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { catchError, map, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';
import * as AssociatedDemandAccountsActions from '../action/associateddemandaccounts.action';
import { DataService } from '../../service/data.service';

@Injectable()
export class AssociatedDemandAccountsEffects {
  constructor(private dataService: DataService, private actions$: Actions) {}

  loadAssociatedDemandAccountsResponse$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AssociatedDemandAccountsActions.getAssociatedDemandAccountRecords),
      switchMap((action) =>
        this.dataService.getAssociatedDemandAccountDetails(action.request).pipe(
          map((response) =>{
            return AssociatedDemandAccountsActions.associatedDemandAccountRetrieved({
                response,
              });
          }),
          catchError((error) =>
            of(
              AssociatedDemandAccountsActions.associatedDemandAccountFailure({
                error,
              })
            )
          )
        )
      )
    );
  });

  loadAddDropDownsValues$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AssociatedDemandAccountsActions.getAddDropDownsValues),
      switchMap((action) =>
        this.dataService.getAddAssociatedDemandAccountDropDownValues(action.request).pipe(
            map((response) =>{
                return AssociatedDemandAccountsActions.getAddDropDownsValuesRetrieved({
                    response,
                  });
              }),
          catchError((error) =>
            of(
              AssociatedDemandAccountsActions.getAddDropDownsValuesFailure({
                error,
              })
            )
          )
        )
      )
    );
  });

  addAssociatedDemandAccount$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AssociatedDemandAccountsActions.addAssociatedDemandAccount),
      switchMap((action) =>
        this.dataService.addAssociatedDemandAccount(action.request).pipe(
          switchMap((response) => {
            const actionsToDispatch = [];
            if (response.faultRecInfoArray && response.faultRecInfoArray !== null && response.faultRecInfoArray.length > 0) {
              actionsToDispatch.push(AssociatedDemandAccountsActions.addFaultRecMessages({ faultRec: response.faultRecInfoArray }));
            } else {
              actionsToDispatch.push(AssociatedDemandAccountsActions.addAssociatedDemandAccountSuccess({ response }));
            }
            return actionsToDispatch;
          }),
          catchError((error) =>
            of(
              AssociatedDemandAccountsActions.addAssociatedDemandAccountFailure({
                error,
              })
            )
          )
        )
      )
    );
  });

  deleteAssociatedDemandAccount$ = createEffect(() => {
    return this.actions$.pipe(
      ofType(AssociatedDemandAccountsActions.deleteAssociatedDemandAccount),
      switchMap((action) =>
        this.dataService.deleteAssociatedDemandAccount(action.request).pipe(
          switchMap((response) => {
            const actionsToDispatch = [];
            if (response.faultRecInfoArray && response.faultRecInfoArray !== null && response.faultRecInfoArray.length > 0) {
              actionsToDispatch.push(AssociatedDemandAccountsActions.addFaultRecMessages({ faultRec: response.faultRecInfoArray }));
            } else {
              actionsToDispatch.push(AssociatedDemandAccountsActions.deleteAssociatedDemandAccountSuccess({ response }));
            }
            return actionsToDispatch;
          }),
          catchError((error) =>
            of(
              AssociatedDemandAccountsActions.deleteAssociatedDemandAccountFailure({
                error,
              })
            )
          )
        )
      )
    );
  });
};
