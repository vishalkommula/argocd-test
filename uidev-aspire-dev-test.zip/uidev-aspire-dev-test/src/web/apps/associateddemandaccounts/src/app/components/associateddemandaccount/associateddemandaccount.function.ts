import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormDataTypeEnum } from '@uid/uid-angular-controls';
import { AccountFunction } from '../../models/account-function.model';
import { AssociatedDemandAccountFormModel } from '../../models/associated-demand-accounts-form.model';
import { AssociatedDemandAccountFormState } from '../../models/associated-demand-accounts-formstate.model';
import { AssociatedDemandAccountFormDateTypeEnum } from '../../models/associated-demand-accounts.enum';
import { InquiryType } from '../../models/inquiry-type.model';

export const getAssociatedTypeOptions =function (model: AssociatedDemandAccountFormModel, formState: AssociatedDemandAccountFormState, field?: FormlyFieldConfig): InquiryType[] {
  return formState.addProtectionAccountTypes ?? [];
};

export const getCustomerAccountFunction =function (model: AssociatedDemandAccountFormModel, formState: AssociatedDemandAccountFormState, field?: FormlyFieldConfig): AccountFunction[] {
  return formState.customerAccountFunctions ?? [];
};

export const getAccountTypes =function (model: AssociatedDemandAccountFormModel, formState: AssociatedDemandAccountFormState, field?: FormlyFieldConfig): InquiryType[] {
  return formState.addAccountTypes ?? [];
};

export const selectCustomerAcccount=function(field: any, $event: any){
    // setting the accountTye while changing the selectedCustomerAccount
    const selectedAccount=$event.value;
      const accountInfo=field.templateOptions.options.find((x: AccountFunction)=>x.accId===selectedAccount);
    if(accountInfo!=null && accountInfo !== undefined){
      field?.form?.get('accountType')?.setValue(accountInfo.acctType);
    }else{
      field?.form?.get('accountType')?.setValue(null);
    }
};

export function getAssociatedDemandAccountGroups(): FormlyFieldConfig[] {
  return [
    {
        wrappers: ['record-detail-block'],
        fieldGroup: [
          {
            key: 'associatedType',
            wrappers: ['form-field'],
            templateOptions: {
              label: 'Associated Account Type',
              labelProp:'displayName',
              labelClasses:'col-md-6',
              valueClasses:'col-md-6',
              valueProp:'typeCode',
              style:{'width':'100%'},
            },
            expressionProperties:{
              'templateOptions.options':getAssociatedTypeOptions
            },
            type: FormDataTypeEnum.dropdown,
          },
          {
            key: 'accId',
            wrappers: ['form-field'],
            templateOptions: {
              label: 'Account',
              labelClasses:'col-md-6',
              valueClasses:'col-md-6',
              editable:true,
              optionLabel:'accId',
              maxlength:16,
              actionButtonIconType:'ellipsis',
              valueProp:'accId',
              optionValue:'accId',
              style:{'width':'100%','height':'100%'},
              change: selectCustomerAcccount
            },
            expressionProperties:{
              'templateOptions.options':getCustomerAccountFunction
            },
            type: AssociatedDemandAccountFormDateTypeEnum.accountInfoDropdown,
          },
          {
            key: 'accountType',
            wrappers: ['form-field'],
            templateOptions: {
              label: '',
              labelProp:'displayName',
              labelClasses:'col-md-6',
              valueClasses:'col-md-5 account-type',
              valueProp:'typeCode',
              style:{'width':'100%'},
            },
            expressionProperties:{
              'templateOptions.options':getAccountTypes
            },
            type: FormDataTypeEnum.dropdown,
          },
        ],
    },
  ];
}

