import { createFeatureSelector, createSelector } from '@ngrx/store';
import { FormlyFormOptions } from '@ngx-formly/core';
import { formatFaultMessages } from '@uid/uid-utilities';
import { AssociatedDemandAccountFormState } from '../../models/associated-demand-accounts-formstate.model';
// models
import { AssociatedDemandAccountsState } from '../state/associateddemandaccounts.state';

export const selectRoot = createFeatureSelector<AssociatedDemandAccountsState>('associatedDemandAccounts');

export const selectProtectionAccountInfoRecords = createSelector(selectRoot, (state) => state.associateDemandAccountResponse.protectionAccountInfoRecords);

export const selectAddProtectionAccountTypes = createSelector(selectRoot, (state) => state.associateDemandAccountResponse.addProtectionAccountTypes);

export const selectAddAccountTypes = createSelector(selectRoot, (state) => state.associatedDemandAccountAddResponse.addAccountTypes);

export const selectCustomerAccountFunctions = createSelector(selectRoot, (state) => state.associatedDemandAccountAddResponse.customerAccountFunctions);


export const selectFaultRecArray = createSelector(selectRoot, (state) => state.faultRecInfoArray);

export const selectShowACHAutoReturn = createSelector(selectRoot, (state) => state.associateDemandAccountResponse.showACHAutoReturn);

export const selectPageMode = createSelector(selectRoot, (state) => state.pageMode);

export const selectAssociatedDemandAccountsSearchMessageResponseHeader = createSelector(selectRoot, (state) => state.associateDemandAccountResponse?.srchMsgRsHdr);

export const selectFaultMessages = createSelector(selectFaultRecArray, formatFaultMessages);

export const selectFormlyOptions = createSelector(selectAddProtectionAccountTypes,
    selectCustomerAccountFunctions,selectPageMode, selectAddAccountTypes,
    (addProtectionAccountTypes, customerAccountFunctions, pageMode,addAccountTypes) => {
    const formState: AssociatedDemandAccountFormState = {
    addProtectionAccountTypes,
    customerAccountFunctions,
    editMode:pageMode,
    addAccountTypes
  };
  return formState as FormlyFormOptions;
});
