import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface AssociatedDemandAccountsSearchRequest {
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
};
