import { PageMode } from '@uid/uid-models';
import * as Selectors from '../selector/associateddemandaccounts.selector';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

describe('Associated Demand Accounts Selectors Tests', () => {

  it('selectPageMode should project editMode', () => {
    const result = Selectors.selectPageMode.projector({pageMode:PageMode.Inquiry});

    expect(result).toBe(PageMode.Inquiry);
  });

  it('selectAssociatedDemandAccountsSearchMessageResponseHeader should header message', () => {
    const result = Selectors.selectAssociatedDemandAccountsSearchMessageResponseHeader.projector
    ({associateDemandAccountResponse:{srchMsgRsHdr:{header:1}}});

    expect(result).toStrictEqual({header:1});
  });

  it('selectFaultRecArray should project faultRecArray', () => {
    const state = { faultRecInfoArray: { errorCode: 'hello header'} };
    const result = Selectors.selectFaultRecArray.projector(state);

    expect(result).toMatchSnapshot();
  });

  it('selectFormlyOptions should project an options object', () => {
    const testFormlyOptions={
      addProtectionAccountTypes:{data:'data3'},
      customerAccountFunctions: {data:'data1'},
      editMode:PageMode.Add,
      addAccountTypes:{data:'data2'},
    };
    const result = Selectors.selectFormlyOptions.projector({data:'data3'},
    {data:'data1'},PageMode.Add,{data:'data2'});

    expect(result).toStrictEqual(testFormlyOptions);
  });

  it('selectFaultMessages should project faultRecArray', () => {
    const state = { faultRecInfoArray: { errorArray: [],faultArray:[] } };
    const result = Selectors.selectFaultMessages.projector(state);

    expect(result).toStrictEqual({ errorArray: [],faultArray:[] });
  });

  it('selectAddProtectionAccountTypes should project test array', () => {
    const state = { associateDemandAccountResponse: { addProtectionAccountTypes: [1,2,3]} };
    const result = Selectors.selectAddProtectionAccountTypes.projector(state);

    expect(result).toEqual([1,2,3]);
  });

  it('selectProtectionAccountInfoRecords should project test array', () => {
    const state = { associateDemandAccountResponse: { protectionAccountInfoRecords: [1,2,3]} };
    const result = Selectors.selectProtectionAccountInfoRecords.projector(state);

    expect(result).toEqual([1,2,3]);
  });

  it('selectAddAccountTypes should project test array', () => {
    const state = { associatedDemandAccountAddResponse: { addAccountTypes: [1,2,3]} };
    const result = Selectors.selectAddAccountTypes.projector(state);

    expect(result).toEqual([1,2,3]);
  });

  it('selectCustomerAccountFunctions should project test array', () => {
    const state = { associatedDemandAccountAddResponse: { customerAccountFunctions: [1,2,3]} };
    const result = Selectors.selectCustomerAccountFunctions.projector(state);

    expect(result).toEqual([1,2,3]);
  });

  it('selectShowACHAutoReturn should project test array', () => {
    const state = { associateDemandAccountResponse: { showACHAutoReturn: true} };
    const result = Selectors.selectShowACHAutoReturn.projector(state);

    expect(result).toBe(true);
  });
});
