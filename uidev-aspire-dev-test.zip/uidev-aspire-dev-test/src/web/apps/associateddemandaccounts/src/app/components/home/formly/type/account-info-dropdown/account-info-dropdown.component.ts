import { Component, OnInit } from '@angular/core';
import { FieldType, FieldTypeConfig } from '@ngx-formly/core';

@Component({
  selector: 'uid-account-info-dropdown',
  templateUrl: './account-info-dropdown.component.html',
  styles: [`
  :host ::ng-deep .minWidthOverride{
    min-width: 525px !important;
    font-size: 14px;
}

.icon-text {
    flex: 1 0 0%;
}
  `],
})
export class AccountInfoDropdownComponent extends FieldType<FieldTypeConfig> implements OnInit {
  optionsData!: any;

  constructor() {
    super();
  }

  ngOnInit() {
    this.optionsData = this.to.options;
  }
}
