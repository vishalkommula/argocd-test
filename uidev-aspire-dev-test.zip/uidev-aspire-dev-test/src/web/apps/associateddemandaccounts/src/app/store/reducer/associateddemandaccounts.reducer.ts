/* eslint-disable arrow-body-style */
import { createReducer, on } from '@ngrx/store';
import * as AssociatedDemandAccountsActions from '../action/associateddemandaccounts.action';
// models
import { PageMode } from '@uid/uid-models';
import { AssociatedDemandAccountsAddResponse } from '../../models/associated-demand-accounts-add-response.model';
import { AssociatedDemandAccountsSearchResponseModel } from '../../models/associated-demand-accounts-search-response.model';
import { AssociatedDemandAccountsState } from '../state/associateddemandaccounts.state';

export const initialState: AssociatedDemandAccountsState = {
  associateDemandAccountResponse: {} as AssociatedDemandAccountsSearchResponseModel,
  associatedDemandAccountAddResponse: {} as AssociatedDemandAccountsAddResponse,
  pageMode: PageMode.Inquiry,
  faultRecInfoArray: [],
};

export const reducer = createReducer(
  initialState,
  on(AssociatedDemandAccountsActions.associatedDemandAccountRetrieved, (state, action): AssociatedDemandAccountsState => {
    return {
      ...state,
      associateDemandAccountResponse: action.response,
      associatedDemandAccountAddResponse: {} as AssociatedDemandAccountsAddResponse,
      pageMode: PageMode.Inquiry,
      faultRecInfoArray: [],
    };
  }),
  on(AssociatedDemandAccountsActions.getAddDropDownsValuesRetrieved, (state, action): AssociatedDemandAccountsState => {
    return {
      ...state,
      associatedDemandAccountAddResponse: action.response,
    };
  }),
  on(AssociatedDemandAccountsActions.togglePageMode, (state, action): AssociatedDemandAccountsState => {
    return {
      ...state,
      pageMode: action.pageMode,
      faultRecInfoArray: [],
    };
  }),
  on(AssociatedDemandAccountsActions.deleteAssociatedDemandAccountSuccess, (state, action): AssociatedDemandAccountsState => {
    return {
      ...state,
      associateDemandAccountResponse: {
        ...state.associateDemandAccountResponse,
        srchMsgRsHdr:action.response.srchMsgRsHdr,
        addProtectionAccountTypes:action.response.addProtectionAccountTypes,
        protectionAccountInfoRecords:action.response.protectionAccountInfoRecords
      },
      faultRecInfoArray: [],
    };
  }),
  on(AssociatedDemandAccountsActions.addAssociatedDemandAccountSuccess, (state, action): AssociatedDemandAccountsState => {
    return {
        ...state,
        associateDemandAccountResponse: {
          ...state.associateDemandAccountResponse,
          srchMsgRsHdr:action.response.srchMsgRsHdr,
          addProtectionAccountTypes:action.response.addProtectionAccountTypes,
          protectionAccountInfoRecords:action.response.protectionAccountInfoRecords
        },
        pageMode:PageMode.Inquiry,
        faultRecInfoArray: [],
      };
  }),
  on(AssociatedDemandAccountsActions.addFaultRecMessages, (state, action): AssociatedDemandAccountsState => {
    return {
      ...state,
      faultRecInfoArray: action.faultRec,
    };
  }),
);
