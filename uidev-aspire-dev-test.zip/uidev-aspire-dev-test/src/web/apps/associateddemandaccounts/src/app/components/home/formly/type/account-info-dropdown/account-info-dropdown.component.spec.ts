import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountInfoDropdownComponent } from './account-info-dropdown.component';

describe('AccountInfoDropdownComponent', () => {
  let component: AccountInfoDropdownComponent;
  it('AccountInfoDropdownComponent should be created', () => {
    component = new AccountInfoDropdownComponent();

    expect(component).toBeTruthy();
  });

  // it('ngOnInit should call and assign the optionsData', () => {
  //  let  mockGenName = jest.spyOn(component,
  //     'to').mockImplemetation(() => 'franc');
  //   jest.spyOn(component, 'to', 'get').mockReturnValue({options:[1,2,3]});
  //   component.ngOnInit();
  //   expect(component.optionsData).toBe([1,2,3]);
  // });
});
