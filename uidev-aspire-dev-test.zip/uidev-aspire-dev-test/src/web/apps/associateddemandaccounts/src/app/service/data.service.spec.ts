import { DataService } from './data.service';

let service: DataService;

const httpMock = {
  get: jest.fn(),
  post: jest.fn()
};

describe('DataService', () => {
  beforeEach(() => {
    service = new DataService(httpMock as any);
  });

  it('service should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getAssociatedDemandAccountRecords returns modified mock data',()=>{
    expect(service.getAssociatedDemandAccountRecords).toBeInstanceOf(Object);
  });

  it('getAddAssociatedDemandAccountDropDownValues returns mocked data for Holding Account', async () => {
    expect(await service.getAddAssociatedDemandAccountDropDownValues
      ({associatedAccountType:'HoldingAccount'} as any).toPromise()).toBeTruthy();
  });

  it('getAddAssociatedDemandAccountDropDownValues returns mocked data for Debit Account', async () => {
    expect(await service.getAddAssociatedDemandAccountDropDownValues
      ({associatedAccountType:'Debit Account'} as any).toPromise()).toBeTruthy();
  });

  it('getAddAssociatedDemandAccountDropDownValues should call httpGet', async () => {
    expect(httpMock.get).toBeCalledTimes(0);
  });

  it('getAssociatedDemandAccountDetails returns mocked data', async () => {
    expect(await service.getAssociatedDemandAccountDetails({} as any).toPromise()).toBeTruthy();
  });

  it('getAssociatedDemandAccountDetails should call httpGet', async () => {
    expect(httpMock.get).toBeCalledTimes(0);
  });

  it('addAssociatedDemandAccount should call httpost', async () => {
    expect(httpMock.post).toBeCalledTimes(0);
  });

  it('addAssociatedDemandAccount returns mocked data', async () => {
    expect(await service.addAssociatedDemandAccount({errOvrRdInfoArray:[1,2]} as any).toPromise()).toBeTruthy();
  });

  it('deleteAssociatedDemandAccount  should call httpost', async () => {
    expect(httpMock.post).toBeCalledTimes(0);
  });

  it('deleteAssociatedDemandAccount returns mocked data', async () => {
    expect(await service.deleteAssociatedDemandAccount({} as any).toPromise()).toBeTruthy();
  });
});
