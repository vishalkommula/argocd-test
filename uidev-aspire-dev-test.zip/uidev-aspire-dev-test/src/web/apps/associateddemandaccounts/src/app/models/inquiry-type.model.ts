export interface InquiryType{
    displayName: string;
    typeCode: string;
    shortDesc: string;
    synergyCabinet: string;
    iconType: string;
};
