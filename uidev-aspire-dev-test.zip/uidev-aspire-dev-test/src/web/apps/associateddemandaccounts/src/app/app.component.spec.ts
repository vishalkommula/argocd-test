import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;
  it('AppComponent should be created', () => {
    component = new AppComponent();

    expect(component).toBeTruthy();
  });
});
