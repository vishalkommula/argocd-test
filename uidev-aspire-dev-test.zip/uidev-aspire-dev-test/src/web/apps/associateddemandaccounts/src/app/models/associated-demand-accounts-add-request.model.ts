import { SearchMessageRequestHeaderModel } from '@uid/uid-models';


export interface AssociatedDemandAccountsAddRequest {
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    associatedAccountType: string;
};
