import { FaultMsgRec, PageMode } from '@uid/uid-models';
import { AssociatedDemandAccountsAddResponse } from '../../models/associated-demand-accounts-add-response.model';
import { AssociatedDemandAccountsSearchResponseModel } from '../../models/associated-demand-accounts-search-response.model';


export interface AssociatedDemandAccountsState {
    // this property stores the multiple associated type accounts and add associated type which is
    // used to bind the associated account type in add associated account type.
    associateDemandAccountResponse: AssociatedDemandAccountsSearchResponseModel;
    // this property stores the drop down values of customFunctionAccount and Add account types.
    associatedDemandAccountAddResponse: AssociatedDemandAccountsAddResponse;
    pageMode: PageMode;
    faultRecInfoArray: FaultMsgRec[];
};
