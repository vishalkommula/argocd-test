import { Action, ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import * as AssociatedDemandAccountsActions from '../action/associateddemandaccounts.action';
import mockData from '../../mock-data/AssociatedDemandAccountsResponse.mock.json';
import { PageMode } from '@uid/uid-models';
import { AssociatedDemandAccountsEffects } from './associateddemandaccounts.effect';

jest.mock('@uid/uid-angular-controls', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

jest.mock('@ngrx/store', () => {
  const originalModule = jest.requireActual('@ngrx/store');

  return {
    ...originalModule,
    createSelector: jest.fn().mockReturnValue(('test'))
  };
});

const dataServiceMock = {
    getAssociatedDemandAccountDetails: () => of(mockData),
    getAddAssociatedDemandAccountDropDownValues:()=>of({}),
    deleteAssociatedDemandAccount: () => of({}),
    addAssociatedDemandAccount:() => of({}),
};

const dataServiceErrorMock = {
    getAssociatedDemandAccountDetails: () => throwError('Error Test'),
    getAddAssociatedDemandAccountDropDownValues:()=>throwError('Error Test'),
    deleteAssociatedDemandAccount: () => throwError('Error Test'),
    addAssociatedDemandAccount:() => throwError('Error Test'),
};

let actions: ActionsSubject;
let effects: AssociatedDemandAccountsEffects;

describe('Associated Demand Accounts Effects tests', () => {
  beforeEach(() => {
    actions = new ActionsSubject();
    effects = new AssociatedDemandAccountsEffects(dataServiceMock as any, actions);
  });

  it('loadAssociatedDemandAccountsResponse$ dispatches a associatedDemandAccountRetrieved action', () => {

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.loadAssociatedDemandAccountsResponse$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.getAssociatedDemandAccountRecords({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Associated Demand Account Records Retrieved');
  });

  it('loadAssociatedDemandAccountsResponse$ dispatches a error action', () => {
    effects = new AssociatedDemandAccountsEffects(dataServiceErrorMock as any, actions);

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.loadAssociatedDemandAccountsResponse$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.getAssociatedDemandAccountRecords({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Associated Demand Account Records Failure');
  });

  it('loadAddDropDownsValues$ dispatches a getAddDropDownsValuesRetrieved action', () => {

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.loadAddDropDownsValues$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.getAddDropDownsValues({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Get Add DropDowns Values Retrieved');
  });

  it('loadAddDropDownsValues$ dispatches a error action', () => {
    effects = new AssociatedDemandAccountsEffects(dataServiceErrorMock as any, actions);

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.loadAddDropDownsValues$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.getAddDropDownsValues({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Get Add DropDowns Values Failure');
  });

  it('deleteAssociatedDemandAccount$ dispatches a success action', () => {
    dataServiceMock.deleteAssociatedDemandAccount=()=>of({responseModel:[1,2]});
    effects = new AssociatedDemandAccountsEffects(dataServiceMock as any, actions);

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.deleteAssociatedDemandAccount$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.deleteAssociatedDemandAccount({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Delete Associated Demand Account Record Success');
  });


  it('deleteAssociatedDemandAccount$ dispatches a error action', () => {
    effects = new AssociatedDemandAccountsEffects(dataServiceErrorMock as any, actions);

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.deleteAssociatedDemandAccount$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.deleteAssociatedDemandAccount({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Delete Associated Demand Account Record Failure');
  });

  it('deleteAssociatedDemandAccount$ dispatches a success action with faultInfo Array', () => {
    dataServiceMock.deleteAssociatedDemandAccount=() => of({faultRecInfoArray:[1,2,3]});
    effects = new AssociatedDemandAccountsEffects(dataServiceMock as any, actions);

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.deleteAssociatedDemandAccount$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.deleteAssociatedDemandAccount({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Add FaultRecMessages To Store');
  });

  it('addAssociatedDemandAccount$ dispatches a success action', () => {
    dataServiceMock.addAssociatedDemandAccount=()=>of({responseModel:[1,2]});
    effects = new AssociatedDemandAccountsEffects(dataServiceMock as any, actions);

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.addAssociatedDemandAccount$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.addAssociatedDemandAccount({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Add Associated Demand Account Record Success');
  });

  it('addAssociatedDemandAccount$ dispatches a success action with faultInfo Array', () => {
    dataServiceMock.addAssociatedDemandAccount=() => of({faultRecInfoArray:[1,2,3]});
    effects = new AssociatedDemandAccountsEffects(dataServiceMock as any, actions);

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.addAssociatedDemandAccount$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.addAssociatedDemandAccount({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Add FaultRecMessages To Store');
  });

  it('addAssociatedDemandAccount$ dispatches a error action', () => {
    effects = new AssociatedDemandAccountsEffects(dataServiceErrorMock as any, actions);

    // Subscribe on the effect to catch emitted actions, which are used to assert the effect output
    const result: Action[] = [];
    effects.addAssociatedDemandAccount$.subscribe((actionResponse) => {
        result.push(actionResponse);
    });
    const action = AssociatedDemandAccountsActions.addAssociatedDemandAccount({} as any);
    actions.next(action);

    expect((result[0]).type).toBe('[Associated Demand Accounts] Add Associated Demand Account Record Failure');
  });

});

