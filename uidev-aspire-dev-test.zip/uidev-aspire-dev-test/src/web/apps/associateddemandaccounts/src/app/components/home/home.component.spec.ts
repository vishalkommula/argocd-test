/* eslint-disable @typescript-eslint/naming-convention */
import { AssociatedDeamdnAccountValueType } from '../../models/associated-demand-accounts.enum';
import { HomeComponent } from './home.component';
import { of } from 'rxjs';

jest.mock('@uid/uid-root-store', () => jest.fn());

jest.mock('../../store', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());

let sut: HomeComponent;

const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(),
};

const gridDefMock = {
  buttonRendererList: [
    {
      iconType: 'delete',
      onClick: null,
    },
  ],
};

const uidGridMock = {
  uidApi: {
    selectRecord: jest.fn(),
  },
};

const AssociatedDemandAccountsActionsMock = {
  getAssociatedDemandAccountRecords: jest.fn(),
  togglePageMode: jest.fn(),
  addFaultRecMessages: jest.fn(),
  deleteAssociatedDemandAccount: jest.fn(),
  addAssociatedDemandAccount: jest.fn(),
  getAddDropDownsValues: jest.fn(),
};

const AssociatedDemandAccountsSelectorMock = {
  selectPageMode: jest.fn(),
  selectProtectionAccountInfoRecords: jest.fn(),
  selectAddProtectionAccountTypes: jest.fn(),
  selectCustomerAccountFunctions: jest.fn(),
  selectAddAccountTypes: jest.fn(),
};

describe('HomeComponent', () => {
  beforeEach(() => {
    sut = new HomeComponent(storeMock as any, gridDefMock as any);
    sut.associatedDemandAccountsActions = AssociatedDemandAccountsActionsMock as any;
    sut.associatedDemandAccountsSelectors = AssociatedDemandAccountsSelectorMock as any;
    sut.protectionAccountInfoRecords$ = of({} as any);
    sut.faultArrayMessages$ = of({} as any);
    sut.uidGrid = uidGridMock as any;
  });

  it('Component should be created', () => {
    expect(sut).toBeTruthy();
  });

  it('ngOnInit should call dispatch enter', () => {
    sut.forceHighlightSelectedGridRow=jest.fn();
    sut.ngOnInit();
    expect(AssociatedDemandAccountsActionsMock.getAssociatedDemandAccountRecords).toBeCalledWith({ request: {} as any });
  });

  it('ngOnDestroy should call unsubscribe', () => {
    sut.subs = [of([1, 2, 3]).subscribe()] as any;
    sut.ngOnDestroy();
    expect(sut.subs[0].closed).toBeTruthy();
  });
  it('forceHighlightSelectedGridRow: should highlight record with holdsId Undefined', () => {
    sut.uidGrid={uidApi:{selectRecord:jest.fn(),
      getDisplayedRowAtIndex:jest.fn(()=>({data:{holdId:undefined}})).mockReturnValue({data:{holdId:undefined}})}} as any;
    sut.forceHighlightSelectedGridRow();

    expect(sut.uidGrid.uidApi.selectRecord).toBeCalledTimes(1);
  });

  it('mapGridButtons should find a preview button in the render list and onClick should be defined', () => {
    sut.mapGridButtons(gridDefMock as any);
    expect(gridDefMock.buttonRendererList.find((x) => x.iconType === 'delete')?.onClick).toBeTruthy();
  });

  it('onGridSizeChanged: should fire sizeColumnsToFit', () => {
    const event = { api: { sizeColumnsToFit: jest.fn() } };
    sut.onGridSizeChanged(event as any);
    expect(event.api.sizeColumnsToFit).toBeCalledTimes(1);
  });

  it('onRowSelected: if node is selected and recordNavigation is null, selectRecord dispatch should be called', () => {
    const event = { node: { isSelected: jest.fn().mockReturnValue(true) }, rowIndex: 2 };
    sut.onRowSelected(event as any);
    expect(sut.currentRowIndex).toBe(2);
  });

  it('onRowSelected: if leaf node is true.', () => {
    const event = {node: {isSelected: jest.fn().mockReturnValue(true),group:true,setSelected:jest.fn().mockReturnValue(true)},rowIndex:2,
    };
    sut.onRowSelected(event as any);
    expect(sut.uidGrid.uidApi.selectRecord).toBeCalled();
  });

  it('onGridReady: should call closeToolPanel and sizeColumnsToFit', () => {
    const event = { api: { closeToolPanel: jest.fn(), sizeColumnsToFit: jest.fn() } };
    sut.onGridReady(event as any);

    expect(event.api.closeToolPanel).toBeCalledTimes(1);
    expect(event.api.sizeColumnsToFit).toBeCalledTimes(1);
  });

  it('onGridReady: should work with 0 pagination size', () => {
    const event = { api: { closeToolPanel: jest.fn(), sizeColumnsToFit: jest.fn() } };
    sut.uidGrid.paginationPageSize = 0;
    sut.onGridReady(event as any);
    expect(event.api.closeToolPanel).toBeCalledTimes(1);
    expect(event.api.sizeColumnsToFit).toBeCalledTimes(1);
  });
  it('onGridReady: should not call closeToolPanel and sizeColumnsToFit if event or uiGrid is null', () => {
    const event = { api: { closeToolPanel: jest.fn(), sizeColumnsToFit: jest.fn() } };
    sut.onGridReady(null as any);
    expect(event.api.closeToolPanel).toBeCalledTimes(0);
    expect(event.api.sizeColumnsToFit).toBeCalledTimes(0);
  });

  it('mapOnChangeFormFunction: called to bind the change function', () => {
    sut.getAddAssociatedTypeDropDownOptions = jest.fn();
    sut.associatedDemandAccountGroups = [{ fieldGroup: [{ key: [{ associatedType: { templateOptions: { change: jest.fn() } } }] }] }] as any;
    sut.mapOnChangeFormFunction();
    expect(sut.associatedDemandAccountGroups).toBeTruthy();
  });

  it('addAssociatedDemandAccountsRecord: load forms to add with pageMode is Add and api call as associatedType is undefined', () => {
    sut.protectionAccountInfoRecords = [{ multipleAcctTypeDesc: 'Protection Account' }] as any;
    sut.associatedDemandAccountFormModel = { associatedType: undefined };
    sut.addAssociatedDemandAccountsRecord();
    expect(AssociatedDemandAccountsActionsMock.getAddDropDownsValues).toBeCalledTimes(1);
    expect(AssociatedDemandAccountsActionsMock.togglePageMode).toBeCalledTimes(1);
  });

  it('cancelButton: load cancel dialogbox', () => {
    sut.cancelButton();
    expect(sut.showDialogBox).toBe(true);
  });
  it('deleteButtonClick: if rowIndex is null, selectRecord will not be called', () => {
    const event = { rowIndex: null };
    sut.showDialogBox = false;
    sut.deleteButtonClick(event as any);
    expect(sut.showDialogBox).toBe(true);
  });
  it('deleteButtonClick: if rowIndex is undefined, selectRecord will not be called', () => {
    const event = { rowIndex: undefined };
    sut.showDialogBox = false;
    sut.deleteButtonClick(event as any);
    expect(sut.showDialogBox).toBe(true);
  });
  it('deleteButtonClick: if rowIndex is not null and not undefined, selectRecord should be called', () => {
    const event = { rowIndex: 2 };
    sut.showDialogBox = false;
    sut.deleteButtonClick(event as any);
    expect(sut.showDialogBox).toBe(true);
  });

  it('deleteAssociatedDemandAccountsRecord: dispatch the delete action', () => {
    sut.uidGrid = { api: { getRowNode: jest.fn(), getDisplayedRowCount: jest.fn().mockReturnValue(2), getDisplayedRowAtIndex: jest.fn().mockReturnValue({}) } } as any;
    sut.deleteAssociatedDemandAccountsRecord();
    expect(AssociatedDemandAccountsActionsMock.deleteAssociatedDemandAccount).toBeCalledTimes(1);
  });

  it('saveAssociatedDemandAccounts: show validation error if  accId is empty', () => {
    sut.associatedDemandAccountFormModel = {
      accId: undefined ,
    };
    sut.saveAssociatedDemandAccounts();
    expect(sut.validationErrorMessage).toStrictEqual('Account Id and Account Type are required.');
    expect(AssociatedDemandAccountsActionsMock.addAssociatedDemandAccount).toBeCalledTimes(0);
  });

  it('saveAssociatedDemandAccounts: show validation error if accId is empty', () => {
    sut.protectionAccountInfoRecords = [
      {
        accountDescription: '6 MO <100M',
        accountStatus: 'Matured',
        acctId: '123',
        acctType: 'checking',
        currentBalance: 14,
        amount: 14,
        multipleAcctTypeDesc: 'Holding Account',
        originalAccountType: 'LnAcctInfo.HldAcctId',
        personName: '',
      },
      {
        accountDescription: '',
        accountStatus: 'Active',
        acctId: '88880',
        acctType: 'loan',
        currentBalance: 1458083.8,
        amount: 1458083.8,
        multipleAcctTypeDesc: 'Protection Account',
        originalAccountType: 'LnProtInfo.ProtAcctId',
        personName: 'Betty Adams....................Cust name',
      },
    ];
    sut.associatedDemandAccountFormModel = {
      associatedType:'ProtectionAccount',
      accId: '88880' ,
      accountType:'D'
    };
    sut.saveAssociatedDemandAccounts();
    expect(sut.validationErrorMessage).toStrictEqual('Account 88880 has already been added.');
    expect(AssociatedDemandAccountsActionsMock.addAssociatedDemandAccount).toBeCalledTimes(0);
  });

  it('saveAssociatedDemandAccounts: should dispatch action to save the changes', () => {
    sut.protectionAccountInfoRecords = [
      {
        accountDescription: '6 MO <100M',
        accountStatus: 'Matured',
        acctId: '123',
        acctType: 'checking',
        currentBalance: 14,
        amount: 14,
        multipleAcctTypeDesc: 'Holding Account',
        originalAccountType: 'LnAcctInfo.HldAcctId',
        personName: '',
      },
      {
        accountDescription: '',
        accountStatus: 'Active',
        acctId: '88880',
        acctType: 'loan',
        currentBalance: 1458083.8,
        amount: 1458083.8,
        multipleAcctTypeDesc: 'Protection Account',
        originalAccountType: 'LnProtInfo.ProtAcctId',
        personName: 'Betty Adams....................Cust name',
      },
    ];
    sut.associatedDemandAccountFormModel = {
      associatedType:'ProtectionAccount',
      accId: '81880' ,
      accountType:'D'
    };
    sut.saveAssociatedDemandAccounts();
    expect(AssociatedDemandAccountsActionsMock.addAssociatedDemandAccount).toBeCalledTimes(1);
  });

  it('dialogBoxClose: close dialogbox of delete type', () => {
    sut.deleteAssociatedDemandAccountsRecord = jest.fn();
    sut.dialogBoxClose({ detail: AssociatedDeamdnAccountValueType.deleteMsg } as any);
    expect(sut.deleteAssociatedDemandAccountsRecord).toBeCalledTimes(1);
  });

  it('dialogBoxClose: dont save dialogbox of delete type', () => {
    sut.deleteAssociatedDemandAccountsRecord = jest.fn();
    sut.dialogBoxClose({ detail: AssociatedDeamdnAccountValueType.donotSave } as any);
    expect(AssociatedDemandAccountsActionsMock.togglePageMode).toBeCalledTimes(1);
  });

  it('overridedialogBoxClose: close dialogbox on override button click', () => {
    sut.saveAssociatedDemandAccounts = jest.fn();
    sut.overridedialogBoxClose({ clickAction: AssociatedDeamdnAccountValueType.overrideMsg } as any);
    expect(sut.saveAssociatedDemandAccounts).toBeCalledTimes(1);
  });
  it('overridedialogBoxClose: close dialogbox on override button click', () => {
    sut.saveAssociatedDemandAccounts = jest.fn();
    sut.overridedialogBoxClose({ clickAction: AssociatedDeamdnAccountValueType.cancelMsg } as any);
    expect(sut.saveAssociatedDemandAccounts).toBeCalledTimes(0);
    expect(AssociatedDemandAccountsActionsMock.addFaultRecMessages).toBeCalledTimes(1);
    expect(sut.showOverrideDialogBox).toBe(false);
  });
  it('getAddAssociatedTypeDropDownOptions: call api on associatedType selected',()=>{
    sut.getAddAssociatedTypeDropDownOptions({} as any,{value:'ProtectionAccount'});
    expect(AssociatedDemandAccountsActionsMock.getAddDropDownsValues).toBeCalledTimes(1);
  });

  afterEach(() => {
    sut = {} as any;
    jest.clearAllMocks();
  });
});
