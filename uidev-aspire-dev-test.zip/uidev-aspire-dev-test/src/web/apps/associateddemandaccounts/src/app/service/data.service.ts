/* eslint-disable @typescript-eslint/no-unused-vars */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
// mock data
import getAssociatedDemandAccountsData from '../mock-data/AssociatedDemandAccountsResponse.mock.json';
import addAssociatedDemandAcountDropDownData1 from '../mock-data/AssociatedDemandAccountsAdd1Response.mock.json';
import addAssociatedDemandAcountDropDownData2 from '../mock-data/AssociatedDemandAccountsAdd3Response.mock.json';
// models
import { FaultMsgRec, SearchMessageRequestHeaderModel, SearchMessageResponseHeaderModel } from '@uid/uid-models';
import { AssociatedDemandAccountsSearchResponseModel } from '../models/associated-demand-accounts-search-response.model';
import { AssociatedDemandAccountsSearchRequest } from '../models/associated-demand-accounts-search-request.model';
import { AssociatedDemandAccountsModRequest } from '../models/associated-demand-accounts-mod-request.model';
import { AssociatedDemandAccountsModResponse } from '../models/associated-demand-accounts-mod-response.model';
import { AssociatedDemandAccountsAddRequest } from '../models/associated-demand-accounts-add-request.model';
import { AssociatedDemandAccountsAddResponse } from '../models/associated-demand-accounts-add-response.model';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  pipe: any;

  // TODO : this property will be removed once api is integrated.
  faultRec: FaultMsgRec[] = [
    {
      errCode: '300168',
      errCat: 'Fault',
      errDesc: 'CIF or TIN number difference',
      errElem: 'LnAcctInfo.HldAcctId',
      errElemVal: 'Y/.00',
      errLoc: 'CDHOLDMOD',
    },
  ];

  constructor(private http: HttpClient) {}

  getAssociatedDemandAccountRecords(): AssociatedDemandAccountsSearchResponseModel {
    // TODO : replaces with api get method
    const clone = JSON.parse(JSON.stringify(getAssociatedDemandAccountsData));
    return clone;
  }

  getAssociatedDemandAccountDetails(request: AssociatedDemandAccountsSearchRequest): Observable<AssociatedDemandAccountsSearchResponseModel> {
    const associatedDemandAccount=this.getAssociatedDemandAccountRecords();
    return of(associatedDemandAccount);
  }

  getAddAssociatedDemandAccountDropDownValues(request: AssociatedDemandAccountsAddRequest):
  Observable<AssociatedDemandAccountsAddResponse> {
  // TODO : replaces with api get method
  if(request.associatedAccountType==='HoldingAccount'){
    const clone = JSON.parse(JSON.stringify(addAssociatedDemandAcountDropDownData1));
    return of(clone);
  }else{
    const clone = JSON.parse(JSON.stringify(addAssociatedDemandAcountDropDownData2));
    return of(clone);
  }
  }

  deleteAssociatedDemandAccount(request: AssociatedDemandAccountsModRequest): Observable<AssociatedDemandAccountsModResponse> {
    // TODO : below logic is replaced with http client call.
    const associatedDemandAccount=this.getAssociatedDemandAccountRecords();
    // response without fault rec.
    const response: AssociatedDemandAccountsModResponse = {
      srchMsgRsHdr: { jXLogTrackingId: '', instEnv: '1', cursor: 123 } as SearchMessageResponseHeaderModel,
      addProtectionAccountTypes:associatedDemandAccount.addProtectionAccountTypes,
      protectionAccountInfoRecords:associatedDemandAccount.protectionAccountInfoRecords,
      faultRecInfoArray: [],
    };
    return of(response);
  }

  addAssociatedDemandAccount(request: AssociatedDemandAccountsModRequest): Observable<AssociatedDemandAccountsModResponse> {
    // TODO : below logic is replaced with http client call.
    const associatedDemandAccount=this.getAssociatedDemandAccountRecords();
    // response without fault rec.
    const response: AssociatedDemandAccountsModResponse = {
      srchMsgRsHdr: { jXLogTrackingId: '', instEnv: '1', cursor: 123 } as SearchMessageResponseHeaderModel,
      addProtectionAccountTypes:associatedDemandAccount.addProtectionAccountTypes,
      protectionAccountInfoRecords:associatedDemandAccount.protectionAccountInfoRecords,
      faultRecInfoArray: request.errOvrRdInfoArray.length > 0 ? [] : this.faultRec,
    };
    return of(response);
  }
};
