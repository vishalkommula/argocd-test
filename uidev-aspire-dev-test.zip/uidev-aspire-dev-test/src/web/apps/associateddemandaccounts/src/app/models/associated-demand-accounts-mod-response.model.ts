import { FaultMsgRec, SearchMessageResponseHeaderModel } from '@uid/uid-models';
import { InquiryType } from './inquiry-type.model';
import { MultipleAccountInfoRecord } from './multiple-account-info-record.model';

export interface AssociatedDemandAccountsModResponse {
    srchMsgRsHdr: SearchMessageResponseHeaderModel;
    protectionAccountInfoRecords: MultipleAccountInfoRecord[];
    addProtectionAccountTypes: InquiryType[];
    faultRecInfoArray: FaultMsgRec[];
};
