  // eslint-disable-next-line @typescript-eslint/naming-convention
  export const AssociatedDeamdnAccountValueType= {
    donotSave:'Don\'t Save',
    deleteMsg:'Delete',
    deleteDialogBoxTitle:'Do you want to delete this?',
    cancelMsg:'Cancel',
    cancelDialogBoxTitle:'Do you want to save your changes?',
    cancelDialogBoxText:'Your changes will be lost if you don\'t save them.',
    overrideMsg:'Override',
    displayedDateFormatter:'MM/dd/yyyy',
    isoDateFormatter:'yyyy-MM-dd',
    faultMsg:'Fault',
    errMsg:'Error',
    save:'Save',
    protectionAccount:'ProtectionAccount',
    protectionAccountDesc:'Protection Account',
};

export enum AssociatedDemandAccountFormDateTypeEnum{
  accountInfoDropdown='accountInfo-dropdown'
};
