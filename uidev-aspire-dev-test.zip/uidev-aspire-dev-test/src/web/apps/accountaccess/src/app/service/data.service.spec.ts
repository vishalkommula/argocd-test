import { DataService } from './data.service';

let service: DataService;
const httpMock = {
  get:jest.fn(),
  post:jest.fn()
};

describe('Data Service Test',()=>{
  beforeEach(()=>{
    service = new DataService(httpMock as any);
  });

  it('component should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getIntetAccessInfoRecords should be executed to get intnet access info records',()=>{
    const request = {} as any;
    const accountAccessCustInqResponse = service.getIntnetFinIdRecord(request);
    expect(accountAccessCustInqResponse).not.toBeNull();
    expect(accountAccessCustInqResponse.toPromise()).toBeTruthy();
  });
});
