// TODO: request and response model may change after api integration
// custid is sent from UI to API. API will get the customer record details, pick intnetFinInstId from it and
// send another request IntnetFinInstIdInq with intnetFinInstId. It gives back IntnetFinInstIdInqRes as reponse to UI.
import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface IntnetFinInstIdInqRequestModel {
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    custId: string;
}
