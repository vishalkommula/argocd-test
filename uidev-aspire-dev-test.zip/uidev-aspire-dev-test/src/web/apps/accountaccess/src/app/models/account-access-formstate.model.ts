import { PageMode } from './account-access-enums';

export interface AccountAccessFormStateModel {
    editMode: PageMode.Inquiry;
};
