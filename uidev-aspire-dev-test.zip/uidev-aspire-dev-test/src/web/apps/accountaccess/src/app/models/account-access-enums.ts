export const accountAccessEnum = {
    yes: 'Yes',
    no: 'No',
    relCustId : 'RelCustId',
    relAccId : 'RelAcctId',
};

export enum PageMode {
    Inquiry = 'inquiry',
}
