export interface AccIdAccessInfoRecItemModel {
    acctId: string;
    acctType: string;
    accessAlw: string;
    prodCode: string;
    prodDesc: string;
    acctRelCode?: string;
    acctRelDesc: string;
    rmk?: string;
    aliasAcctName?: string;
    acctElecDocType: string;
    stopPmtAddAnlysId: string;
    stopPmtAddFeeAmt?: number;
    xferFromAnlysId: string;
    xferFromFeeAmt?: number;
    stmtRetrvAnlysId: string;
    stmtRetrvFeeAmt?: number;
    feeChgStmtType: string;
    lnPmtAlw?: string;
}
