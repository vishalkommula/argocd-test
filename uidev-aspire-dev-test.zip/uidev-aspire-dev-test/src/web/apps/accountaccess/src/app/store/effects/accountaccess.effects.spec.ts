import { ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import * as fromRootStore from '@uid/uid-root-store';
import { AccountAccessEffects } from './accountaccess.effects';
import * as AccountAccessActions from '../actions/accountaccess.actions';
import IntnetAccessInfoRecordMock from '../../mock-data/intnet-fin-id-inq-response.mock.json';


jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

const intnetAccessInfoRecordMockData = IntnetAccessInfoRecordMock;

const dataServiceSuccessMockWithData = {
    getIntnetFinIdRecord: ()=> of(intnetAccessInfoRecordMockData)
};

const dataDerviceSuccessMockWithNoData = {
    getIntnetFinIdRecord: ()=> of({srchMsgRsHdr: {} as any})
};

const dataServiceFailureMock = {
    getIntnetFinIdRecord: ()=> throwError('Error - get intnet fin id inq recors')
};

let actions: ActionsSubject;
let effects: AccountAccessEffects;

describe('Account Access Effects Test',()=>{
    beforeEach(()=>{
        actions = new ActionsSubject();
    });

    it('loadIntnetAccessInfoRecord$ should be executed with success response with data',()=>{
        effects = new AccountAccessEffects(dataServiceSuccessMockWithData as any, actions);
        effects.loadIntnetAccessInfoRecord$.subscribe((dispatchedAction)=>{
            expect(dispatchedAction).toEqual(AccountAccessActions.getIntnetAccessInfoRecordSuccess({} as any));
        });
        const action = AccountAccessActions.getIntnetAccessInfoRecord({intnetFinInstIdInqRequest: {} as any});
        actions.next(action);
    });

    it('loadIntnetAccessInfoRecord$ should be executed with success response with no data',()=>{
        effects = new AccountAccessEffects(dataDerviceSuccessMockWithNoData as any, actions);
        effects.loadIntnetAccessInfoRecord$.subscribe((dispatchedAction)=>{
            expect(dispatchedAction).toEqual(AccountAccessActions.getIntnetAccessInfoRecordSuccess({} as any));
        });
        const action = AccountAccessActions.getIntnetAccessInfoRecord({intnetFinInstIdInqRequest: {} as any});
        actions.next(action);
    });

    it('loadIntnetAccessInfoRecord$ should be executed with failure response',()=>{
        effects = new AccountAccessEffects(dataServiceFailureMock as any, actions);
        effects.loadIntnetAccessInfoRecord$.subscribe((dispatchedAction)=>{
            expect(dispatchedAction).toEqual(AccountAccessActions.getIntnetAccessInfoRecordFailure({error: {} as any}));
        });
        const action = AccountAccessActions.getIntnetAccessInfoRecord({intnetFinInstIdInqRequest: {} as any});
        actions.next(action);
    });

    it('rowDetailClicked$ should be executed',() => {
        effects = new AccountAccessEffects(dataServiceSuccessMockWithData as any, actions);
        effects.rowDetailClicked$.subscribe(() => {
            expect(fromRootStore.detailsViewAction).toBeCalled();
        });
        const action = AccountAccessActions.gridRowShowDetailButtonClicked();
        actions.next(action);
    });
});
