export interface RelCodeAccessInfoRecItemModel {
    acctRelCode: string;
    acctRelDesc: string;
}
