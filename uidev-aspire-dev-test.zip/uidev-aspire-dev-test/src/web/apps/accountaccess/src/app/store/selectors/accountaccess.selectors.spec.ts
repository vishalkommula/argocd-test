import { SplitterViewEnum } from '@uid/uid-primary-detail';
import * as AccountAccessSelector from '../selectors/accountaccess.selectors';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

describe('Account Access Selector Test',()=>{
    it('selectAccountIdAccess should be executed',()=>{
        const mockData = {intnetFinInstIdInqResponse: {intnetAccessInfoRecord: {acctIdAccess: ''}}};
        const selector = AccountAccessSelector.selectAccountIdAccess.projector(mockData);
        expect(selector).toEqual(mockData.intnetFinInstIdInqResponse.intnetAccessInfoRecord.acctIdAccess);
    });

    it('selectAccountIdAccessArray should be executed',()=>{
        const mockData = {intnetFinInstIdInqResponse: {intnetAccessInfoRecord: {acctIdAccessArray: [{} as any,{} as any]}}};
        const selector = AccountAccessSelector.selectAccountIdAccessArray.projector(mockData);
        expect(selector).toEqual(mockData.intnetFinInstIdInqResponse.intnetAccessInfoRecord.acctIdAccessArray);
    });

    it('selectRelationshipCodeAccessArray should be executed',()=> {
        const mockData = {intnetFinInstIdInqResponse: {intnetAccessInfoRecord: {relCodeAccessArray: [{} as any, {} as any]}}};
        const selector = AccountAccessSelector.selectRelationshipCodeAccessArray.projector(mockData);
        expect(selector).toEqual(mockData.intnetFinInstIdInqResponse.intnetAccessInfoRecord.relCodeAccessArray);
    });

    it('selectCurrentSelectedRecord should be executed',()=>{
        const mockData = {acctIdAccessRecord: {} as any};
        const selector = AccountAccessSelector.selectCurrentSelectedRecord.projector(mockData);
        expect(selector).toEqual(mockData.acctIdAccessRecord);
    });

    it('selectIntnetAccessInfoRecord should be executed',()=> {
        const mockData = {intnetFinInstIdInqResponse: {intnetAccessInfoRecord: {} as any}};
        const selector = AccountAccessSelector.selectIntnetAccessInfoRecord.projector(mockData);
        expect(selector).toEqual(mockData.intnetFinInstIdInqResponse.intnetAccessInfoRecord);
    });

    it('selectGridWatchColumns should be executed',()=> {
        const mockData = {
            records: [
                {action: 'hide', fieldName: 'actionButtons', value: false}
            ]
        };
        const selector = AccountAccessSelector.selectGridWatchColumns.projector(SplitterViewEnum.gridView);
        expect(selector.records).toEqual(mockData.records);
    });
});
