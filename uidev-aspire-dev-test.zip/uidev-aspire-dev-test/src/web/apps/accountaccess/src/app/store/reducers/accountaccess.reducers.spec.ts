import { AccountAccessState } from '../states/accountaccess.state';
import { accountAccessReducer, initialAccountAccessState } from './accountaccess.reducers';
import * as AccountAccessActions from '../actions/accountaccess.actions';

const expectedState: AccountAccessState = {
    intnetFinInstIdInqResponse: {} as any,
    acctIdAccessRecord: {} as any
};


describe('Inquiry Tracking Reducer test',() => {
    it('getIntnetAccessInfoRecordSuccess should be executed',() => {
        const state = accountAccessReducer(initialAccountAccessState,AccountAccessActions.getIntnetAccessInfoRecordSuccess({intnetFinInstIdInqResponse: {} as any}));
        expect(state).toEqual(expectedState);
    });

    it('updateCurrentRecord should be executed',() => {
        const state = accountAccessReducer(initialAccountAccessState,AccountAccessActions.updateCurrentSelectedRecord({currentRecord: {} as any}));
        expect(state).toEqual(expectedState);
    });
});
