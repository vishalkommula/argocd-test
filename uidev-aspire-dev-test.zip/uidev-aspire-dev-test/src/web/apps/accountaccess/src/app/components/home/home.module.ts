import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AngularSplitModule } from 'angular-split';
import { HttpClientModule } from '@angular/common/http';

// JHA web components
// import '@jha/rui-wc/components/rui-layout/rui-layout-imports';
// import '@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports';
// import '@jha/rui-wc/components/rui-buttons/rui-buttons-imports';
// import '@jha/rui-wc/components/rui-input/rui-input-imports';
// import '@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports';
// import '@jha/rui-wc/components/rui-master-detail/rui-master-detail-imports';
// import '@jha/rui-wc/components/rui-notifications/rui-notifications-imports';

// NGRX
import { ReactiveComponentModule } from '@ngrx/component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

// Ag-grid
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';

// UID
import { UidPrimaryDetailModule } from '@uid/uid-primary-detail';
import { UidPipesModule } from '@uid/uid-pipes';
import { UidAngularControlsModule } from '@uid/uid-angular-controls';
import { UidDirectivesModule } from '@uid/uid-directives';

import { HomeComponent } from './home.component';
import { DataService } from '../../service/data.service';
import { accountAccessReducer } from '../../store/reducers/accountaccess.reducers';
import { AccountAccessEffects } from '../../store/effects/accountaccess.effects';

const routes: Routes = [
    {path: '', component: HomeComponent}
  ];

@NgModule({
    declarations: [
        HomeComponent,
    ],
    imports: [
        CommonModule,
        HttpClientModule,
        RouterModule.forChild(routes),
        UidAngularControlsModule,
        UidDirectivesModule,
        UidPipesModule,
        UidPrimaryDetailModule,
        AgGridModule.withComponents(),
        AngularSplitModule,
        ReactiveComponentModule,
        StoreModule.forFeature('accountAccess', accountAccessReducer),
        EffectsModule.forFeature([AccountAccessEffects]),
    ],
    providers: [ DataService ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class HomeModule {}
