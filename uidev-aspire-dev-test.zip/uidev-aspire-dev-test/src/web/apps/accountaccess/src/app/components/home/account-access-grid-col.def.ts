import { Injectable } from '@angular/core';
import { ColDef, GridOptions, SideBarDef } from 'ag-grid-community';
import { AgGridHyperlinkCellRendererComponent, ButtonRendererClickParms,
         ButtonRendererComponent, ButtonRendererModel } from '@uid/uid-angular-controls';

@Injectable({providedIn: 'root'})
export class AccountAccessGridColDef {
    public buttonRendererList: ButtonRendererModel[] = [
        {
            iconType: 'preview',
            onClick: this.onPreview.bind(this)
        }
    ];

    public default: ColDef = {
        resizable: true,
        sortable: true,
        filter: true,
        enablePivot: false,
    };

    public columns: ColDef[] = [
        {
            field: 'accessAlw',
            headerName: 'Access Allowed',
            rowGroup: true,
            hide: true,
        },
        {
            field: 'acctId',
            headerName: 'Account',
            filter: 'agTextColumnFilter',
            cellRenderer: AgGridHyperlinkCellRendererComponent,
        },
        {
            field: 'aliasAcctName',
            headerName: 'Pseudo Name',
            filter: 'agTextColumnFilter'
        },
        {
            field: 'prodDesc',
            headerName: 'Product',
            filter: 'agTextColumnFilter'
        },
        {
            field: 'acctRelDesc',
            headerName: 'Relationship',
            filter: 'agTextColumnFilter'
        },
        {
            field: 'rmk',
            headerName: 'Comments',
            suppressMenu: true
        },
        {
            field: 'actionButtons',
            headerName: '',
            sortable: false,
            filter: false,
            hide: true,
            cellRenderer: ButtonRendererComponent,
            cellRendererParams: {
                buttonList: this.buttonRendererList
            },
            suppressColumnsToolPanel: true,
            suppressFiltersToolPanel: true
        }
    ];

    public gridOptions: GridOptions = {
        columnDefs: this.columns,
        rowSelection: 'single',
        cacheBlockSize: 100,
        maxBlocksInCache: 25,
        suppressCellFocus: true,
        suppressMovableColumns: true
    };

    public autoGroupColumnDef: ColDef = {
        headerName: 'Access Allowed',
    };

    public sideBar: SideBarDef = {
        toolPanels: [
            {
                id: 'columns',
                labelDefault: 'Columns',
                labelKey: 'columns',
                iconKey: 'columns',
                toolPanel: 'agColumnsToolPanel',
                toolPanelParams: {
                    suppressRowGroups: true,
                    suppressValues: true,
                    suppressPivots: true,
                    suppressPivotMode: true,
                },
            },
            'filters',
        ],
        defaultToolPanel: '',
    };

    onPreview(event: ButtonRendererClickParms): void {
        console.log('clicking Preview!!', event);
    }
}
