import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface EFTCardSrchRequest{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
};
