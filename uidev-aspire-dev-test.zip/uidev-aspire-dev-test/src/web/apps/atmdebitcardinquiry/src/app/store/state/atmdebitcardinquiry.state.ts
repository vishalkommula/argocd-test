import { EFTCardSrchResponse } from '../../models/atmDebitCardInquiry-response.model';

export interface AtmDebitCardInquiryState {
    atmDebitCardInquiryDetailsResponse: EFTCardSrchResponse;
}
