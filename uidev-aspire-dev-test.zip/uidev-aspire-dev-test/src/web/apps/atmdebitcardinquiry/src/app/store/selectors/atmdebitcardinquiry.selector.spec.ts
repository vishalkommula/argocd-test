import * as AtmDebitCardInquirySelector from './atmdebitcardinquiry.selector';

describe('AtmDebit Card List Selector Test',()=> {

    // Atm Debit Card list selector test
    it('selectAtmDebitCardInquiryDetails - should be excuted',()=> {
        const atmDebitCardInquiryListMock = {atmDebitCardInquiryDetailsResponse: {eFTCardSrchArray:[{this: 'test data 1'},{this: 'test data 2'}]}};
        const selector = AtmDebitCardInquirySelector.selectAtmDebitCardInquiryDetails.projector(atmDebitCardInquiryListMock);
        expect(selector).toEqual(atmDebitCardInquiryListMock.atmDebitCardInquiryDetailsResponse.eFTCardSrchArray);
    });
    it('selectExcludeHotCardsData - should be excuted eFTCardSrchArray is data',()=> {
        const atmDebitCardInquiryListMock = {atmDebitCardInquiryDetailsResponse: {eFTCardSrchArray:[{this: 'test data 1'},{this: 'test data 2'}]}};
        const selector = AtmDebitCardInquirySelector.selectExcludeHotCardsData.projector(atmDebitCardInquiryListMock);
        expect(selector).toEqual(atmDebitCardInquiryListMock.atmDebitCardInquiryDetailsResponse.eFTCardSrchArray);
    });
    it('selectExcludeHotCardsData - should be excuted if eFTCardSrchArray is empty',()=> {
        const atmDebitCardInquiryListMock = {atmDebitCardInquiryDetailsResponse: {eFTCardSrchArray:[]}};
        const selector = AtmDebitCardInquirySelector.selectExcludeHotCardsData.projector(atmDebitCardInquiryListMock);
        expect(selector).toEqual(atmDebitCardInquiryListMock.atmDebitCardInquiryDetailsResponse.eFTCardSrchArray);
    });
});
