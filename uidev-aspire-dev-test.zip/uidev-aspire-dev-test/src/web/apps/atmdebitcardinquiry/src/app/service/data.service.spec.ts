import { TestBed } from '@angular/core/testing';

import { DataService } from './data.service';

let service: DataService;

describe('DataService', () => {

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('getAtmCardDetails method - should be excuted', async ()=> {
    expect(await service.getAtmDebitCardInquiryDetails({} as any).toPromise()).toBeTruthy();
  });
});
