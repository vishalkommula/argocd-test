import { Component, Input, OnInit, ViewChild } from '@angular/core';

// Ag grid
import { ColDef, GridApi, GridOptions } from 'ag-grid-enterprise';
import { GridReadyEvent, GridSizeChangedEvent, SideBarDef } from 'ag-grid-community';

// UID
import { UidGridAngular, WatchColumnActionsEnum, WatchColumnDefinitionModel } from '@uid/uid-directives';

// NGRX
import { Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { EftCardSrcRecItemModel } from '../../models/atmDebitCardInquiry-item.model';
import * as AtmDebitCardInquiryActions from '../../store/actions/atmdebitcardinquiry.action';
import * as AtmDebitCardInquirySelector from '../../store/selectors/atmdebitcardinquiry.selector';
import { AtmDebitCardInquiryGridService } from './atmdebitcardinquiry-grid.service';
@Component({
  selector: 'uid-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  @ViewChild('uidGrid')
  uidGrid = {} as UidGridAngular;

  public colDefs!: ColDef[];
  public defaultColDefs!: ColDef;
  public gridOptions!: GridOptions;
  gridApi: GridApi = {} as GridApi;
  sideBar: SideBarDef;
  atmDebitCardInquiryActions = AtmDebitCardInquiryActions;
  atmDebitCardInquirySelector = AtmDebitCardInquirySelector;
  hotCardStatus = true;

  atmDebitCardInquiryDetails$: Observable<EftCardSrcRecItemModel[]> = of();

  constructor(private store: Store, private gridDef: AtmDebitCardInquiryGridService) {
    this.colDefs = this.gridDef.columns;
    this.defaultColDefs = this.gridDef.defautColDef;
    this.gridOptions = this.gridDef.gridOptions;
    this.gridApi = this.uidGrid.api;
    this.sideBar = this.gridDef.sideBar;
    this.atmDebitCardInquiryDetails$ = this.store.select(this.atmDebitCardInquirySelector.selectAtmDebitCardInquiryDetails);
  }

  ngOnInit(): void {
    this.store.dispatch(this.atmDebitCardInquiryActions.getAtmDebitCardInquiry({ request: {} as any }));
  }

  onGridReady(event: GridReadyEvent) {
    this.gridApi = event.api;
    event.api.closeToolPanel();
    event.api.sizeColumnsToFit();
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
    event.api.sizeColumnsToFit();
  }

  onExcludeHotCardsClick(){
    if(this.hotCardStatus === true){
      this.hotCardStatus = false;
      this.atmDebitCardInquiryDetails$ = this.store.select(this.atmDebitCardInquirySelector.selectExcludeHotCardsData);
    } else{
      this.hotCardStatus = true;
      this.atmDebitCardInquiryDetails$ = this.store.select(this.atmDebitCardInquirySelector.selectAtmDebitCardInquiryDetails);
    }
  }
}
