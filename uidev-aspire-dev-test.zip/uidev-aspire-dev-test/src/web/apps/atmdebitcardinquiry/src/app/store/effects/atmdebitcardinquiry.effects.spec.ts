
import { ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import mockData from '../../mock-data/atmDebitCardInquiry.mock.json';
import * as AtmDebitCardInquiryActions from '../actions/atmdebitcardinquiry.action';
import { AtmDebitCardInquiryEffects } from './atmdebitcardinquiry.effects';

// mocking success service method
const atmDebitCardInquirySuccessMock = {
    getAtmDebitCardInquiryDetails: ()=> of(mockData),
};

// mocking faiure service method
const atmDebitCardInquiryFailureMock = {
    getAtmDebitCardInquiryDetails: ()=> throwError('Error - getting the atm debit card inquiry list')
};

// mock action subject
let actions: ActionsSubject;

// mock effects
let effects: AtmDebitCardInquiryEffects;

describe('Atm Debit Card Inquiry Effects Test',()=> {
    beforeEach(()=>{
        actions = new ActionsSubject();
    });
// get atm debit card inquiry list info success response
it('getAtmDebitCardInquiryDetails$ - should be excuted if success response', ()=>{
    effects = new AtmDebitCardInquiryEffects(atmDebitCardInquirySuccessMock as any,actions);
    effects.getAtmDebitCardInquiryDetails$.subscribe((response: any)=>{
        expect(response).toEqual(AtmDebitCardInquiryActions.getAtmDebitCardInquirySuccess({response: {} as any}));
    });
        // dispatch the action method
    const action = AtmDebitCardInquiryActions.getAtmDebitCardInquiry({request:{} as any});
    actions.next(action);
});

// get atm debit card inquiry list info failure response
it('getAtmDebitCardInquiryDetails$ - should be excuted if failure response', ()=>{
    effects = new AtmDebitCardInquiryEffects(atmDebitCardInquiryFailureMock as any,actions);
    effects.getAtmDebitCardInquiryDetails$.subscribe((failure: any)=>{
       expect(failure).toEqual(AtmDebitCardInquiryActions.getAtmDebitCardInquiryFailure({error:{} as Error}));
    });
        // dispatch the action method
        const action = AtmDebitCardInquiryActions.getAtmDebitCardInquiry({request:{} as any});
        actions.next(action);
});

});
