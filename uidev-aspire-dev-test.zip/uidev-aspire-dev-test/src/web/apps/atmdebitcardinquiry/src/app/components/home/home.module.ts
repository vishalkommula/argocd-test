import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

// JHA web components
import '@jha/rui-wc/components/rui-layout/rui-layout-imports';
import '@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports';
import '@jha/rui-wc/components/rui-buttons/rui-buttons-imports';
import '@jha/rui-wc/components/rui-input/rui-input-imports';
import '@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports';
import '@jha/rui-wc/components/rui-master-detail/rui-master-detail-imports';
import '@jha/rui-wc/components/rui-notifications/rui-notifications-imports';
import '@jha/rui-wc/components/rui-tabs/rui-tabs-imports';

// Ag-grid
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';

// NGRX
import { ReactiveComponentModule } from '@ngrx/component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

// UID
import { UidDirectivesModule } from '@uid/uid-directives';

// Store
import { AtmDebitCardInquiryEffects } from '../../store/effects/atmdebitcardinquiry.effects';
import {atmDebitCardInquiryReducer} from '../../store/reducers/atmdebitcardinquiry.reducer';

// Components
import { HomeComponent } from './home.component';


// Service
import { DataService } from '../../service/data.service';

const routes: Routes = [
    {path: '', component: HomeComponent, children: [
      {path: '', component: HomeComponent},
    ]},
  ];

@NgModule({
    declarations: [
        HomeComponent
    ],
    imports: [
        CommonModule,
        RouterModule.forChild(routes),
        FormsModule,
        HttpClientModule,
        UidDirectivesModule,
        ReactiveFormsModule,
        AgGridModule.withComponents([]),
        ReactiveComponentModule,
        StoreModule.forFeature('atmDebitCardInquiry', atmDebitCardInquiryReducer),
        EffectsModule.forFeature([AtmDebitCardInquiryEffects]),
    ],
    providers: [DataService],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HomeModule{}
