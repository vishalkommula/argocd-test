import { createReducer, on } from '@ngrx/store';
import { EftCardSrcRecItemModel } from '../../models/atmDebitCardInquiry-item.model';
import { EFTCardSrchResponse } from '../../models/atmDebitCardInquiry-response.model';
import * as AtmDebitCardInquiryActions from '../actions/atmdebitcardinquiry.action';
import { AtmDebitCardInquiryState } from '../state/atmdebitcardinquiry.state';


export const initialAtmDebitCardInquiryState: AtmDebitCardInquiryState = {
  // atm debit card inquiry state
  atmDebitCardInquiryDetailsResponse: {} as EFTCardSrchResponse,
};

export const atmDebitCardInquiryReducer = createReducer(
  initialAtmDebitCardInquiryState,

//   atm debit card inquiry reducer
  on(
    AtmDebitCardInquiryActions.getAtmDebitCardInquirySuccess,
    (state, action): AtmDebitCardInquiryState => ({
      ...state,
      atmDebitCardInquiryDetailsResponse:action.response
    })
  ),

);
