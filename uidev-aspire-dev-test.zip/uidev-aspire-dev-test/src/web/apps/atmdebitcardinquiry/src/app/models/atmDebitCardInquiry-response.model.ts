import { SearchMessageResponseHeaderModel} from '@uid/uid-models';
import { EftCardSrcRecItemModel} from './atmDebitCardInquiry-item.model';


export interface EFTCardSrchResponse{
    srchMsgRsHdr:    SearchMessageResponseHeaderModel;
    acctId:          string;
    acctType:        string;
    eFTCardSrchArray:   EftCardSrcRecItemModel[];
};
