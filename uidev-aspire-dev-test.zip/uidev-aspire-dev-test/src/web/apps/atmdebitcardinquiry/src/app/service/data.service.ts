import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import atmcardmockdata from '../mock-data/atmDebitCardInquiry.mock.json';
import { EFTCardSrchRequest } from '../models/atmDebitCardInquiry-request.model';
import { EFTCardSrchResponse } from '../models/atmDebitCardInquiry-response.model';
@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor() { }

   // get atm debit card inquiry details
   getAtmDebitCardInquiryDetails(_request: EFTCardSrchRequest): Observable<EFTCardSrchResponse>{
    const clone = JSON.parse(JSON.stringify(atmcardmockdata));
    return of(clone);
  }
}
