import { AtmDebitCardInquiryGridService } from './atmdebitcardinquiry-grid.service';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());



let service: AtmDebitCardInquiryGridService;

describe('AtmDebitCardInquiryGridService', () => {

  beforeEach(() => {
    service = new AtmDebitCardInquiryGridService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('dateFormatter convert date to MM/dd/YYYY format', () => {
    const params = { value: '2013-11-02' };
    expect(service.dateFormatter(params as any)).toBe('11/02/2013');
  });
});
