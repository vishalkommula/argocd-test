import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeComponent } from './home.component';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());

import 'ag-grid-enterprise';
import { GridReadyEvent } from 'ag-grid-community';

import atmDebitCardInquiryMock from '../../mock-data/atmDebitCardInquiry.mock.json';
import { Observable, of } from 'rxjs';
import { EFTCardSrchResponse } from '../../models/atmDebitCardInquiry-response.model';

let component: HomeComponent;

  const atmDebitCardInquiryActionsMock = {
    getAtmDebitCardInquiry: jest.fn(),
  };
  const atmDebitCardInquirySelectorMock ={
    selectAtmDebitCardInquiryDetails:jest.fn(),
    selectExcludeHotCardsData:jest.fn(),
  };
  const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(() =>({
      subscribe:jest.fn(),
    })),
  };
  const gridDef = {

  };

describe('HomeComponent', () => {
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    component = new HomeComponent(storeMock as any,gridDef as any);
    component.atmDebitCardInquiryActions = atmDebitCardInquiryActionsMock as any;
    component.atmDebitCardInquirySelector = atmDebitCardInquirySelectorMock as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('data should be fetched on oninit', () => {
    component.ngOnInit();
    expect(atmDebitCardInquiryActionsMock.getAtmDebitCardInquiry).toBeCalledWith({request: {} as any});
    expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
    expect(atmDebitCardInquiryActionsMock.getAtmDebitCardInquiry).toHaveBeenCalledTimes(1);
  });
  it('onGridReady method - should be executed', () => {
    const event: GridReadyEvent = {} as any;
    component.onGridReady(event);
    component.gridApi = event.api;
    const actualValue = component.gridApi;
    const expectedValue = event.api;
    expect(actualValue).toEqual(expectedValue);
  });
  it('onGridSizeChanged method - should be executed', () => {
    const event = {
      api:{
        sizeColumnsToFit:jest.fn()
      }
    } as any;
    component.onGridSizeChanged(event);
    const actualValue = event.api.sizeColumnsToFit;
    expect(actualValue).toBeCalled();
  });;
  it('onExcludeHotCardsClick method - should be excuted if hotcardstatus true', () => {
    component.hotCardStatus = true;
    component.onExcludeHotCardsClick();
    expect(component.hotCardStatus).toEqual(false);
    expect(storeMock.select).toHaveBeenCalledTimes(2);
  });
  it('onExcludeHotCardsClick method - should be excuted if hotcardstatus false', () => {
    component.hotCardStatus = false;
    component.onExcludeHotCardsClick();
    expect(component.hotCardStatus).toEqual(true);
    expect(storeMock.select).toHaveBeenCalledTimes(3);
  });
});
