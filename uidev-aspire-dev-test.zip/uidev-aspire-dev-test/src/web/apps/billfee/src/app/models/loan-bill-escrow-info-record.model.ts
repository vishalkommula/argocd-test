import { SLLnBilEscrwInfoRecItemModel } from './sl-loan-bill-escrow-info-record-item.model';
import { SLLnBilEscrwPmtBalInfoRecItem } from './sl-loan-bill-escrow-pmt-bal-info-record-item.model';

export interface LnBilEscrwInfoRecModel{
    billDt: string;
    escrowInfo: SLLnBilEscrwInfoRecItemModel;
    lnBilEscrowId: string;
    escrowBalances: SLLnBilEscrwPmtBalInfoRecItem[];
    override: boolean;
};
