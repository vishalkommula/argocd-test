import { createFeatureSelector, createSelector } from '@ngrx/store';
import { LoanFeeFormStateModel } from '../../models/loan-fee-form-state.model';
import { BillFeeState } from '../states/billfee.state';
import * as fromRootStore from '@uid/uid-root-store';
import {SplitterViewEnum} from '@uid/uid-primary-detail';
import { formatISODate } from '@uid/uid-utilities';


export const selectFeeRoot = createFeatureSelector<BillFeeState>('billFees');

export const selectLoanFee = createSelector(selectFeeRoot, state => state.loanBillFeeResponse.lnFeeInfoRec);

export const selectUpdatedFees = createSelector(selectFeeRoot, state => state.updatedLoanFeeResponse.lnFeeInfo);

export const selectShadowFee = createSelector(selectFeeRoot, state => state.loanBillFeeResponse.lnFeeInfoRec);

export const selectCurrentLoanFeeRecord = createSelector(selectFeeRoot, state => ({
    ...state.currentBillFeeRecord
}));

// for selected fee
export const selectFeeRecord = createSelector(
    selectFeeRoot,
    selectCurrentLoanFeeRecord,
    (state, selectedLoanFeeRecord) => {
        const currentBillFeeRecord = {...selectedLoanFeeRecord};
        currentBillFeeRecord['lnFeeLastPmtDt'] =  formatISODate(currentBillFeeRecord['lnFeeLastPmtDt'], 'MM/dd/yyyy');
        currentBillFeeRecord['lnFeeAssmntDt']  =  formatISODate(currentBillFeeRecord['lnFeeAssmntDt'], 'MM/dd/yyyy');
        currentBillFeeRecord['lnBillDt']       =  formatISODate(currentBillFeeRecord['lnBillDt'], 'MM/dd/yyyy');
        currentBillFeeRecord['lnPaidDt']       =  formatISODate(currentBillFeeRecord['lnPaidDt'], 'MM/dd/yyyy');
        currentBillFeeRecord['lnFeeWavDt']     =  formatISODate(currentBillFeeRecord['lnFeeWavDt'], 'MM/dd/yyyy');
        return currentBillFeeRecord;
    });

export const selectPageMode = createSelector(selectFeeRoot, (state) => state.pageMode);

export const selectModifiedFeeResponse = createSelector(selectFeeRoot, state => state.updatedLoanFeeResponse);

export const selectShowACHAutoReturn = createSelector(selectFeeRoot, state => state.loanBillFeeResponse.showACHAutoReturn);

export const selectFormState = createSelector(
    fromRootStore.selectCurrentAccountType,
    selectPageMode,
    selectShowACHAutoReturn,
    fromRootStore.selectIsSplitView,
    (accountType,editMode, showACHAutoReturn, splitView): LoanFeeFormStateModel => ({
        accountType,
        editMode,
        showACHAutoReturn,
        width: splitView === SplitterViewEnum.detailView ? 'medium' : 'full'
})
);
