import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { DataService } from '../../service/data.service';
import * as escrowInfoActions from '../actions/billescrow.action';

@Injectable()
export class EscrowInfoEffects{

    constructor(private dataservice: DataService, private actions$: Actions){}

    // Get escrow from service
    getEscrowDetails$ = createEffect(() => {
        return this.actions$.pipe(
                   ofType(escrowInfoActions.getEscrow),
                   switchMap((action) =>
                       this.dataservice
                           .getEscrowDetails(action.request)
                           .pipe(
                               map((response) => escrowInfoActions.getEscrowSuccess({response})),
                               catchError((error) =>
                                   of(escrowInfoActions.getEscrowFailure({error}))
                               )
                           )
                   )
            );
       }
    );

    // Edit escrow from service
    editEscrowDetails$ = createEffect(() => {
        return this.actions$.pipe(
                   ofType(escrowInfoActions.saveEscrow),
                   switchMap((action) =>
                       this.dataservice
                           .saveEscrowDetails(action.updateRecord)
                           .pipe(
                               map((response) => escrowInfoActions.saveEscrowSuccess({response})),
                               catchError((error) =>
                                   of(escrowInfoActions.saveEscrowFailure({error}))
                               )
                           )
                   )
            );
       }
    );
}
