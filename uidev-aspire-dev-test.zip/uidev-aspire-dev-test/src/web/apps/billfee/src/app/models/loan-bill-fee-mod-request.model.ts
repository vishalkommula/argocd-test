import { SearchMessageRequestHeaderModel } from '@uid/uid-models';
import { LoanBillFeeResponseModel } from './loan-bill-fee-response.model';


export interface LnFeeModRequestModel{
  srchMsgRqHdr: SearchMessageRequestHeaderModel;
  acctId:       string;
  acctType:     string;
  lnFeeInfo: LoanBillFeeResponseModel;
  overrideFaultMsg: boolean;
}
