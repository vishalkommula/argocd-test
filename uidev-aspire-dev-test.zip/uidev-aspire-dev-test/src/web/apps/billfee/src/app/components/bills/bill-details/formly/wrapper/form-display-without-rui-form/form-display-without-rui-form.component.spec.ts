
import { FormDisplayWithoutRuiFormComponent } from './form-display-without-rui-form.component';

describe('FormDisplayWithoutRuiFormComponent', () => {
    let sut: FormDisplayWithoutRuiFormComponent;

    beforeEach(() => {
        sut = new FormDisplayWithoutRuiFormComponent();
    });

    it('should create', () => {
        expect(sut).toBeTruthy();
    });
});
