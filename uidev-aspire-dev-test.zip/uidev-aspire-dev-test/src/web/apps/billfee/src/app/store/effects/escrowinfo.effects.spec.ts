
import { ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';
import mockData from '../../mock-data/loanBillescrowResponse.mock.json';
import mockEditData from '../../mock-data/loanBillescrowEditResponse.mock.json';
import { EscrowInfoEffects } from './escrowinfo.effects';
import { getEscrowFailure, getEscrowSuccess, saveEscrowFailure, saveEscrowSuccess } from '../actions/billescrow.action';
import * as EscrowInfoActions from '../actions/billescrow.action';

// mocking success service method
const escrowServiceSuccessMock = {
    getEscrowDetails: ()=> of(mockData),
    editEscrowDetails: ()=> of(mockEditData),
};

// mocking faiure service method
const escrowServiceFailureMock = {
    getEscrowDetails: ()=> throwError('Error - getting the escrow list'),
    editEscrowDetails: ()=> throwError('Error - getting the edit escrow list')
};

// mock action subject
let actions: ActionsSubject;

// mock effects
let effects: EscrowInfoEffects;

describe('Escrow Effects Test',()=> {
    beforeEach(()=>{
        actions = new ActionsSubject();
    });
// get escrow list info success response
it('getEscrowDetails$ dispatch success action', ()=>{
    effects = new EscrowInfoEffects(escrowServiceSuccessMock as any,actions);
    effects.getEscrowDetails$.subscribe((response)=>{
        expect(response).toEqual(EscrowInfoActions.getEscrowSuccess({} as any));
    });
        // dispatch the action method
    const action = EscrowInfoActions.getEscrow({request:{} as any});
    actions.next(action);
});

// get escrow list info failure response
it('getEscrowDetails$ dispatch failure action', ()=>{
    effects = new EscrowInfoEffects(escrowServiceFailureMock as any,actions);
    effects.getEscrowDetails$.subscribe((dispatchedaction)=>{
       expect(dispatchedaction).toEqual(EscrowInfoActions.getEscrowFailure({error:{} as Error}));
    });
        // dispatch the action method
        const action = EscrowInfoActions.getEscrow({request:{} as any});
        actions.next(action);
});

// get escrow editlist info success response
it('editEscrowDetails$ dispatch success action', ()=>{
    effects = new EscrowInfoEffects(escrowServiceSuccessMock as any,actions);
    effects.editEscrowDetails$.subscribe((response)=>{
        expect(response).toEqual(EscrowInfoActions.saveEscrowSuccess({} as any));
    });
        // dispatch the action method
    const action = EscrowInfoActions.saveEscrow({updateRecord:{} as any});
    actions.next(action);
});

// get escrow editlist info failure response
it('editEscrowDetails$ dispatch failure action', ()=>{
    effects = new EscrowInfoEffects(escrowServiceFailureMock as any,actions);
    effects.editEscrowDetails$.subscribe((error)=>{
       expect(error).toEqual(EscrowInfoActions.saveEscrowFailure({error:{} as Error}));
    });
        // dispatch the action method
        const action = EscrowInfoActions.saveEscrow({updateRecord:{} as any});
        actions.next(action);
});

});
