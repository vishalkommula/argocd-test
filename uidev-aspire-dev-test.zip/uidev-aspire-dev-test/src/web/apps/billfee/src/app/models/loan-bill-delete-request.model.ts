import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface LnBilDeleteRequestModel{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    billduedate: string;
    overrideFaultMsg: boolean;
};
