// import { createReducer, on, State } from '@ngrx/store';
// import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';
// import { SLLnBilEscrwPmtBalInfoRecItem } from '../../models/sl-loan-bill-escrow-pmt-bal-info-record-item.model';
// import * as EscrowInfoActions from '../actions/billescrow.action';
// import { EscrowDetailsState, initialEscrowInfoState } from '../states/escrowinfo.state';

// export const escrowDetailsReducer = createReducer(
//   initialEscrowInfoState,

//   // // Reducer for escrow details initial entry
//   // on(
//   //   EscrowInfoActions.escrowList,
//   //   (state): EscrowDetailsState => ({
//   //     ...state,
//   //     escrowDetailsResponse: {} as LnBilEscrwSrchResponse,
//   //   })
//   // ),

//   // // Reducer for escrow details success response
//   // on(
//   //   EscrowInfoActions.escrowListRetrived,
//   //   (state, action): EscrowDetailsState => ({
//   //     ...state,
//   //     escrowDetailsResponse: action.response,
//   //   })
//   // ),

//   // // Reducer for escrow details edit response
//   // on(EscrowInfoActions.escrowListEditsuccess, (state, action): EscrowDetailsState => {
//   //   if (action.response.rsStat) {
//   //     return {
//   //       ...state,
//   //     };
//   //   } else if (!action.response.rsStat && action.response.canOverride) {
//   //     return {
//   //       ...state,
//   //       faultRecInfoArray: action.response.faultRecInfoArray,
//   //       showoverridedialogbox: true,
//   //     };
//   //   } else {
//   //     return {
//   //       ...state,
//   //       faultRecInfoArray: action.response.faultRecInfoArray,
//   //     };
//   //   }
//   // }),

//   // //    override cancel popup
//   // on(
//   //   EscrowInfoActions.canceloverridedialogbox,
//   //   (state, action): EscrowDetailsState => ({
//   //     ...state,
//   //     showoverridedialogbox: action.canceloverridebox,
//   //     faultRecInfoArray: [],
//   //   })
//   // ),

//   // // update escrow balances
//   // on(
//   //   EscrowInfoActions.updateEscrowBalance,
//   //   (state, action): EscrowDetailsState => ({
//   //     ...state,
//   //     escrowDetailsResponse: {
//   //       srchMsgRsHdr: state.escrowDetailsResponse.srchMsgRsHdr,
//   //       acctId: state.escrowDetailsResponse.acctId,
//   //       acctType: state.escrowDetailsResponse.acctType,
//   //       canOverride: state.escrowDetailsResponse.canOverride,
//   //       faultRecInfoArray: state.escrowDetailsResponse.faultRecInfoArray,
//   //       rsStat: state.escrowDetailsResponse.rsStat,
//   //       lnBilEscrwInfoRec: {
//   //         billDt: state.escrowDetailsResponse.lnBilEscrwInfoRec.billDt,
//   //         override: state.escrowDetailsResponse.lnBilEscrwInfoRec.override,
//   //         lnBilEscrowId: state.escrowDetailsResponse.lnBilEscrwInfoRec.lnBilEscrowId,
//   //         escrowInfo: state.escrowDetailsResponse.lnBilEscrwInfoRec.escrowInfo,
//   //         escrowBalances: state.escrowDetailsResponse.lnBilEscrwInfoRec.escrowBalances.map((escrow) => (escrow.balFldAff === action.cellModifiedData.uniqueRowIdentifier ? action.cellModifiedData.newRowData : escrow)),
//   //       },
//   //     },
//   //   })
//   // ),

//   // // update escrow balances
//   // on(
//   //   EscrowInfoActions.updateEscrowDetails,
//   //   (state, action): EscrowDetailsState => ({
//   //     ...state,
//   //     escrowDetailsResponse: {
//   //       srchMsgRsHdr: state.escrowDetailsResponse.srchMsgRsHdr,
//   //       acctId: state.escrowDetailsResponse.acctId,
//   //       acctType: state.escrowDetailsResponse.acctType,
//   //       canOverride: state.escrowDetailsResponse.canOverride,
//   //       faultRecInfoArray: state.escrowDetailsResponse.faultRecInfoArray,
//   //       rsStat: state.escrowDetailsResponse.rsStat,
//   //       lnBilEscrwInfoRec: {
//   //         billDt: state.escrowDetailsResponse.lnBilEscrwInfoRec.billDt,
//   //         override: state.escrowDetailsResponse.lnBilEscrwInfoRec.override,
//   //         lnBilEscrowId: state.escrowDetailsResponse.lnBilEscrwInfoRec.lnBilEscrowId,
//   //         escrowInfo: action.updateEscrowDetails,
//   //         escrowBalances: state.escrowDetailsResponse.lnBilEscrwInfoRec.escrowBalances,
//   //       },
//   //     },
//   //   })
//   // )
// );
