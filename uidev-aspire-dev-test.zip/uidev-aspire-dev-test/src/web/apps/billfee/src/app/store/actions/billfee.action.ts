import { createAction, props } from '@ngrx/store';
import { LoanBillFeeRequestModel } from '../../models/loan-bill-fee-request.model';
import { LoanBillFeeResponseModel } from '../../models/loan-bill-fee-response.model';
import { LnFeeModRequestModel } from '../../models/loan-bill-fee-mod-request.model';
import { LnFeeInfoRecModel } from '../../models/loan-fee-info-record.model';
import { LnFeeModResponse } from '../../models/loan-bill-fee-mod-response.model';

export interface Status {
  status: string;
}
// create action for getting data
export const getLoanFees = createAction('[Bills/Fees] Get Loan Fees Data', props<{ request: LoanBillFeeRequestModel }>());

// action for loanfee success response
export const getLoanFeeSuccess = createAction('[Bills/Fees] Loan Fees Response Success', props<{ response: LoanBillFeeResponseModel }>());

// action for loanfee error response
export const getLoanFeeError = createAction('[Bills/Fees] Loan Fees Error Response', props<{ error: Error }>());

// create action for getting shadow fee data
export const getShadowFees = createAction('[Bills/Fees] Get Shadow Fees Data', props<{ request: LoanBillFeeRequestModel }>());

// action for shadowfee success response
export const getShadowFeeSuccess = createAction('[Bills/Fees] Shadow Fees Response Success', props<{ response: LoanBillFeeResponseModel }>());

// action for shadowfee error response
export const getShadowFeeError = createAction('[Bills/Fees] Shadow Fees Error Response', props<{ error: Error }>());

// action for select record
export const selectRecord = createAction('[Bill/Fees] Select A Record', props<{ currentRecord: LnFeeInfoRecModel }>());

// action for inquiry/detail view
export const setPageToInquiryMode = createAction('[Bills/Fees] Set Inquiry Mode');

// action for edit
export const setPageToEditMode = createAction('[BillFee/Fees] Set Edit Mode');

// action for cancel
export const cancelModifiedFee = createAction('[BillFee/Fees] Click Form Cancel');

// action for fee form model change
export const updateLoanFeeFormModel = createAction('[BillFee/Fees] On Formdata Change', props<{ updateFeeFormModel: LnFeeInfoRecModel}>());

// action for save
export const saveModifiedFee = createAction('[BillFee/Fees] Click Form Save', props<{ request: LnFeeModRequestModel}>());

// action for save success
export const saveModifiedFeeSuccess = createAction('[BillFee/Fees] Modified Form Success Response', props<{ response: LnFeeModResponse }>());

// action for shadowfee error response
export const saveModifiedFeeError = createAction('[Bills/Fees] Modified Form Error Response', props<{ error: Error }>());
