import { PageMode } from '../../models/bill-fee-enums';
import * as BillInfoSelector from './billInfo.selector';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

describe('Bill List Selector Test', () => {
  // Bill list selector test
  it('selectBillList- returns bill list selector test', () => {
    const billListMock = { loanBillResponse: { lnBilSrchRec: [{ this: 'test data 1' }, { this: 'test data 2' }] } };
    const selector = BillInfoSelector.selectBillList.projector(billListMock);
    expect(selector).toEqual(billListMock.loanBillResponse.lnBilSrchRec);
  });
  // bill due date selector test
  it('selectBillDueDate- returns selected billdue date', () => {
    const billDueDateMock = { selectedBillDueDate: '' };
    const selector = BillInfoSelector.selectBillDueDt.projector(billDueDateMock);
    expect(selector).toEqual(billDueDateMock.selectedBillDueDate);
  });

  // Bill inq selector test
  it('selectBillInfoByBillDueDt; return bill info by bill due date selector test', () => {
    const billInfoMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22',lnStmtInfoRec:{nxtPmtDueDt:'2022-02-22'} } }],
      loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectBillInfoByBillDueDt.projector(billInfoMock, '2022-02-22');
    const billInfoResultMock = { lnbilInfoRec: { bilDueDt: '02/22/2022', bilPaidDt: '', nxtPayDt: '',lnStmtInfoRec:{nxtPmtDueDt:'02/22/2022'} } };
    expect(selector).toEqual(billInfoResultMock);
  });

  it('selectBillInfoByBillDueDt; return null if bill dude is not existing selector test', () => {
    const billInfoMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
      loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectBillInfoByBillDueDt.projector(billInfoMock, '2022-02-21');
    const billInfoResultMock = { lnbilInfoRec: { bilDueDt: '02/22/2022', bilPaidDt: '', nxtPayDt: '' } };
    expect(selector).toEqual(null);
  });

  it('selectBillInfoByBillDueDt; return null if lnBillInfoResponse not exist', () => {
    const billInfoMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
      loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectBillInfoByBillDueDt.projector(billInfoMock, '');
    expect(selector).toEqual(null);
  });

  it('selectBillSearchByBillDueDt - return bill search by bill due date selector.', () => {
    const billsearchMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
      loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectBillSearchByBillDueDt.projector(billsearchMock, '2022-02-22');
    const billInfoSearchMock = { lnbilSrchRec: { bilDueDt: '2022-02-22' } };
    expect(selector).toEqual(billInfoSearchMock);
  });

  it('selectBillSearchByBillDueDt - return null by bill due date that not availiable in bill searchselector.', () => {
    const billsearchMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
      loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectBillSearchByBillDueDt.projector(billsearchMock, '2022-02-4');
    expect(selector).toEqual(null);
  });

  it('selectBillSearchByBillDueDt - return null if bill due date is empty selector.', () => {
    const billsearchMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
      loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectBillSearchByBillDueDt.projector(billsearchMock, '');
    expect(selector).toEqual(null);
  });

  it('selectBillSearchByBillDueDt - return null if bill search is not existing.', () => {
    const billsearchMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
      loanBillResponse: {},
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectBillSearchByBillDueDt.projector(billsearchMock, '');
    expect(selector).toEqual(null);
  });
  it('selectAvailiableBillDueDates - return availiabled bill due date in bill info selector test', () => {
    const billInfoMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
      loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectAvailiableBillDueDates .projector(billInfoMock);
    expect(selector).toEqual(['2022-02-20', '2022-02-22']);
  });

  it('selectBillDueDtList - return availiabled bill due date in bill search selector test', () => {
    const billsearchMock = {
      lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
      loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
      selectedBillDueDate: '2022-03-21',
      billDueDt: '2022-03-21',
    };
    const selector = BillInfoSelector.selectBillDueDtList.projector(billsearchMock);
    expect(selector).toEqual(['2022-02-20', '2022-02-22']);
  });

  it('selectIsBillInfoUpdated - returns isBillInfoUpdated  test', () => {
    const billState = { isBillInfoUpdated: false };
    const selector = BillInfoSelector.selectIsBillInfoUpdated.projector(billState);
    expect(selector).toEqual(billState.isBillInfoUpdated);
  });

  it('selectisBillInfoDeleted - return isBillInfoDeleted test', () => {
    const billState = { isBillInfoDeleted: false };
    const selector = BillInfoSelector.selectIsBillInfoDeleted.projector(billState);
    expect(selector).toEqual(billState.isBillInfoDeleted);
  });

  it('selectBillListFilter - return bill list filter test', () => {
    const billState = { filterRecordModel: {billDueDt:false} };
    const selector = BillInfoSelector.selectBillListFilter.projector(billState);
    expect(selector).toEqual(billState.filterRecordModel);
  });

  it('selectPageLoad test', () => {
    const billListMock = { pageMode: PageMode.Add };
    const selector = BillInfoSelector.selectPageMode.projector(billListMock);
    expect(selector).toEqual(billListMock.pageMode);
  });
  it('selectselectedModule - test', () => {
    const billListMock = { selectedModule: PageMode.Add };
    const selector = BillInfoSelector.selectSelectedModule.projector(billListMock);
    expect(selector).toEqual(billListMock.selectedModule);
  });
  it('selectBillSearch - return filter data.', () => {
    const billsearchMock = {
        lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
        loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20',paymentAmountFrom:100,paymentAmountTo:1000,dateRange:'' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
        selectedBillDueDate: '2022-03-21',
        billDueDt: '2022-03-21',
      };
    const filterMock = {bilDueDt: '2022-02-22',paymentAmountFrom:100,paymentAmountTo:1000,dateRange:'' };
    const selector = BillInfoSelector.selectFilteredBills.projector(billsearchMock,filterMock);
    expect(selector).toEqual(billsearchMock.loanBillResponse.lnBilSrchRec);
  });
    it('selectBillSearch - return bill search without filter apply.', () => {
    const billsearchMock = {
        lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
        loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20',paymentAmountFrom:100,paymentAmountTo:1000,dateRange:'' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
        selectedBillDueDate: '2022-03-21',
        billDueDt: '2022-03-21',
      };
    const filterMock = {bilDueDt: '2022-02-22',paymentAmountFrom:0,paymentAmountTo:0,dateRange:'' };
    const selector = BillInfoSelector.selectFilteredBills.projector(billsearchMock,filterMock);
    expect(selector).toEqual(billsearchMock.loanBillResponse.lnBilSrchRec);
  });

  it('selectBillSearch - return bill search with filter apply on orgTotAmt.', () => {
    const billsearchMock = {
        lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
        loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20',orgTotAmt:1000,paymentAmountTo:1000,dateRange:'' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
        selectedBillDueDate: '2022-03-21',
        billDueDt: '2022-03-21',
      };
    const filterMock = {bilDueDt: '2022-02-22',paymentAmountFrom:0,paymentAmountTo:10000,dateRange:'' };
    const selector = BillInfoSelector.selectFilteredBills.projector(billsearchMock,filterMock);
    expect(selector).toEqual(billsearchMock.loanBillResponse.lnBilSrchRec);
  });

  it('selectBillSearch - return bill search with filter apply on orgTotAmt with paymentAmountFrom.', () => {
    const billsearchMock = {
        lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
        loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20',orgTotAmt:1000,paymentAmountTo:1000,dateRange:'' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
        selectedBillDueDate: '2022-03-21',
        billDueDt: '2022-03-21',
      };
    const filterMock = {bilDueDt: '2022-02-22',paymentAmountFrom:10,paymentAmountTo:0,dateRange:'' };
    const selector = BillInfoSelector.selectFilteredBills.projector(billsearchMock,filterMock);
    expect(selector).toEqual(billsearchMock.loanBillResponse.lnBilSrchRec);
  });

  it('selectBillSearch - return bill search with filter apply on bilduedate with date.', () => {
    const billsearchMock = {
        lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
        loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { bilDueDt: '2022-02-20',orgTotAmt:1000,paymentAmountTo:1000,dateRange:'' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
        selectedBillDueDate: '2022-03-21',
        billDueDt: '2022-03-21',
      };
    const filterMock = {bilDueDt: '2022-02-22',paymentAmountFrom:0,paymentAmountTo:0,dateRange:['2022-02-20','2022-02-22'] };
    const selector = BillInfoSelector.selectFilteredBills.projector(billsearchMock,filterMock);
    expect(selector).toEqual(billsearchMock.loanBillResponse.lnBilSrchRec);
  });

  it('selectBillSearch - return bill search with filter apply on billdue date with date.', () => {
    const billsearchMock = {
        lnBillInfoResponse: [{ lnbilInfoRec: { bilDueDt: '2022-02-20' } }, { lnbilInfoRec: { bilDueDt: '2022-02-22' } }],
        loanBillResponse: { lnBilSrchRec: [{ lnbilSrchRec: { orgTotAmt:1000,paymentAmountTo:1000,dateRange:'' } }, { lnbilSrchRec: { bilDueDt: '2022-02-22' } }] },
        selectedBillDueDate: '2022-03-21',
        billDueDt: '2022-03-21',
      };
    const filterMock = {bilDueDt: '2022-02-22',paymentAmountFrom:0,paymentAmountTo:0,dateRange:['2022-02-20','2022-02-22'] };
    const selector = BillInfoSelector.selectFilteredBills.projector(billsearchMock,filterMock);
    expect(selector).toEqual(billsearchMock.loanBillResponse.lnBilSrchRec);
  });

  it('selectFormState- returns formstate', () => {
    const selector = BillInfoSelector.selectFormState.projector('A',PageMode.Add,['2022-02-10']);
    const billFormMock={accountType:'A',pageMode:PageMode.Add, width: 'medium',
    editMode:PageMode.Add
    ,addedBillDueDtList:['2022-02-10'],billDueDtValidation:false};
    expect(selector).toEqual(billFormMock);
  });

  it('selectStatementDetailsFormState- returns formstate', () => {
    const selector = BillInfoSelector.selectStatementDetailsFormState.projector(PageMode.Add,{billInfo:{lnbilInfoRec:{printbillingnotice:true}}});
    const billFormMock={accountType:'',pageMode:PageMode.Inquiry, width: 'medium',
    editMode:PageMode.Inquiry
    ,addedBillDueDtList:[],billDueDtValidation:false};
    expect(selector).toEqual(billFormMock);
  });
});
