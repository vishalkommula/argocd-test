import { PageMode } from "./bill-fee-enums";

export interface BillFormStateModel {
    accountType: string;
    pageMode: PageMode;
    width: string;
    addedBillDueDtList: string[];
    billDueDtValidation: boolean;
    editMode: PageMode;
}
