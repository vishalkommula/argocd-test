import { FaultMsgRec, SearchMessageRequestHeaderModel } from '@uid/uid-models';
import { LnFeeInfoRecModel } from './loan-fee-info-record.model';

export interface LnFeeModResponse{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    lnFeeInfo: LnFeeInfoRecModel[];
    faultRecInfoArray: FaultMsgRec[];
    rsStat: boolean;
};
