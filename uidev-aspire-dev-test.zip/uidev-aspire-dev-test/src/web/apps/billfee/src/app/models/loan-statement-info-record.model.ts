export interface LnStmtInfoRecItemModel{
    crLineAmt?: number;
    balLstStmt?: number;
    curBal?: number;
    aggDays?: number;
    amtOfAdvas?: number;
    amtOfPmts?: number;
    pmtAmt?: number;
    annPctRate?: number;
    avalBal?: number;
    avgBal?: number;
    prevAmtStillPastDue?: number;
    fincChg?: number;
    rePrtFlg?: number;
    othChgs?: number;
    nxtPmtDueDt?: string;
    dlyPeriodicRate?: number;
    pastDuePmtAmt?: number;
};
