import { LnBilEscrwInfoRecModel } from './loan-bill-escrow-info-record.model';
import { LnFeeInfoRecModel } from './loan-fee-info-record.model';
import { LnStmtInfoRecItemModel } from './loan-statement-info-record.model';

export interface LnBilInfoRecItemModel{
    addBilDueDt?: string;
    bilDueDt?: string;
    bilPaidDt?: string;
    bilPrincAmt?: number;
    bilIntAmt?: number;
    bilEscrwAmt?: number;
    bilLateChgAmt?: number;
    bilOtherChgAmt?: number;
    remBilPrincAmt?: number;
    remBilIntAmt?: number;
    remBilEscrwAmt?: number;
    remBilLateChgAmt?: number;
    remBilOtherChgAmt?: number;
    totalBilled?: number;
    totalRemaining?: number;
    printbillingnotice?: boolean;
    nxtPayDt?: string;
    bilCrtDt?: string;
    lnFeeInfoRec?: LnFeeInfoRecModel[];
    lnBilEscrwInfoRec?: LnBilEscrwInfoRecModel;
    lnStmtInfoRec?: LnStmtInfoRecItemModel;
};
