import { PageMode } from "./bill-fee-enums";

export interface LoanFeeFormStateModel{
    accountType: string;
    editMode: PageMode;
    width: string;
    showACHAutoReturn: boolean;
};
