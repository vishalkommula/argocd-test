import {billFeeReducer, initialBillFeeState} from './billfee.reducer';

import * as BillInfoActions from '../actions/billInfo.action';
import lnBillInfoResponse from '../../mock-data/loanBillInqResponse.mock.json';
import escrowDetailsResponse from '../../mock-data/loanBillescrowResponse.mock.json';
import { LnBillAddModResponse } from '../../models/loan-bill-add-mod-response.model';
import { GridCellModifiedData } from '../../models/gridCellModifiedData.model';
import { SLLnBilEscrwPmtBalInfoRecItem } from '../../models/sl-loan-bill-escrow-pmt-bal-info-record.model';
import * as feeMock from '../../mock-data/loanBillFeeResponse.mock.json';

import * as BillFeeActions from '../actions/billfee.action';
import * as EscrowInfoActions from '../actions/billescrow.action';
import { LoanBillFeeResponseModel } from '../../models/loan-bill-fee-response.model';
import { LnFeeInfoRecModel } from '../../models/loan-fee-info-record.model';
import { LnBilSrchResponseModel } from '../../models/loan-bill-search-response.model';
import { LnBilSrchFilterModel } from '../../models/loan-bill-search-filter.model';
import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';

import { PageMode } from '../../models/bill-fee-enums';
import { LnFeeModResponse} from '../../models/loan-bill-fee-mod-response.model';

const expectedState = {
    loanBillFeeResponse: {},
    updatedLoanFeeResponse: {},
    currentBillFeeRecord: {},
    pageMode: PageMode.Inquiry,
    loanBillResponse: {},
    selectedBillDueDate: '',
    lnBillInfoResponse: [],
    isBillInfoUpdated: false,
    isBillInfoDeleted: false,
    filterRecordModel: {},
    escrowDetailsResponse: {},
    escrowDetailsEditResponse: {},
    selectedModule: 'Bills'
};

const responseData = { data: 'data' };

describe('Bill Fee Reducers test', () => {

    it('getBillListSuccess - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.getBillListSuccess({response: responseData as any}));
        expectedState.loanBillResponse = responseData;
        expect(state).toEqual(expectedState);
    });

    it('setBillListFilter - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.setBillListFilter({filterRecordModel: responseData as any}));
        expectedState.filterRecordModel = responseData;
        expectedState.loanBillResponse = {};
        expect(state).toEqual(expectedState);
    });

    it('clearBillListFilter - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.clearBillListFilter());
        expectedState.filterRecordModel = {};
        expectedState.loanBillResponse = {};
        expect(state).toEqual(expectedState);
    });

    it('getBillDetailsError - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.getBillDetailsError({error: responseData as any}));
        expectedState.loanBillResponse = {};
        expect(state).toEqual(expectedState);
    });

    it('updateSelectedBillDueDate - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.updateSelectedBillDueDate({dueDate: ''}));
        expectedState.selectedBillDueDate = '';
        expectedState.pageMode = PageMode.Inquiry;
        expect(state).toEqual(expectedState);
    });

    it('updateBillDetailsError - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.updateBillDetailsError({billModResponse: false}));
        expect(state).toEqual(expectedState);
    });

    it('addBillDetailsSuccess - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.addBillDetailsSuccess({billAddResponse: responseData as any}));
        expectedState.pageMode = PageMode.Inquiry;
        expect(state).toEqual(expectedState);
    });

    it('addBillDetailsError - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.addBillDetailsError({billAddResponse: true}));
        expect(state).toEqual(expectedState);
    });

    it('deleteBillDetailsSuccess - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.deleteBillDetailsSuccess({deleteResponse: responseData as any}));
        expect(state).toEqual(expectedState);
    });

    it('deleteBillDetailsSuccess - should be executed with success',()=>{
        const action = {rsStat: true};
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.deleteBillDetailsSuccess({deleteResponse: action as any}));
        expectedState.isBillInfoDeleted = true;
        expect(state).toEqual(expectedState);
        expectedState.isBillInfoDeleted = false;
    });

    it('deleteBillDetailsError - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.deleteBillDetailsError({deleteResponse: true}));
        expect(state).toEqual(expectedState);
    });

    it('changePageMode - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.changePageMode({clickAction: PageMode.Add}));
        expectedState.pageMode = PageMode.Add;
        expect(state).toEqual(expectedState);
    });

    it('blockOverrideDialog - should be executed',()=>{
        const state = billFeeReducer(initialBillFeeState, BillInfoActions.blockOverrideDialog({blockOverrideDialog: true}));
        expectedState.pageMode = PageMode.Inquiry;
        expect(state).toEqual(expectedState);
    });

    it('getBillDetailsSuccess - should be executed',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const action = newState.lnBillInfoResponse[0];
        const state = billFeeReducer(newState,BillInfoActions.getBillDetailsSuccess({loanBillInfoResponse: action}));
        newState.pageMode = PageMode.Inquiry;
        newState.isBillInfoUpdated = false;
        newState.selectedBillDueDate = action.lnbilInfoRec.bilDueDt ?? '';
        expect(state).toEqual(newState);
    });

    it('getBillDetailsSuccess - should be executed for new bill due date',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = [lnBillInfoResponse[0] as any];
        const action = lnBillInfoResponse[1];
        const state = billFeeReducer(newState,BillInfoActions.getBillDetailsSuccess({loanBillInfoResponse: action as any}));
        newState.pageMode = PageMode.Inquiry;
        newState.isBillInfoUpdated = false;
        newState.lnBillInfoResponse = [lnBillInfoResponse[0] as any,lnBillInfoResponse[1] as any];
        newState.selectedBillDueDate = action.lnbilInfoRec.bilDueDt as any;
        expect(state).toEqual(newState);
    });


it('on page get loan fees success', () => {
        const newState = initialBillFeeState;
        const loanBillFeeResponseModel = {} as any;
        const loanFeeSuccess = billFeeReducer(initialBillFeeState, BillFeeActions.getLoanFeeSuccess({
        response: loanBillFeeResponseModel as any}));
        newState.loanBillFeeResponse = loanBillFeeResponseModel;
        newState.selectedModule = 'Fees';
        expect(loanFeeSuccess).toEqual(newState);
});

it('on get shadow fees', () => {
    const loanBillFeeRequestModel = {} as any;
    expectedState.loanBillFeeResponse  = billFeeReducer(initialBillFeeState, BillFeeActions.getShadowFees({request: loanBillFeeRequestModel as any}));expectedState.pageMode = PageMode.Inquiry;
    const shadowFeesResponse = expectedState;
    expect(shadowFeesResponse).toEqual(expectedState);
});

it('on page get shadow fees success', () => {
    const newState = initialBillFeeState;
    const loanBillFeeResponseModel = {} as any;
    const shadowFees = billFeeReducer(initialBillFeeState, BillFeeActions.getShadowFeeSuccess({
    response: loanBillFeeResponseModel as any}));
    newState.loanBillFeeResponse = loanBillFeeResponseModel;
    newState.pageMode = PageMode.Inquiry;
    expect(shadowFees).toEqual(newState);
});

it('on page set to inquiry  mode', () => {
    const newState = initialBillFeeState;
    const pagestate = billFeeReducer(initialBillFeeState, BillFeeActions.setPageToInquiryMode());
    newState.pageMode = PageMode.Inquiry;
    expect(pagestate).toEqual(newState);
});

it('on page set to edit mode', () => {
    const newState = initialBillFeeState;
    const pagestate = billFeeReducer(initialBillFeeState, BillFeeActions.setPageToEditMode());
    newState.pageMode = PageMode.Edit;
    expect(pagestate).toEqual(newState);
});

it('on cancel modified fee', () => {
    const newState = initialBillFeeState;
    const cancelmodifiedFee = billFeeReducer(initialBillFeeState, BillFeeActions.cancelModifiedFee());
    newState.pageMode = PageMode.Inquiry;
    expect(cancelmodifiedFee).toEqual(newState);
});

it('on row select', () => {
    const currentRecord: LnFeeInfoRecModel = {
            lnFeeCode: '815',
            lnFeeId: 6,
            lnFeeConcatDescription: 'Other Charges',
            capitalized: 'Yes',
            lnFeeSeq: 'Test Data',
            lnFeeDebtProtType: '',
            lnFeeDebtProtSeq: '',
            lnFeeAmt: 2000,
            lnFeeRemAmt: 9000,
            lnFeeLastPmtDt: '2021-04-03',
            lnFeeAssmntDt: '2021-04-20',
            lnBillDt: '2021-12-31',
            lnPaidDt: '2021-01-26',
            lnFeeWavDt: '2021-04-03',
            loanFeeCategory: '',
            shdwFeeBasis: ''
    };
    const newState = initialBillFeeState;
    newState.currentBillFeeRecord = currentRecord;
    const currentFeeRecord = billFeeReducer(initialBillFeeState, BillFeeActions.selectRecord({currentRecord: currentRecord}));
    expect(currentFeeRecord).toEqual(newState);
});

it('on formly model change', () => {
    const currentRecord: LnFeeInfoRecModel = {
            lnFeeCode: '815',
            lnFeeId: 6,
            lnFeeConcatDescription: 'Other Charges',
            capitalized: 'Yes',
            lnFeeSeq: 'Test Data',
            lnFeeDebtProtType: '',
            lnFeeDebtProtSeq: '',
            lnFeeAmt: 2000,
            lnFeeRemAmt: 9000,
            lnFeeLastPmtDt: '2021-04-03',
            lnFeeAssmntDt: '2021-04-20',
            lnBillDt: '2021-12-31',
            lnPaidDt: '2021-01-26',
            lnFeeWavDt: '2021-04-03',
            loanFeeCategory: '',
            shdwFeeBasis: ''
    };
    const newState = initialBillFeeState;
    newState.currentBillFeeRecord = currentRecord;
    const currentFeeRecord = billFeeReducer(initialBillFeeState, BillFeeActions.updateLoanFeeFormModel({updateFeeFormModel: currentRecord}));
    expect(currentFeeRecord).toEqual(newState);
});
it('on save modified fee success', () => {
    const newState = initialBillFeeState;
    newState.loanBillFeeResponse = feeMock as any;
    const data = newState.loanBillFeeResponse;
    const action: LnFeeModResponseModel={
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        lnFeeInfo: feeMock as any,
        faultRecInfoArray: [
            {} as any,{} as any
        ],
        rsStat: false
    };
    newState.updatedLoanFeeResponse = action;
    newState.pageMode = PageMode.Edit;
    const updatedResponse = billFeeReducer(initialBillFeeState, BillFeeActions.saveModifiedFeeSuccess({response: action}));
    expect(updatedResponse).toEqual(newState);
});

it('on save modified fee success if fault array is empty', () => {
    const newState = initialBillFeeState;
    newState.loanBillFeeResponse = feeMock as any;
    const data = newState.loanBillFeeResponse;
    const action: LnFeeModResponse={
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        lnFeeInfo: feeMock as any,
        faultRecInfoArray: [
        ],
        rsStat: false
    };
    newState.updatedLoanFeeResponse = action;
    newState.pageMode = PageMode.Inquiry;
    const updatedResponse = billFeeReducer(initialBillFeeState, BillFeeActions.saveModifiedFeeSuccess({response: action}));
    expect(updatedResponse).toEqual(newState);
});

    it('updateBillDetailsSuccess  - should be executed',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const data = newState.lnBillInfoResponse[0];
        const action: LnBillAddModResponse ={
            srchMsgRqHdr: data.srchMsgRsHdr as any,
            acctId: data.acctId,
            acctType: data.acctType,
            lnBilInfoRec: data.lnbilInfoRec,
            faultRecInfoArray: {} as any,
            rsStat: false
        };
        const state = billFeeReducer(newState,BillInfoActions.updateBillDetailsSuccess({billModResponse: action}));
        newState.pageMode = PageMode.Inquiry;
        expect(state).toEqual(newState);
    });

    it('updateBillDetailsSuccess - should be executed with fault record array',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const data = newState.lnBillInfoResponse[0];
        const action: LnBillAddModResponse ={
            srchMsgRqHdr: data.srchMsgRsHdr as any,
            acctId: data.acctId,
            acctType: data.acctType,
            lnBilInfoRec: data.lnbilInfoRec,
            faultRecInfoArray: [
                {} as any,{} as any
            ],
            rsStat: false
        };
        const state = billFeeReducer(newState,BillInfoActions.updateBillDetailsSuccess({billModResponse: action}));
        newState.pageMode = PageMode.Inquiry;
        newState.lnBillInfoResponse[0].faultRecInfoArray = action.faultRecInfoArray as any;
        expect(state).toEqual(newState);
    });

    it('updateBillInfoModel - should be executed',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const action = {updateBillInfoModel: newState.lnBillInfoResponse[0].lnbilInfoRec};
        const state = billFeeReducer(newState,BillInfoActions.updateBillInfoModel({updateBillInfoModel: action.updateBillInfoModel}));
        expect(state).toEqual(newState);
    });

    it('updateBillInfoModel - should be executed with invalid request',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const state = billFeeReducer(newState,BillInfoActions.updateBillInfoModel({updateBillInfoModel: {} as any}));
        expect(state).toEqual(newState);
    });

    it('updateBillInfoEscrowModel - should be executed',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const gridCellModifiedData: GridCellModifiedData<SLLnBilEscrwPmtBalInfoRecItem> = newState.lnBillInfoResponse[0].lnbilInfoRec.lnBilEscrwInfoRec?.escrowBalances as any;
        const action = {updateBillInfoEscrowModel: gridCellModifiedData, billDueDt: '2022-05-30'};
        const state = billFeeReducer(newState,BillInfoActions.updateBillInfoEscrowModel({updateBillInfoEscrowModel: action.updateBillInfoEscrowModel, billDueDt: action.billDueDt}));
        expect(state).toEqual(newState);
    });

    it('updateBillInfoEscrowModel - should be executed with invalid request',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const state = billFeeReducer(newState,BillInfoActions.updateBillInfoEscrowModel({updateBillInfoEscrowModel: {} as any, billDueDt: {} as any}));
        expect(state).toEqual(newState);
    });

    it('updateBillInfoEscrowDetails - should be executed',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const action = {updateBillEscrowDetails: newState.lnBillInfoResponse[0].lnbilInfoRec.lnBilEscrwInfoRec?.escrowInfo, billDueDt: '2022-05-30'};
        const state = billFeeReducer(newState,BillInfoActions.updateBillInfoEscrowDetails({updateBillEscrowDetails: action.updateBillEscrowDetails as any, billDueDt: action.billDueDt}));
        expect(state).toEqual(newState);
    });

    it('updateBillInfoEscrowModel - should be executed with invalid request',()=>{
        const newState = initialBillFeeState;
        newState.lnBillInfoResponse = lnBillInfoResponse as any;
        const state = billFeeReducer(newState,BillInfoActions.updateBillInfoEscrowDetails({updateBillEscrowDetails: {} as any, billDueDt: {} as any}));
        expect(state).toEqual(newState);
    });

    it('getEscrowSuccess - should be executed',()=>{
        const newState = initialBillFeeState;
        const state = billFeeReducer(newState, EscrowInfoActions.getEscrowSuccess({response: responseData as any}));
        expectedState.escrowDetailsResponse = responseData;
        const escrow = 'Escrow';
        expectedState.selectedModule = escrow;
        expect(state).toEqual(expectedState);
    });

    it('saveEscrowSuccess - should be executed',()=>{
        const newState = initialBillFeeState;
        const state = billFeeReducer(newState, EscrowInfoActions.saveEscrowSuccess({response: responseData as any}));
        expectedState.escrowDetailsEditResponse = responseData;
        expect(state).toEqual(expectedState);
    });

    it('updateEscrowBalance - should be executed',()=>{
        const newState = initialBillFeeState;
        newState.escrowDetailsResponse = escrowDetailsResponse as any;
        const gridCellModifiedData: GridCellModifiedData<SLLnBilEscrwPmtBalInfoRecItem> = newState.escrowDetailsResponse.lnBilEscrwInfoRec?.escrowBalances as any;
        const state = billFeeReducer(newState, EscrowInfoActions.updateEscrowBalance({cellModifiedData:gridCellModifiedData}));
        expect(state).toEqual(newState);
    });

    it('updateEscrowDetails - should be executed',()=>{
        const newState = initialBillFeeState;
        newState.escrowDetailsResponse = escrowDetailsResponse as any;
        const action = {updateEscrowDetails: newState.escrowDetailsResponse.lnBilEscrwInfoRec.escrowInfo};
        const state = billFeeReducer(initialBillFeeState, EscrowInfoActions.updateEscrowDetails({updateEscrowDetails:action.updateEscrowDetails}));
        expect(state).toEqual(newState);
    });


});
