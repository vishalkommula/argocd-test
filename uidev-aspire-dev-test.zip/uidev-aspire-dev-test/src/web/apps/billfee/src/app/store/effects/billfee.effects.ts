import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType} from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { LnFeeModResponse } from '../../models/loan-bill-fee-mod-response.model';
import { DataService } from '../../service/data.service';
import * as feeActions from '../actions/billfee.action';


@Injectable()
export class BillFeesEffects{
    constructor(private dataservice: DataService, private action$: Actions){}

    loadBillFeeResponse$ =  createEffect(() =>
     this.action$.pipe(
        ofType(feeActions.getLoanFees),
        switchMap((action) => this.dataservice.getLoanFees(action.request)
        .pipe(
            map((response: any) => feeActions.getLoanFeeSuccess({response})),
            catchError((error) => of(feeActions.getLoanFeeError({error})))
        )
    )));

    // effect for shadowfee
    shadowBillFeeResponse$ = createEffect(() =>
      this.action$.pipe(
        ofType(feeActions.getShadowFees),
        switchMap((action) => this.dataservice.getShadowFees(action.request)
        .pipe(
    map((response: any) => feeActions.getShadowFeeSuccess({response})),
    catchError((error) => of(feeActions.getShadowFeeError({error})))
        )
    )));

    // effect for updating date
    updateBillFeeRecord$ = createEffect(() =>
    this.action$.pipe(
      ofType(feeActions.saveModifiedFee),
      switchMap((action) => this.dataservice.setUpdatedBillFee(action.request)
      .pipe(
        map((response: LnFeeModResponse) => feeActions.saveModifiedFeeSuccess({response})),
        catchError((error) => of(feeActions.saveModifiedFeeError({error})))
            )
      )));

}
