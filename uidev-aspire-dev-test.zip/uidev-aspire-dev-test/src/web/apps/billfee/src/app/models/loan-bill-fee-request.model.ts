import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface LoanBillFeeRequestModel{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
};
