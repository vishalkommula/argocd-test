// import { LnFeeInfoModel } from './loan-fee-info.model';

export interface LnFeeInfoRecModel{
    // loanFeeInfoArray: LnFeeInfoModel[];
    lnFeeId: number;
    lnFeeConcatDescription: string;
    loanFeeCategory: string;
    capitalized: string;
    lnFeeSeq: string;
    lnFeeDebtProtType: string;
    lnFeeDebtProtSeq: string;
    shdwFeeBasis: string;
    lnFeeLastPmtDt: string;
    lnFeeRemAmt: number;
    lnFeeCode: string;
    lnFeeAmt: number;
    lnFeeAssmntDt: string;
    lnBillDt: string;
    lnPaidDt: string;
    lnFeeWavDt: string;
};
