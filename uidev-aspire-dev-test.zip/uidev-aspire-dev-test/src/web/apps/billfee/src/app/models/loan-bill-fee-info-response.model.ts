import { SearchMessageResponseHeaderModel } from '@uid/uid-models';
import { LnBilInfoRecItemModel } from './loan-bill-info-record-item.model';
import { LnFeeInfoRecModel } from './loan-fee-info-record.model';

export interface LnBilInfoResponseModel{
    srchMsgRsHdr:    SearchMessageResponseHeaderModel;
    acctId:          string;
    acctType:        string;
    lnbilInfoRec:    LnBilInfoRecItemModel;
    lnFeeInfoRec:    LnFeeInfoRecModel[];
};
