export enum FeesType {
    loanFees = 'loanFees',
    shadowFees = 'shadowLoanFees',
}
