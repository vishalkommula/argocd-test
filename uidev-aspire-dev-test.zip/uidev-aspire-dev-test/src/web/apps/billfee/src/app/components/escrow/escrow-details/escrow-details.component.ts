import { Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit, Output, SimpleChange, SimpleChanges, ViewChild } from '@angular/core';
import { Store } from '@ngrx/store';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';

// Ngrx store
import { CellEditRequestEvent, ColDef, GridApi, GridOptions, GridReadyEvent, GridSizeChangedEvent } from 'ag-grid-community';
import * as EscrowActions from '../../../store/actions/billescrow.action';
import * as EscrowSelector from '../../../store/selectors/billescrow.selector';
import * as BillInfoActions from '../../../store/actions/billInfo.action';
import { EscrowgridcoldefService } from './escrow-grid-coldef.service';
import { BillFeeState } from '../../../store/states/billfee.state';

// Libs
import { UidGridAngular } from '@uid/uid-directives';
import { formatFaultMessages } from '@uid/uid-utilities';

// Models
import { BillFeeModulesEnum, BillFeeRoutesEnum, PageMode } from '../../../models/bill-fee-enums';
import { LnBilEscrwEditSrchRequest } from '../../../models/loan-bill-escrow-edit-request.model';
import { LnBilEscrwInfoRecModel } from '../../../models/loan-bill-escrow-info-record.model';
import { SLLnBilEscrwPmtBalInfoRecItem } from '../../../models/sl-loan-bill-escrow-pmt-bal-info-record-item.model';
import { GridCellModifiedData } from '../../../models/grid-cell-modified-data.model';
import { SLLnBilEscrwInfoRecItemModel } from '../../../models/sl-loan-bill-escrow-info-record-item.model';
import { FaultMsgRec } from '@uid/uid-models';

@Component({
  selector: 'uid-escrow-details',
  templateUrl: './escrow-details.component.html',
  styleUrls: ['./escrow-details.component.scss'],
})
export class EscrowDetailsComponent implements OnInit,OnChanges {
  @ViewChild('uidGrid')
  uidGrid = {} as UidGridAngular;
  @ViewChild('editUid')
  editUid = {} as UidGridAngular;
  escrowDetails!: LnBilEscrwInfoRecModel;

  defaultColDef!: ColDef;
  columnDefs!: ColDef[];
  gridOptions!: GridOptions;
  gridApi!: GridApi;

  nonEscrwPmtRem!: number;
  nonEscrwPmt!: number;
  rowHeight = 30;

  escrowBalance!: SLLnBilEscrwPmtBalInfoRecItem[];
  pageModeEnum = PageMode;
  billScreenTypeEnum = BillFeeModulesEnum;
  billScreenRoute = BillFeeRoutesEnum;

  escrowSelector = EscrowSelector;
  escrowActions = EscrowActions;
  billInfoActions = BillInfoActions;
  public screenType!: string;

//  Input Varibles
  @Input() billDueDt!: string;
  @Input() set pageType(pageType: string) {
    this.screenType = pageType;
  }
  @Input() escrowPageMode!: PageMode;
  @Input() escrowData: any;

  constructor(private store: Store<BillFeeState>, private gridDef: EscrowgridcoldefService, private router: Router) {
  }

  ngOnInit(): void {
    this.gridOptions = this.gridDef.gridOptions;
  }
  // TODO : Replace ngOnChanges with event emitters.
  ngOnChanges(changes: SimpleChanges) {
    if(changes['escrowPageMode']){
      if(this.escrowPageMode=== PageMode.Inquiry){
        this.defaultColDef = this.gridDef.default;
        this.columnDefs = this.gridDef.readonlyColumns;
        if (this.gridOptions !== undefined && Object.keys(this.gridOptions).length !== 0) {
          this.gridOptions.rowHeight = this.rowHeight;
          this.gridOptions.stopEditingWhenCellsLoseFocus = false;
          this.gridOptions.singleClickEdit = false;
          this.gridOptions.readOnlyEdit = false;
          this.gridOptions.api?.stopEditing();
        }
      }else if(this.escrowPageMode===PageMode.Edit){
        this.defaultColDef = this.gridDef.defaultEditableScreen;
        this.columnDefs = this.gridDef.editableColumns;
        this.gridOptions.stopEditingWhenCellsLoseFocus = true;
        this.gridOptions.singleClickEdit = true;
        this.gridOptions.rowHeight = this.rowHeight;
        this.gridOptions.readOnlyEdit = true;
        this.gridOptions.onCellEditRequest = (event: CellEditRequestEvent) => {
          this.onCellEditRequest(event);
        };
      }
    }
    if(changes['escrowData']){
      this.escrowDetails = this.escrowData;
      if (this.escrowDetails !== undefined && this.escrowDetails !== null) {
        this.nonEscrwPmt = this.escrowDetails.escrowInfo.nonEscrwPmt??0;
        this.nonEscrwPmtRem = this.escrowDetails.escrowInfo.nonEscrwPmtRem??0;
      }
    }
  }

  onGridReady(event: GridReadyEvent) {
    event?.api?.closeToolPanel();
    event?.api?.sizeColumnsToFit();
    // this.escrowBalance = event.api.getRowData
    this.gridApi = event?.api;
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
    event.api.sizeColumnsToFit();
  }

  onCellEditRequest(event: any) {
    const tempNewRowData = {};
    Object.entries(event.data as SLLnBilEscrwPmtBalInfoRecItem).find(([key, value]) => {
      console.log('key, value is : ' + key.toString() + '-' + value.toString());
      if (key === event.colDef.field) {
        (tempNewRowData as any)[key] = event.newValue;
      } else {
        (tempNewRowData as any)[key] = value;
      }
    });
    const cellModifiedData: GridCellModifiedData<SLLnBilEscrwPmtBalInfoRecItem> = {
      uniqueRowIdentifier: event.data.balFldAff,
      oldData: event.oldValue,
      newData: event.newValue,
      oldRowData: event.data,
      newRowData: tempNewRowData as SLLnBilEscrwPmtBalInfoRecItem,
      field: event.colDef.field as string,
    };
    if (this.screenType === this.billScreenTypeEnum.escrow) {
      this.store.dispatch(this.escrowActions.updateEscrowBalance({ cellModifiedData: cellModifiedData }));
    } else if (this.screenType === this.billScreenTypeEnum.billsEscrow) {
      this.store.dispatch(this.billInfoActions.updateBillInfoEscrowModel({ updateBillInfoEscrowModel: cellModifiedData, billDueDt: this.billDueDt }));
    }
  }

  onFirstDataRendered(params: any) {
    const allColumnIds: any = [];
    params.columnApi.getAllColumns().forEach((column: any) => allColumnIds.push(column.colId));
    params.columnApi.autoSizeColumns(allColumnIds, false);
  }

  nonEscrwPmtUpdate(value: any) {
    const escrowInfo: SLLnBilEscrwInfoRecItemModel = {
      nonEscrwPmt: this.nonEscrwPmt,
      nonEscrwPmtRem: this.nonEscrwPmtRem,
    };
    this.updateEscorwInfo(escrowInfo);
  }

  updateEscorwInfo(escrowInfo: SLLnBilEscrwInfoRecItemModel) {
    if (this.screenType === this.billScreenTypeEnum.escrow) {
      this.store.dispatch(this.escrowActions.updateEscrowDetails({ updateEscrowDetails: escrowInfo }));
    } else if (this.screenType === this.billScreenTypeEnum.billsEscrow) {
      this.store.dispatch(this.billInfoActions.updateBillInfoEscrowDetails({ updateBillEscrowDetails: escrowInfo, billDueDt: this.billDueDt }));
    }
  }

  loadBillDetailsForDueDate(){
    this.router.navigate([this.billScreenRoute.billsScreen],{state: {billDueDate: this.escrowDetails.billDt}});
  }
}
