import { SearchMessageResponseHeaderModel } from '@uid/uid-models';
import { LnFeeInfoRecModel } from './loan-fee-info-record.model';

export interface LoanBillFeeResponseModel{
    srchMsgRsHdr:    SearchMessageResponseHeaderModel;
    acctId:          string;
    acctType:        string;
    showACHAutoReturn: boolean;
    lnFeeInfoRec:    LnFeeInfoRecModel[];
};
