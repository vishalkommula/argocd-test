import { ActionsSubject } from '@ngrx/store';
import { of, throwError } from 'rxjs';
import mockData from '../../mock-data/loanBillFeeResponse.mock.json';
import shadowfeemockdata from '../../mock-data/shadowFeeResponse.mock.json';
import { LoanBillFeeResponseModel } from '../../models/loan-bill-fee-response.model';
import { getLoanFeeError, getLoanFeeSuccess, getShadowFeeError, getShadowFeeSuccess, saveModifiedFeeError, saveModifiedFeeSuccess } from '../actions/billfee.action';
import { BillFeesEffects } from './billfee.effects';
import * as feeActions from '../actions/billfee.action';
import { LnFeeModResponseModel } from '../../models/loan-bill-fee-mod-response.model';

// getFees method in service success mock
const billFeeServiceSuccessMock = {
    getLoanFees:       () => of(mockData),
    getShadowFees:     () => of(shadowfeemockdata),
    setUpdatedBillFee: () => of({
        'lnFeeId' : 1,
        'lnFeeRemAmt': '$2,000.00',
        'lnPaidDt': '03/03/2022'}),
};

// getFees method in service failure mock
const billFeeServiceErrorMock = {
    getLoanFees:       () => throwError('Error in getting fees'),
    geShadowFees:     () => throwError('Error in getting fees'),
    setUpdatedBillFee: () => throwError('Error in getting fees')
};

let actions: ActionsSubject;
let effects: BillFeesEffects;

describe('BillFees Effects Test', ()=> {
    beforeEach(() => {
        actions = new ActionsSubject();
    });

    // check loanbillfee success response
it('loadBillFeeResponse$ dispatch success action', ()=> {
    effects = new BillFeesEffects(billFeeServiceSuccessMock as any, actions);
    effects.loadBillFeeResponse$.subscribe((response) => {
        expect(response).toEqual(getLoanFeeSuccess({response: {} as LoanBillFeeResponseModel}));
    });
    const action = feeActions.getLoanFees({request: {} as any});
    actions.next(action);
});

// check loanbillfee error response
it('loanBillFeeReponse$ dispatch error action', () => {
    effects = new BillFeesEffects(billFeeServiceErrorMock as any, actions);
    effects.loadBillFeeResponse$.subscribe((response) => {
            expect(response).toEqual(getLoanFeeError({error: {} as Error}));
});
    const action = feeActions.getLoanFees({request: {} as any});
    actions.next(action);
});

    // check shadowfee loan success response
it('shadowBillFeeResponse$ dispatch success action', ()=> {
    effects = new BillFeesEffects(billFeeServiceSuccessMock as any, actions);
    effects.shadowBillFeeResponse$.subscribe((response) => {
            expect(response).toEqual(getShadowFeeSuccess({response: {} as LoanBillFeeResponseModel}));
    });
    const action = feeActions.getShadowFees({request: {} as any});
    actions.next(action);
});

    // check shadowfee error response
it('loanBillFeeReponse$ dispatch error action', () => {
    effects = new BillFeesEffects(billFeeServiceErrorMock as any, actions);
    effects.shadowBillFeeResponse$.subscribe((response) => {
        expect(response).toEqual(getShadowFeeError({error: {} as Error}));
     });
     const action = feeActions.getShadowFees({request: {} as any});
     actions.next(action);
});

 // check updatefee loan success response
it('updateBillFeeResponse$ dispatch success action', ()=> {
    effects = new BillFeesEffects(billFeeServiceSuccessMock as any, actions);
    effects.updateBillFeeRecord$.subscribe((response) => {
        expect(response).toEqual(saveModifiedFeeSuccess({response: {} as LnFeeModResponseModel}));
    });
    const action = feeActions.saveModifiedFee({request: {} as any});
    actions.next(action);
});

it('updateBillFeeResponse$ dispatch success action', ()=> {
    effects = new BillFeesEffects(billFeeServiceErrorMock as any, actions);
    effects.updateBillFeeRecord$.subscribe((response) => {
        expect(response).toEqual(saveModifiedFeeError({error: {} as Error}));
    });
    const action = feeActions.saveModifiedFee({request: {} as any});
    actions.next(action);
});

});

