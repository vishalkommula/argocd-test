import { Component, OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';

@Component({
  selector: 'uid-display-record-field',
  templateUrl: './display-record-field.component.html',
  styleUrls: ['./display-record-field.component.scss']
})
export class DisplayRecordFieldComponent extends FieldType {}