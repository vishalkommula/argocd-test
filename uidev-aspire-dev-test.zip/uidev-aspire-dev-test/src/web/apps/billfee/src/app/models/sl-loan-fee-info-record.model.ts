import { LnFeeInqRecItemModel } from './loan-fee-inquiry-record-item.model';

export interface SLLnFeeInfoRecModel{
    loanFeeCategory?: string;
    isSelected?: boolean;
    isEnabled?: boolean;
    lnFeeInqRec?: LnFeeInqRecItemModel;
};
