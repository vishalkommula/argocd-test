export interface SLLnBilEscrwPmtBalInfoRecItem{
    balFldAff?: number;
    escrwPmtBalDesc?: string;
    escrwPmtAmt?: number;
    escrwPmtAmtRem?: number;

};
