import { LnFeeInfoRecModel } from './loan-fee-info-record.model';


export interface SelectedLoanFeeModel{
   currentBillFeeRecord: LnFeeInfoRecModel;
   // canOverride: boolean;
};
