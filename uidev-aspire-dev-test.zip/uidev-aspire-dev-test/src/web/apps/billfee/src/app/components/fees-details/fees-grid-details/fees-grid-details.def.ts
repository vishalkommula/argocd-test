import { EventEmitter, Injectable, OnDestroy, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';

// ag grid
import { CellEditRequestEvent, ColDef, GridOptions, ValueFormatterParams, ValueParserParams } from 'ag-grid-community';

// uid-angular-controls
import {
  AgGridEditIconComponent,
  AgGridHyperlinkCellRendererComponent,
  AgGridPCalendarEditorComponent,
  AgGridPCalendarRendererComponent,
  AgGridPInputnumberEditorComponent,
  AgGridPInputnumberRendererComponent,
  ButtonRendererClickParms,
} from '@uid/uid-angular-controls';

// enums
import { FeesGridParentEnum, PageMode } from '../../../models/bill-fee-enums';

// models and components
import { FeeDetailAgGridCheckboxRendererComponent } from './fee-detail-ag-grid-checkbox-renderer/fee-detail-ag-grid-checkbox-renderer.component';
import { GridCellSelectedRecord } from '../../../models/grid-cell-selected-data.model';
import { LnFeeInfoRecModel } from '../../../models/loan-fee-info-record.model';
import { GridCellModifiedData } from '../../../models/grid-cell-modified-data.model';
import { formatISODate } from '@uid/uid-utilities';

// ngrx
import { Store } from '@ngrx/store';
import * as BillInfoActions from '../../../store/actions/billInfo.action';
import * as BillFeesSelectors from '../../../store/selectors/billfee.selector';


@Injectable({ providedIn: 'root' })
export class FeeGridDetailsDef implements OnDestroy {
  // bill due date is used to update attached fee in bill info.
  billDueDt = '';
  feesGridParentEnum = FeesGridParentEnum;
  billInfoActions = BillInfoActions;
  billFeeSelector = BillFeesSelectors;
  pageMode$!: Observable<PageMode>;
  @Output() emitSelectedOrDeSelectedFeeRecordDef = new EventEmitter<GridCellSelectedRecord<LnFeeInfoRecModel>>();
  @Output() editSelectedFee = new EventEmitter<any>();
  currentPageMode!: PageMode;
  // subscriptions
  subscriptions: Subscription[] = [];

  filterParams = {
    // provide comparator function

    comparator: (filterLocalDateAtMidnight: any, cellValue: any) => {

        if (cellValue == null) {
            return 0;
        }
        const dateAsString = cellValue;

        // In the example application, dates are stored as yyyy-mm-dd
        // We create a Date object for comparison against the filter date
        const dateParts = dateAsString.split('-');
        const year = Number(dateParts[0]);
        const month = Number(dateParts[1]) - 1;
        const day = Number(dateParts[2]);
        const cellDate = new Date(year, month, day);
         console.log(cellDate, 'celldate');

        // Now that both parameters are Date objects, we can compare
        if (cellDate < filterLocalDateAtMidnight) {
            return -1;
        } else if (cellDate > filterLocalDateAtMidnight) {
            return 1;
        }
        return 0;
    }
};

  // get fee-grid-details colDef
  columns: ColDef[] = [
    {
      field: 'lnFeeId',
      headerName: 'lnFeeId',
      hide: true,
      suppressMovable: true,
    },
    {
      field: 'lnFeeConcatDescription',
      headerName: 'Fee Description',
      rowGroup: true,
      suppressSizeToFit: true,
      hide: true,
      suppressMovable: true,
    },
    {
      field: 'lnFeeAssmntDt',
      headerName: 'Assessed Date',
      filter: 'agDateColumnFilter',
      cellClass: 'ag-right-aligned-cell',
      valueFormatter: this.dateFormatter,
      filterParams: this.filterParams,
      suppressMovable: true,
    },
    {
      field: 'lnBillDt',
      headerName: 'Due Date',
      filter: 'agDateColumnFilter',
      cellClass: 'ag-right-aligned-cell',
      valueFormatter: this.dateFormatter,
      cellRenderer: AgGridHyperlinkCellRendererComponent,
      cellRendererParams: {
        dataTestId: 'lnBillDt',
        dynamicField: 'lnFeeCode',
        hyperlinkCell:
          {
            click: this.onDueDateClick.bind(this),
          },

      },
      filterParams: this.filterParams,
      suppressMovable: true,
    },
    {
      field: 'lnPaidDt',
      headerName: 'Paid Date',
      filter: 'agDateColumnFilter',
      cellClass: 'ag-right-aligned-cell',
      valueFormatter: this.dateFormatter,
      filterParams: this.filterParams,
      suppressMovable: true,
      },
    {
      field: 'lnFeeAmt',
      headerName: 'Amount Assessed',
      aggFunc: 'sum',
      cellClass: 'ag-right-aligned-cell',
      valueFormatter: this.currencyFormatter,
      filterParams: {
        valueFormatter: this.currencyFormatter,
      },
      suppressMovable: true,
    },
    {
      field: 'lnFeeRemAmt',
      headerName: 'Amount Remaining',
      cellClass: 'ag-right-aligned-cell',
      aggFunc: 'sum',
      valueFormatter: this.currencyFormatter,
      filterParams: {
        valueFormatter: this.currencyFormatter,
      },
      suppressMovable: true,
    },
    {
      field: 'capitalized',
      cellClass: (params: any) => (params.value === this.feesGridParentEnum.FeeDetails ? 'ag-right-aligned-cell' : 'ag-left-aligned-cell'),
      suppressMovable: true,
    },
    {
      field: 'actionButtons',
      headerName: '',
      minWidth:60,
      maxWidth: 150,
      sortable: false,
      filter: false,
      cellRenderer: AgGridEditIconComponent,
      pinned: 'right',
      cellRendererParams: {
        buttonList: [
          {
            iconType: 'edit',
            onClick: this.onEdit.bind(this),
            dataTestId: 'editIcon',
            dynamicField: 'lnFeeCode',
          },
        ],
      },
    },
  ];

  // bills grid coldef
  billFeeGridColumns: ColDef[] = [
    {
      field: 'lnFeeId',
      headerName: 'lnFeeId',
      hide: true,
      suppressFiltersToolPanel: true,
      suppressColumnsToolPanel: true,
      suppressMovable: true,
    },
    {
      field: 'lnFeeConcatDescription',
      headerName: 'Fee Description',
      rowGroup: true,
      suppressSizeToFit: true,
      hide: true,
      suppressMovable: true,


    },
    {
      field: 'lnFeeAssmntDt',
      headerName: 'Assessed Date',
      filter: 'agDateColumnFilter',
      cellClass: 'ag-right-aligned-cell',
      valueFormatter: this.dateFormatter,
      filterParams: this.filterParams,
      suppressMovable: true,
    },
    {
      field: 'lnPaidDt',
      headerName: 'Paid Date',
      cellClass: 'ag-right-aligned-cell grid-cell-zero-padding',
      filter: 'agDateColumnFilter',
      valueFormatter: this.dateFormatter,
      filterParams: this.filterParams,
      suppressMovable: true,
    },
    {
      field: 'lnFeeAmt',
      headerName: 'Amount Assessed',
      cellClass: 'ag-right-aligned-cell',
      valueFormatter: this.currencyFormatter,
      filterParams: {
        valueFormatter: this.currencyFormatter,
      },
      suppressMovable: true,
    },
    {
      field: 'lnFeeRemAmt',
      headerName: 'Amount Remaining',
      cellClass: 'ag-right-aligned-cell grid-cell-zero-padding',
      valueFormatter: this.currencyFormatter,
      filterParams: {
        valueFormatter: this.currencyFormatter,
      },
      suppressMovable: true,
    },
    {
      field: 'capitalized',
      cellClass: 'ag-left-aligned-cell',
      suppressMovable: true,
    },
  ];
  // column type def
  columnTypes: { [key: string]: ColDef } = {
    numberValue: {
      enableValue: true,
      editable: false,
      valueParser: this.numberParser,
    },
    dimension: {
      enableRowGroup: true,
      enablePivot: true,
    },
  };
  // gridoptions
  public gridOptions: GridOptions = {
    columnDefs: this.columns,
    rowHeight: 31,
    paginationPageSize: 15,
    rowSelection: 'single',
    cacheBlockSize: 100,
    maxBlocksInCache: 25,
    suppressDragLeaveHidesColumns: true,
    frameworkComponents: {
      agGridEditIcon: AgGridEditIconComponent,
    },
  };
  // bill screen gridoptions
  public billAGridOptions: GridOptions = {
    columnDefs: this.billFeeGridColumns,
    rowHeight: 31,
    paginationPageSize: 15,
    rowSelection: 'single',
    cacheBlockSize: 100,
    maxBlocksInCache: 25,
    suppressDragLeaveHidesColumns: true,
    frameworkComponents: {
      agGridPInputnumber: AgGridPInputnumberRendererComponent,
      agGridPCalendar: AgGridPCalendarRendererComponent,
      feeAgGridPCheckbox: FeeDetailAgGridCheckboxRendererComponent,
      agGridPCalendarEditor: AgGridPCalendarEditorComponent,
      agGridPInputnumberEditor: AgGridPInputnumberEditorComponent,
    },
  };

  constructor(private router: Router, private store: Store) {
    this.pageMode$ = this.store.select(this.billFeeSelector.selectPageMode);
    const subPageMode = this.pageMode$.subscribe(pageModelState => { this.currentPageMode = pageModelState});
    // push all subscripbe into subscription array
    this.subscriptions.push(subPageMode);
  }
  // TODO:  Use the common date formatter and remove the below function.
  // format date to MM/dd/yyyy
  dateFormatter(params: ValueFormatterParams) {
    return formatISODate(params.value, 'MM/dd/yyyy');
  }
  currencyFormatter(params: ValueFormatterParams) {
    if (params.value !== undefined) {
      const currentRecord = params.value;
      const inrFormat = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
      });
      const formattedRecord = inrFormat.format(currentRecord);
      return formattedRecord;
    }
    return '';
  }



  //  on click of due date
  onDueDateClick(event: any) {
    // Allow Navigate only when pageMode is in Inquiry state
      if(this.currentPageMode === PageMode.Inquiry){
        this.router.navigate(['ui/billfee/bills'], { state: { billDueDate: event.rowData['lnBillDt'] } });
      }
  }
  // on click of edit icon
  onEdit(event: ButtonRendererClickParms): void {
    this.editSelectedFee.emit(event);
  }
  // define default column
  getDefaultColumnDef(editMode: boolean): ColDef {
    return {
      filter: !editMode,
      resizable: !editMode,
      sortable: !editMode,
      editable: false,
      enableValue: !editMode,
      enablePivot: false,
      enableRowGroup: !editMode,
      suppressMenu: editMode,
      suppressMovable: true,
    };
  }
  // get autogroup column def
  getautoGroupColumnDef(pageType: FeesGridParentEnum, pageMode: PageMode, isCheckboxdisable: boolean): ColDef {
    if (pageType === FeesGridParentEnum.FeeDetails) {
      return {
        field: 'lnFeeConcatDescription',
        cellRenderer: 'agGroupCellRenderer',
        headerName: 'Fee Description',
        minWidth: 210,
        valueGetter: this.feeDescriptionValueGetter,
      };
    } else {
      return {
        field: 'lnFeeConcatDescription',
        cellRenderer: 'agGroupCellRenderer',
        headerName: 'Fee Description',
        valueGetter: this.feeDescriptionValueGetter,
        minWidth: 230,
        cellRendererParams: {
          innerRenderer: 'feeAgGridPCheckbox',
         innerRendererParams: {
            pageMode: pageMode,
            dataTestId: 'lnFeeConcatDescription',
            isCheckboxdisable: isCheckboxdisable,
            emitSelectedValue: (params: any, clickStatus: boolean) => {
              if (params !== undefined) {
                const feeRecord: GridCellSelectedRecord<LnFeeInfoRecModel> = {
                  selectedRecord: params,
                  selectedStatus: clickStatus,
                };
                // TODO : emitter logic
                this.emitSelectedOrDeSelectedFeeRecordDef.emit(feeRecord);
              }
            },
            navFeeID: (feeID: string) => {
              // navigate to specific id
              this.router.navigateByUrl('ui/billfee/fees', { state: { selectedFeeID: feeID } });
            },
          },
        },
      };
    }
  }
  feeDescriptionValueGetter(params: any){
    return params.data.lnFeeCode + ' - ' + params.data.lnFeeConcatDescription;
  }
  // number parse
  numberParser(params: ValueParserParams) {
    return parseInt(params.newValue, 10);
  }
  modifyGridOptionsDef(pageMode: PageMode): GridOptions {
    this.billAGridOptions.domLayout = 'autoHeight';
    if (pageMode === PageMode.Add) {
      this.billAGridOptions.rowSelection = 'multiple';
      this.billAGridOptions.groupSelectsChildren = true;
      this.billAGridOptions.suppressRowClickSelection = true;
    } else if (pageMode === PageMode.Edit) {
      this.billAGridOptions.singleClickEdit = true;
      this.billAGridOptions.readOnlyEdit = true;
      this.billAGridOptions.rowSelection = 'single';
      this.billAGridOptions.groupSelectsChildren = false;
      this.billAGridOptions.suppressRowClickSelection = false;
      this.billAGridOptions.stopEditingWhenCellsLoseFocus = true;
      this.billAGridOptions.singleClickEdit = true;
      this.billAGridOptions.onCellEditRequest = (event: CellEditRequestEvent)=>{
        const tempNewRowData = {};
        Object.entries(event.data as LnFeeInfoRecModel).find(([key, value]) => {
          if (key === event.colDef.field) {
            (tempNewRowData as any)[key] = event.newValue;
          } else {
            (tempNewRowData as any)[key] = value;
          }
        });
        const cellModifiedData: GridCellModifiedData<LnFeeInfoRecModel> = {
          uniqueRowIdentifier: event.data.balFldAff,
          oldData: event.oldValue,
          newData: event.newValue,
          oldRowData: event.data,
          newRowData: tempNewRowData as LnFeeInfoRecModel,
          field: event.colDef.field as string,
        };
        this.store.dispatch(this.billInfoActions.updateAttachedFee({ cellModifiedData: cellModifiedData, billDueDt: this.billDueDt }));
      };;
    } else {
      this.billAGridOptions.rowSelection = 'single';
      this.billAGridOptions.groupSelectsChildren = false;
      this.billAGridOptions.suppressRowClickSelection = true;
    }
    return this.billAGridOptions;
  }

  // modify the column def
  modifyColumnDef(pageMode: PageMode): ColDef[] {
    if (pageMode !== PageMode.Edit) {
      this.billFeeGridColumns.forEach(function (colDef, index) {
        if (colDef.field === 'lnFeeRemAmt') {
          colDef.cellRenderer = '';
          colDef.cellEditor = '';
          colDef.editable = false;
          colDef.aggFunc=pageMode===PageMode.Add?'':'sum';
        }
        if (colDef.field === 'lnFeeAmt') {
          colDef.aggFunc=pageMode===PageMode.Add?'':'sum';
        }
        if (colDef.field === 'lnPaidDt') {
          colDef.cellRenderer = '';
          colDef.cellEditor = '';
          colDef.editable = false;
        }
        if (colDef.field === 'capitalized' && pageMode === PageMode.Add) {
          colDef.cellClass = 'ag-right-aligned-cell';
        }
      });
    } else {
      this.billFeeGridColumns.forEach(function (colDef) {
        if (colDef.field === 'lnFeeRemAmt') {
          colDef.aggFunc = '';
          colDef.cellRenderer = 'agGridPInputnumber';
          colDef.cellRendererParams = {
            minFractionDigits: 2,
            maxFractionDigits: 2,
            locale: 'en-US',
            step: 0.01,
            prefix: '$',
            mode: 'currency',
            currency: 'USD',
            maxlength: 15,
            inputStyleClass: 'prime-inputNumber',
            dataTestId: 'lnFeeRemAmt'
          };
          colDef.cellEditor = 'agGridPInputnumberEditor';
          colDef.cellEditorParams = {
            minFractionDigits: 2,
            maxFractionDigits: 2,
            locale: 'en-US',
            step: 0.01,
            prefix: '$',
            mode: 'currency',
            currency: 'USD',
            maxlength: 15,
            inputStyleClass: 'prime-inputNumber',
            dataTestId: 'lnFeeRemAmt'
          };
          colDef.editable = true;
        }
        if (colDef.field === 'lnPaidDt') {
          colDef.cellRenderer = 'agGridPCalendar';
          colDef.cellRendererParams = {
            hourFormat: '24',
            numberOfMonths: 1,
            selectionMode: 'single',
            required: false,
            readonlyInput: false,
            showTime: false,
            showButtonBar: false,
            showIcon: true,
            showOtherMonths: true,
            selectOtherMonths: false,
            monthNavigator: true,
            yearNavigator: true,
            yearRange: '2000:2030',
            inline: false,
            dataTestId: 'lnPaidDt',
          };
          colDef.cellEditor = 'agGridPCalendarEditor';
          colDef.cellEditorParams = {
            hourFormat: '24',
            numberOfMonths: 1,
            selectionMode: 'single',
            required: false,
            readonlyInput: false,
            showTime: false,
            showButtonBar: false,
            showIcon: true,
            showOtherMonths: true,
            selectOtherMonths: false,
            monthNavigator: true,
            yearNavigator: true,
            yearRange: '2000:2030',
            inline: false,
            dataTestId:'lnPaidDt',
          };
          colDef.editable = true;
        }
        if (colDef.field === 'lnFeeAmt') {
          colDef.aggFunc = '';
        }
        if (colDef.field === 'capitalized') {
          colDef.cellClass = 'ag-right-aligned-cell';
        }
      });
    }
    return this.billFeeGridColumns;
  }
  ngOnDestroy(){
    this.subscriptions.forEach(subs => subs.unsubscribe());
  }
}
