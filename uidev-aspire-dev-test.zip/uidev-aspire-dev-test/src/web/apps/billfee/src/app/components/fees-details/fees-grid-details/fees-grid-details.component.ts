import { Component, Input, OnInit, Output, ViewChild, EventEmitter, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
// directives
import { UidGridAngular } from '@uid/uid-directives';

// ag grid
import {ColDef, GridApi, GridOptions, GridReadyEvent, GridSizeChangedEvent, RowSelectedEvent, } from 'ag-grid-community';

// ngrx
import { Store } from '@ngrx/store';
import { selectPageMode } from '../../../store/selectors/billfee.selector';
// enums
import { FeesType } from '../fees-enum';
import { FeesGridParentEnum, PageMode } from '../../../models/bill-fee-enums';
// model
import { LnFeeInfoRecModel } from '../../../models/loan-fee-info-record.model';
import { GridCellSelectedRecord } from '../../../models/grid-cell-selected-data.model';
// service
import { FeeGridDetailsDef } from './fees-grid-details.def';

@Component({
  selector: 'uid-fees-grid-details',
  templateUrl: './fees-grid-details.component.html',
  styleUrls: ['./fees-grid-details.component.scss'],
})
export class FeesGridDetailsComponent implements OnInit, OnChanges {
  @ViewChild('uidGrid')
  uidGrid = {} as UidGridAngular;
  // set rowheight;
  rowHeight!: number;
  currentSelectedFeeId = '';
  public colDefs!: ColDef[];
  public defaultColDefs!: ColDef;
  public gridOptions!: GridOptions;
  public gridApi: GridApi = {} as GridApi; // change private to public accessModifier to mock the gidAPI
  public groupDefaultExpanded!: number;
  public autoGroupColumnDef!: ColDef;
  public columnTypes!: { [key: string]: ColDef };

  isBillFeeFormDirty = false;
  feesGridParentEnum = FeesGridParentEnum;
  // disable the checkbox under feedescription.
  isCheckboxdisable = true;
  feesTypeEnum = FeesType;
  @Input() feeData: any;
  @Input() pageType!: FeesGridParentEnum;
  @Input() feesType!: FeesType;
  @Input() billDueDt!: string;
  @Input() pageMode: PageMode;
  @Input() navLnFeeID!: string;
  // event emitter to add or remove the selected or deselected record.
  // TODO: remove and use generic class instead of any
  @Output() emitSelectedFee = new EventEmitter<any>();
  @Output() emitSelectedOrDeSelectedFeeRecord = new EventEmitter<GridCellSelectedRecord<LnFeeInfoRecModel>>();
  @Output() editSelectedFee = new EventEmitter<any>();

  gridColumnApi: any;

  getRowNodeId(params: any) {
    return params.lnFeeId;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.pageType === FeesGridParentEnum.FeeDetails) {
      if (changes['feeData']) {
        // To force retain the row selection everytime the grid data is changed, else for some reason the grid doesnt show the row as selected.
        this.forceHighlightSelectedGridRow();

      }

      if(changes['feesType'] && this.colDefs !== undefined){
        this.defaultColDefs = this.feeGridDetails.getDefaultColumnDef(false);
        this.forceHighlightSelectedGridRow();
        const feeTypeData=this.feesType;
        this.colDefs.forEach(function (colDef) {
        if (colDef.field === 'actionButtons') {
          if(feeTypeData === FeesType.shadowFees){
            colDef.hide = true;
          }else{
            colDef.hide = false;
          }
        }
      });
      }
    }
    if (this.pageType === FeesGridParentEnum.BillFee) {
      if (changes['pageMode']) {
        // logic to render the attached fee on readony bill screen
        this.gridOptions = this.feeGridDetails.modifyGridOptionsDef(this.pageMode);
        this.colDefs = this.feeGridDetails.modifyColumnDef(this.pageMode);
        this.defaultColDefs = this.feeGridDetails.getDefaultColumnDef(this.pageMode===PageMode.Inquiry ? false : true);
        // checkbox disable is true
        this.autoGroupColumnDef = this.feeGridDetails.getautoGroupColumnDef(this.pageType,this.pageMode,true);
        // set autogroup and columndef
        this.setModifiedColDefAndAutColDef(this.pageMode===PageMode.Edit ? 31 : 33);
      }
    }

    if(changes['billDueDt']){
      if(this.pageType===this.feesGridParentEnum.BillFee){
        this.feeGridDetails.billDueDt=this.billDueDt;
      }
    }
  }
  // update cell renderer params when bill due date is selected to enable the checkbox.
  @Input() set isBillduedtSelected(isBillduedtSelected: boolean) {
    if (this.pageMode === PageMode.Add) {
      this.isCheckboxdisable = !isBillduedtSelected;
      this.autoGroupColumnDef = this.feeGridDetails.getautoGroupColumnDef(this.pageType,this.pageMode ,this.isCheckboxdisable);
      this.gridApi.setAutoGroupColumnDef(this.autoGroupColumnDef);
      this.gridApi.setColumnDefs(this.colDefs);
    }
  }

  constructor(private store: Store, private feeGridDetails: FeeGridDetailsDef) {
    this.emitSelectedOrDeSelectedFeeRecord=this.feeGridDetails.emitSelectedOrDeSelectedFeeRecordDef;
    this.editSelectedFee=this.feeGridDetails.editSelectedFee;
    this.pageMode = PageMode.Inquiry;
    // TODO : add subcription and unsubscribe logic
    this.store.select(selectPageMode).subscribe((response) => {
      if (response !== undefined && response === PageMode.Edit) {
        this.isBillFeeFormDirty = true;
      } else {
        this.isBillFeeFormDirty = false;
      }
    });
  }

  ngOnInit(): void {
    // below property is used for expanding the grouped row.
    this.groupDefaultExpanded = 1;
    if (this.pageType === this.feesGridParentEnum.FeeDetails) {
      this.rowHeight = 31;
      this.defaultColDefs = this.feeGridDetails.getDefaultColumnDef(false);
      // assigning the column.
      this.colDefs = this.feeGridDetails.columns;
      this.columnTypes = this.feeGridDetails.columnTypes;
      this.gridOptions = this.feeGridDetails.gridOptions;
      // checkbox should be not disabled in initial load.
      this.autoGroupColumnDef = this.feeGridDetails.getautoGroupColumnDef(this.pageType,this.pageMode, false);
      this.gridOptions.suppressCellFocus = true;
    }
  }

  onGridSizeChanged(event: GridSizeChangedEvent) {
    event.api.sizeColumnsToFit();
  }

  onGridReady(event: GridReadyEvent) {
    this.gridApi = event.api;
    this.gridColumnApi = event.columnApi;
    event.api.closeToolPanel();
    event.api.sizeColumnsToFit();
    // this.autoSizeAll();
    if (this.pageType === FeesGridParentEnum.FeeDetails) {
      if (this.navLnFeeID !== '') {
        const firstRow = this.gridApi.getRowNode(this.navLnFeeID);
        firstRow?.setSelected(true);
      } else if (this.currentSelectedFeeId === '') {
        const firstRow = this.gridApi.getRowNode('2');
        firstRow?.setSelected(true);
      }
    }
  }

  forceHighlightSelectedGridRow(){
    if (this.currentSelectedFeeId !== ''){
      setTimeout(()=> {
        this.gridApi.getRowNode(this.currentSelectedFeeId)?.selectThisNode(true);
      },0);
    }
  }

  autoSizeAll() {
    const allColumnIds: any[] = [];
    this.gridColumnApi.getAllColumns().forEach((column: { getId: () => any }) => {
      allColumnIds.push(column.getId());
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds);
  }
  // function for row select event
  onRowSelect(e: RowSelectedEvent) {
    const grp = e.node.group;
    // || e.node.data.lnFeeCode == this.currentSelectedFeeId)
    if (grp) {
      //  e.node.expanded = !e.node.expanded;
      e.node.setSelected(false);
      // e.node.setExpanded(!e.node.expanded);
      if (this.pageType === FeesGridParentEnum.FeeDetails) {
        this.forceHighlightSelectedGridRow();
      }
      return;
    }
    // check page type
    if (this.pageType === FeesGridParentEnum.FeeDetails && this.currentSelectedFeeId !== e.node.data.lnFeeId) {
      // if billfee form in inquiry mode
      if (this.isBillFeeFormDirty === false) {
        if (e.node.isSelected()) {
          // e.node.setSelected(false);
          this.currentSelectedFeeId = e.node.data.lnFeeId;
          this.emitSelectedFee.emit(e);
        }
      }
      // if billfee form in edit mode
      else if (this.isBillFeeFormDirty === true) {
        this.emitSelectedFee.emit(false);
        e.node.setSelected(false);
        this.forceHighlightSelectedGridRow();
      }
    }
  }
  // update grid col and auto codef.
  setModifiedColDefAndAutColDef(setRowHeight: number){
    if (this.gridApi !== undefined && Object.keys(this.gridApi).length !== 0) {
      // set autogroup and columndef
      this.gridApi.stopEditing();
      this.gridApi.setAutoGroupColumnDef(this.autoGroupColumnDef);
      this.gridApi.setColumnDefs(this.colDefs);
      // set the height for allrownode
      this.gridApi.forEachNode(function (rowNode) {
        rowNode.setRowHeight(setRowHeight);
      });
      this.gridApi.onRowHeightChanged();
      this.gridApi.sizeColumnsToFit();
    }
  }
}
