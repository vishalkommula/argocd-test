import { FeesGridParentEnum, PageMode } from '../../../models/bill-fee-enums';
import { FeesType } from '../fees-enum';
import { FeesGridDetailsComponent } from './fees-grid-details.component';
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.spyOn(global, 'setTimeout');
const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(() => ({
    subscribe: jest.fn(),
  })),
};

const feeGridDetailsMock = {
  billDueDt: '',
  gridOptions: {
    suppressCellFocus: false,
  },
  modifyGridOptionsDef: jest.fn(),
  modifyColumnDef: jest.fn(),
  getDefaultColumnDef: jest.fn(),
  getautoGroupColumnDef: jest.fn(),
};

let component: FeesGridDetailsComponent;
// let fixture: ComponentFixture<FeesGridDetailsComponent>;
describe('Fee grid common', () => {
  beforeEach(() => {
    component = new FeesGridDetailsComponent(storeMock as any, feeGridDetailsMock as any);
  });

  // component creation
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('getRowNodeId returns feeID', () => {
    const params = { lnFeeId: 1 };
    expect(component.getRowNodeId(params)).toBe(1);
  });

  it('ngOnChanges for billFee pageType ', () => {
    component.pageType = FeesGridParentEnum.BillFee;
    const changes = { billDueDt: '2022-07-07' };
    component.ngOnChanges(changes as any);
    expect(component.billDueDt).toBe(feeGridDetailsMock.billDueDt);
  });

  it('ngOnChanges for billFee pageType and pageMode is inquiry', () => {
    component.pageType = FeesGridParentEnum.BillFee;
    component.setModifiedColDefAndAutColDef = jest.fn();
    const changes = { pageMode: PageMode.Inquiry };
    component.ngOnChanges(changes as any);
    expect(feeGridDetailsMock.getDefaultColumnDef).toBeCalledTimes(1);
    expect(feeGridDetailsMock.getautoGroupColumnDef).toBeCalledTimes(1);
    expect(feeGridDetailsMock.modifyColumnDef).toBeCalledTimes(1);
    expect(feeGridDetailsMock.modifyGridOptionsDef).toBeCalledTimes(1);
  });

  it('ngOnChanges for Fee pageType and shadow feetype ', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    const changes = { feesType: FeesType.shadowFees };
    component.feesType = FeesType.shadowFees;
    component.forceHighlightSelectedGridRow = jest.fn();
    component.colDefs = [
      {
        field: 'actionButtons',
        headerName: 'lnFeeId',
        suppressMovable: true,
        hide: false,
      },
      {
        field: 'lnFeeId',
        headerName: 'lnFeeId',
        hide: true,
        suppressMovable: true,
      },
    ];
    component.ngOnChanges(changes as any);
    const actionButtonField = component.colDefs.filter((x) => x.field === 'actionButtons')[0];
    expect(actionButtonField.hide).toBe(true);
    expect(feeGridDetailsMock.getDefaultColumnDef).toBeCalledTimes(2);
  });

  it('ngOnChanges for Fee pageType and loan feetype ', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    const changes = { feesType: FeesType.loanFees };
    component.feesType = FeesType.loanFees;
    component.forceHighlightSelectedGridRow = jest.fn();
    component.colDefs = [
      {
        field: 'actionButtons',
        headerName: 'lnFeeId',
        suppressMovable: true,
        hide: false,
      },
      {
        field: 'lnFeeId',
        headerName: 'lnFeeId',
        hide: true,
        suppressMovable: true,
      },
    ];
    component.ngOnChanges(changes as any);
    const actionButtonField = component.colDefs.filter((x) => x.field === 'actionButtons')[0];
    expect(actionButtonField.hide).toBe(false);
    expect(feeGridDetailsMock.getDefaultColumnDef).toBeCalledTimes(3);
  });
  it('ngOnChanges for Fee pageType with feeData change', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    const changes = { feeData: {} };
    component.feesType = FeesType.shadowFees;
    component.forceHighlightSelectedGridRow = jest.fn();
    component.ngOnChanges(changes as any);
    expect(component.forceHighlightSelectedGridRow).toBeCalledTimes(1);
  });

  it('ngOnInit for Fee pageType', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.feesType = FeesType.shadowFees;
    component.forceHighlightSelectedGridRow = jest.fn();
    component.ngOnInit();
    expect(feeGridDetailsMock.getDefaultColumnDef).toBeCalledTimes(4);
    expect(feeGridDetailsMock.getautoGroupColumnDef).toBeCalledTimes(2);
    expect(feeGridDetailsMock.modifyColumnDef).toBeCalledTimes(1);
    expect(feeGridDetailsMock.modifyGridOptionsDef).toBeCalledTimes(1);
  });

  it('onGridSizeChanged: should fire sizeColumnsToFit', () => {
    const event = { api: { sizeColumnsToFit: jest.fn() } };
    component.onGridSizeChanged(event as any);

    expect(event.api.sizeColumnsToFit).toBeCalledTimes(1);
  });

  it('onGridReady: should call closeToolPanel and sizeColumnsToFit', () => {
    const event = { api: { closeToolPanel: jest.fn(), sizeColumnsToFit: jest.fn() }, columnApi: { getAllColumns: jest.fn(), autoSizeColumns: jest.fn() } };
    component.pageType = FeesGridParentEnum.BillFee;
    component.autoSizeAll = jest.fn();
    component.onGridReady(event as any);
    expect(event.api.closeToolPanel).toBeCalledTimes(1);
    expect(event.api.sizeColumnsToFit).toBeCalledTimes(1);
  });

  it('onGridReady: highlight specific record by navFeeID', () => {
    const event = { api: { closeToolPanel: jest.fn(), sizeColumnsToFit: jest.fn(), getRowNode: jest.fn() }, columnApi: { getAllColumns: jest.fn(), autoSizeColumns: jest.fn() } };
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.currentSelectedFeeId = '';
    component.navLnFeeID = '1';
    component.autoSizeAll = jest.fn();
    component.onGridReady(event as any);
    expect(event.api.closeToolPanel).toBeCalledTimes(1);
    expect(event.api.sizeColumnsToFit).toBeCalledTimes(1);
  });

  it('onGridReady: highlight specific record by currentSelectedFeeId', () => {
    const event = { api: { closeToolPanel: jest.fn(), sizeColumnsToFit: jest.fn(), getRowNode: jest.fn() }, columnApi: { getAllColumns: jest.fn(), autoSizeColumns: jest.fn() } };
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.navLnFeeID = '';
    component.currentSelectedFeeId = '';
    component.autoSizeAll = jest.fn();
    component.onGridReady(event as any);
    expect(event.api.closeToolPanel).toBeCalledTimes(1);
    expect(event.api.sizeColumnsToFit).toBeCalledTimes(1);
  });

  it('forceHighlightSelectedGridRow: forcing the grid to select the row', () => {
    const event = { api: { closeToolPanel: jest.fn(), sizeColumnsToFit: jest.fn(), getRowNode: jest.fn() }, columnApi: { getAllColumns: jest.fn(), autoSizeColumns: jest.fn() } };
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.navLnFeeID = '';
    component.currentSelectedFeeId = '1';
    component.autoSizeAll = jest.fn();
    const _gripAPI = { getRowNode: jest.fn().mockImplementation(() => true), setAutoGroupColumnDef: jest.fn(), setColumnDefs: jest.fn() };
    component.gridApi = _gripAPI as any;
    component.forceHighlightSelectedGridRow();
    expect(_gripAPI.getRowNode).toBeCalledTimes(0);
    expect(setTimeout).toBeCalled();
  });

  it('autoSizeAll: change column size', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.gridColumnApi = { getAllColumns: jest.fn().mockImplementation(() => []), autoSizeColumns: jest.fn() };
    component.autoSizeAll();
    expect(component.gridColumnApi.getAllColumns).toBeCalledTimes(1);
    expect(component.gridColumnApi.autoSizeColumns).toBeCalledTimes(1);
  });

  it('isBillduedtSelected: setting isBillduedtSelected value ', () => {
    component.pageMode = PageMode.Add;
    const _gripAPI = { getRowNode: jest.fn().mockImplementation(() => true), setAutoGroupColumnDef: jest.fn(), setColumnDefs: jest.fn() };
    component.gridApi = _gripAPI as any;
    component.isBillduedtSelected = true;
    expect(feeGridDetailsMock.getautoGroupColumnDef).toBeCalledTimes(3);
  });

  it('setModifiedColDefAndAutColDef - sets gripAPI value', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.feesType = FeesType.shadowFees;
    component.forceHighlightSelectedGridRow = jest.fn();
    const gripAPI = { getRowNode: jest.fn().mockImplementation(() => true), forEachNode: jest.fn(rowNode=> rowNode.setRowHeight=jest.fn()),
      onRowHeightChanged: jest.fn(),
      setAutoGroupColumnDef: jest.fn(), setColumnDefs: jest.fn(), stopEditing: jest.fn() };
    component.gridApi=gripAPI as any;
    component.setModifiedColDefAndAutColDef(11);
    expect(gripAPI.stopEditing).toBeCalledTimes(1);
    expect(gripAPI.setAutoGroupColumnDef).toBeCalledTimes(1);
    // expect(gripAPI.forEachNode.call).toBeCalledTimes(1);
    expect(gripAPI.setColumnDefs).toBeCalledTimes(1);
    expect(gripAPI.forEachNode).toBeCalledTimes(1);
    expect(gripAPI.onRowHeightChanged).toBeCalledTimes(1);
  });

  it('onRowSelect - select the row if group is true', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.feesType = FeesType.shadowFees;
    const event={node:{group:true,setSelected:jest.fn().mockImplementation(()=>(true)),
      data:{lnFeeId:'1'},isSelected:jest.fn().mockImplementation(()=>(true))}};
    component.forceHighlightSelectedGridRow = jest.fn();
    component.currentSelectedFeeId='2';

    const gripAPI = { getRowNode: jest.fn().mockImplementation(() => true), forEachNode: jest.fn(rowNode=> rowNode.setRowHeight=jest.fn()),
      onRowHeightChanged: jest.fn(),
      setAutoGroupColumnDef: jest.fn(), setColumnDefs: jest.fn(), stopEditing: jest.fn() };
    component.gridApi=gripAPI as any;
    component.onRowSelect(event as any);
    expect(component.forceHighlightSelectedGridRow).toBeCalledTimes(1);
  });
 
  it('onRowSelect - select the row if group is false and isBillFeeFormDirty is false', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.feesType = FeesType.shadowFees;
    const event={node:{group:false,setSelected:jest.fn().mockImplementation(()=>(true)),
      data:{lnFeeId:'1'},isSelected:jest.fn().mockImplementation(()=>(true))}};
    component.forceHighlightSelectedGridRow = jest.fn();
    component.currentSelectedFeeId='2';
      component.isBillFeeFormDirty=false;
    const gripAPI = { getRowNode: jest.fn().mockImplementation(() => true), forEachNode: jest.fn(rowNode=> rowNode.setRowHeight=jest.fn()),
      onRowHeightChanged: jest.fn(),
      setAutoGroupColumnDef: jest.fn(), setColumnDefs: jest.fn(), stopEditing: jest.fn() };
    component.gridApi=gripAPI as any;
    component.emitSelectedFee={emit:jest.fn()} as any;
    component.onRowSelect(event as any);
    expect(component.forceHighlightSelectedGridRow).toBeCalledTimes(0);
    expect(component.emitSelectedFee.emit).toBeCalledTimes(1);
  });

  it('onRowSelect - select the row if group is false and isBillFeeFormDirty is true', () => {
    component.pageType = FeesGridParentEnum.FeeDetails;
    component.feesType = FeesType.shadowFees;
    const event={node:{group:false,setSelected:jest.fn().mockImplementation(()=>(true)),
      data:{lnFeeId:'1'},isSelected:jest.fn().mockImplementation(()=>(true))}};
    component.forceHighlightSelectedGridRow = jest.fn();
    component.currentSelectedFeeId='2';
      component.isBillFeeFormDirty=true;
    const gripAPI = { getRowNode: jest.fn().mockImplementation(() => true), forEachNode: jest.fn(rowNode=> rowNode.setRowHeight=jest.fn()),
      onRowHeightChanged: jest.fn(),
      setAutoGroupColumnDef: jest.fn(), setColumnDefs: jest.fn(), stopEditing: jest.fn() };
    component.gridApi=gripAPI as any;
    component.emitSelectedFee={emit:jest.fn()} as any;
    component.onRowSelect(event as any);
    expect(component.forceHighlightSelectedGridRow).toBeCalledTimes(1);
    expect(component.emitSelectedFee.emit).toBeCalledTimes(1);
  });
});
