// import { FaultMsgRec} from '../../models/loan-bill-error.model';
// import { LoanBillFeeResponseModel } from '../../models/loan-bill-fee-response.model';
// import { LnBilInfoRecItemModel } from '../../models/loan-bill-info-record-item.model';
// import { LnBilSrchFilterModel } from '../../models/loan-bill-search-filter.model';
// import { LnBilSrchResponseModel } from '../../models/loan-bill-search-response.model';

// export interface BillInfoState{
//     loanBillResponse: LnBilSrchResponseModel;
//     action: string;
//     billDueDate: string;
//     lnBilInfo: LnBilInfoRecItemModel[];
//     isBillInfoUpdated: boolean;
//     isBillInfoDeleted: boolean;
//     showoverridedialogbox: boolean;
//     faultRecInfoArray: FaultMsgRec[];
//     filterRecordModel: LnBilSrchFilterModel;
//     isBillInfoFormDirty: boolean;
// };
