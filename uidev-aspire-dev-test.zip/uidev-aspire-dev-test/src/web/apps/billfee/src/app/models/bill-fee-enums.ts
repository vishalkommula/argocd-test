export enum FeesGridParentEnum {
    BillFee = 1,
    FeeDetails,
    EscrowDetails
    // billEditMode='bill edit',
    // billAddMode='bill add',
    // billInquiryMode='bill view'
  }
  export enum PageMode {
    Inquiry = 'inquiry',
    Add = 'add',
    Edit = 'editMode'
  }
  // TODO : Pascal Case
  export const billFeeValueTypes= {
    lateCharge:'Late Charge',
    otherCharges:'Other Charges',
    donotSave:'Don\'t Save',
    deleteMsg:'Delete',
    deleteDialogBoxTitle:'Do you want to delete this bill?',
    cancelMsg:'Cancel',
    cancelDialogBoxTitle:'Do you want to save your changes?',
    cancelDialogBoxText:'Your changes will be lost if you don\'t save them.',
    overrideMsg:'Override',
    modelChanged:'Model Changed',
    displayedDateFormatter:'MM/dd/yyyy',
    isoDateFormatter:'yyyy-MM-dd',
    faultMsg:'Fault',
    errMsg:'Error',
    titleText: 'Detail',
    save:'Save'
};

export enum BillFeeFormDateTypeEnum{
  // type
  billTableType='bill-table-type',
  // wrapper
  displayRecord='record-detail-field',
  recordDetailNoRuiFormRenderer='record-detail-no-rui-form-renderer',
  // validators
  billDueDtInvalid='billDueDtInvalid',
  // validation message
  billDueDateValidationMsg='Invalid due date',

}
// TODO : remove and have in component.
export enum BillFeeRoutesEnum{
  billsScreen = 'ui/billfee/bills',
  feesScreen = 'ui/billfee/fees',
  escrowScreen = 'ui/billfee/escrow'
}
// TODO : Move to home component.
// TODO : change the hardcode in reducer.
export enum BillFeeModulesEnum {
  bills = 'Bills',
  fees = 'Fees',
  escrow = 'Escrow',
  billsEscrow = 'Bills Escrow',
}
