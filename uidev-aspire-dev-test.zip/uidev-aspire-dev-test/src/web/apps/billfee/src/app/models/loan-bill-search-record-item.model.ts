export interface LnBilSrchRecItemModel{
    bilDueDt?: string;
    bilCrtDt?: string;
    orgTotAmt?: number;
    totRemAmt?: number;
    status?: string;
};
