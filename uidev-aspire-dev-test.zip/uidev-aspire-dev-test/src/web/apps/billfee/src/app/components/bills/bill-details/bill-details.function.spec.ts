import { DateTime } from 'luxon';
import * as billDetailsFunction from './bill-details.function';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

describe('bill details function test', () => {
  it('getbilldetailform should return data', () => {
    const retVal = billDetailsFunction.getBillDetailFormField();
    expect(retVal).toBeTruthy();
  });

  it('isAddView should return true', () => {
    const retVal = billDetailsFunction.isAddView({} as any, { pageMode: 'editMode' } as any, {} as any);
    expect(retVal).toBeTruthy();
  });

  it('isAddView should return false when pageMode is add', () => {
    const retVal = billDetailsFunction.isAddView({} as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe(false);
  });

  it('isBillInfoView should return false when pageMode is inquiry', () => {
    const retVal = billDetailsFunction.isBillInfoView({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(retVal).toBe(false);
  });

  it('isBillInfoView should return true when pageMode is add', () => {
    const retVal = billDetailsFunction.isBillInfoView({} as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe(true);
  });

  it('isEditView should return true when pageMode is inquiry', () => {
    const retVal = billDetailsFunction.isEditView({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(retVal).toBe(true);
  });

  it('isEditView should return false when pageMode is edit', () => {
    const retVal = billDetailsFunction.isEditView({} as any, { pageMode: 'editMode' } as any, {} as any);
    expect(retVal).toBe(false);
  });

  it('isDetailsView should return false when pageMode is inquiry', () => {
    const retVal = billDetailsFunction.isDetailsView({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(retVal).toBe(false);
  });

  it('isDetailsView should return true when pageMode is edit', () => {
    const retVal = billDetailsFunction.isDetailsView({} as any, { pageMode: 'editMode' } as any, {} as any);
    expect(retVal).toBe(true);
  });

  it('isPrintNoDisplay should return true when pageMode is inquiry', () => {
    const retVal = billDetailsFunction.isPrintNoDisplay({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(retVal).toBe(true);
  });

  it('isPrintNoDisplay should return false when pageMode is add', () => {
    const retVal = billDetailsFunction.isPrintNoDisplay({} as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe(false);
  });

  it('isBillDueDtEmpty should return false when pageMode is add and addbilldue date is undeinfed', () => {
    const retVal = billDetailsFunction.isBillDueDtEmpty({ addBilDueDt: undefined } as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe(true);
  });

  it('isBillDueDtEmpty should return true when pageMode is add and addbilldue date is not empty', () => {
    const retVal = billDetailsFunction.isBillDueDtEmpty({ addBilDueDt: '2022-07-07' } as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe(false);
  });

  it('isBillDueDtEmpty should return false when pageMode is edit.', () => {
    const retVal = billDetailsFunction.isBillDueDtEmpty({ addBilDueDt: '2022-07-07' } as any, { pageMode: 'editMode' } as any, {} as any);
    expect(retVal).toBe(false);
  });

  it('isBillDetailView should return false when pageMode is inquiry', () => {
    const retVal = billDetailsFunction.isBillDetailView({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(retVal).toBe(true);
  });

  it('isBillDetailView should return true when pageMode is add.', () => {
    const retVal = billDetailsFunction.isBillDetailView({} as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe(false);
  });

  it('prntValueClass should return col-md-3 when pageMode is add', () => {
    const retVal = billDetailsFunction.prntValueClass({} as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe('col-md-3');
  });

  it('prntValueClass should return col-md-2 when pageMode is inquiry', () => {
    const retVal = billDetailsFunction.prntValueClass({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(retVal).toBe('col-md-2');
  });

  it('prntLabelClass should return col-md-4 when pageMode is add', () => {
    const retVal = billDetailsFunction.prntLabelClass({} as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe('col-md-4');
  });

  it('prntLabelClass should return col-md-10 when pageMode is inquiry', () => {
    const retVal = billDetailsFunction.prntLabelClass({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(retVal).toBe('col-md-10');
  });

  it('tableWidth should return 500px when pageMode is add', () => {
    const retVal = billDetailsFunction.tableWidth({} as any, { pageMode: 'add' } as any, {} as any);
    expect(retVal).toBe('500px');
  });

  it('tableWidth should return 368px when pageMode is add', () => {
    const retVal = billDetailsFunction.tableWidth({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(retVal).toBe('368px');
  });

  it('billInfoScreenStyle should return text align as right when pageMode is inquiry & key is totalBilled', () => {
    const retVal = billDetailsFunction.billInfoScreenStyle({} as any, { pageMode: 'inquiry' } as any, { key: 'totalBilled' } as any);
    expect(retVal).toStrictEqual({ 'text-align': 'right', 'font-weight': '600' }); // deep comparing
  });
  it('billInfoScreenStyle should return text align as right when pageMode is inquiry & key is bilPrincAmt', () => {
    const retVal = billDetailsFunction.billInfoScreenStyle({} as any, { pageMode: 'inquiry' } as any, { key: 'bilPrincAmt' } as any);
    expect(retVal).toStrictEqual({ 'text-align': 'right', 'font-weight': '400' }); // deep comparing
  });
  it('billInfoScreenStyle should return text align as right when pageMode is add & key is bilPrincAmt', () => {
    const retVal = billDetailsFunction.billInfoScreenStyle({} as any, { pageMode: 'add' } as any, { key: 'bilPrincAmt' } as any);
    expect(retVal).toStrictEqual({ 'text-align': 'right', 'font-weight': '600' }); // deep comparing
  });

  it('formatISODate returns formatted date', () => {
    const dateTime = DateTime.local(2018, 12, 19, 11, 25);
    const result = billDetailsFunction.dateISOFormatter(dateTime.toISO());
    expect(result).toEqual(dateTime.toFormat('MM/dd/yyyy'));
  });

  it('formatISODate returns input as is if not in ISO format', () => {
    expect(billDetailsFunction.dateISOFormatter(undefined as any)).toEqual(undefined);
    expect(billDetailsFunction.dateISOFormatter(null as any)).toEqual(null);
    expect(billDetailsFunction.dateISOFormatter('' as any)).toEqual('');
    expect(billDetailsFunction.dateISOFormatter('12/19/2018' as any)).toEqual('12/19/2018');
    expect(billDetailsFunction.dateISOFormatter('12/19/2018' as any)).toEqual('12/19/2018');
  });

  it('getInputMode returns the mode of input as currency',()=>{
    const result = billDetailsFunction.getInputMode({} as any, { pageMode: 'inquiry' } as any, {} as any);
    expect(result).toEqual('currency');
  });

  it('getInputMode returns the mode of input as decimal',()=>{
    const result = billDetailsFunction.getInputMode({} as any, { pageMode: 'editMode' } as any, {} as any);
    expect(result).toEqual('decimal');
  });
});
