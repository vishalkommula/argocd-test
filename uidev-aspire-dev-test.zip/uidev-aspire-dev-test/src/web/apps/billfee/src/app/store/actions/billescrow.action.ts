import { createAction, props } from '@ngrx/store';
import { GridCellModifiedData } from '../../models/grid-cell-modified-data.model';
import { LnBilEscrwEditSrchRequest } from '../../models/loan-bill-escrow-edit-request.model';
import { LnBilEscrwSrchRequest } from '../../models/loan-bill-escrow-request.model';
import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';
import { SLLnBilEscrwInfoRecItemModel } from '../../models/sl-loan-bill-escrow-info-record-item.model';
import { SLLnBilEscrwPmtBalInfoRecItem } from '../../models/sl-loan-bill-escrow-pmt-bal-info-record-item.model';

// Escrow details request action
export const getEscrow = createAction('[Bills/Fees] Get Escrow Data', props<{ request: LnBilEscrwSrchRequest }>());

//  Escrow details action success response
export const getEscrowSuccess = createAction('[Bills/Fees] Get Escrow Success', props<{ response: LnBilEscrwSrchResponse }>());

// Escrow details action error response
export const getEscrowFailure = createAction('[Bills/Fees] Get Escrow Failed', props<{ error: Error }>());

// Escrow details edit request action
export const saveEscrow = createAction('[Bills/Fees] Save Escrow', props<{ updateRecord: LnBilEscrwEditSrchRequest }>());

//  Escrow details edit action success response
export const saveEscrowSuccess = createAction('[Bills/Fees] Save Escrow Success', props<{ response: LnBilEscrwSrchResponse }>());

// Escrow details action error response
export const saveEscrowFailure = createAction('[Bills/Fees] Save Escrow Failed', props<{ error: Error }>());

//TODO: Do we need the below 3 actions?
// Escrow details cancel action
// export const cancelOverrideDialogBox = createAction('[blockoverridebox] Block Override Dialogbox Block Or Show', props<{ cancelOverrideBox: boolean }>());

export const updateEscrowBalance = createAction('[Bills/Fees] Update Escrow Details Grid', props<{ cellModifiedData: GridCellModifiedData<SLLnBilEscrwPmtBalInfoRecItem> }>());

// billInfo update
export const updateEscrowDetails = createAction('[Bills/Fees] Update Escrow after updating data', props<{ updateEscrowDetails: SLLnBilEscrwInfoRecItemModel }>());

export const updateBillInfoEscrowDetails = createAction('[Bills/Fees] Update Bill Info Escrow in BilInfo after grid update', props<{ updateBillEscrowDetails: SLLnBilEscrwInfoRecItemModel; billDueDt: string }>())
