// import { BillInfoState } from './billInfo.state';
import { BillFeeState } from './billfee.state';
import { ActionReducerMap } from '@ngrx/store';
import { billFeeReducer } from '../../store/reducers/billfee.reducer';
// import { billInfoReducer } from '../../store/reducers/billInfo.reducer';

export interface AppState{
   
}

// export const appReducer: ActionReducerMap<AppState> = {
//     billList: billInfoReducer,
//     billFees: billFeeReducer
// };
