// import { LnBilSrchResponseModel } from '../../models/loan-bill-search-response.model';
// import * as BillInfoActions from '../actions/billInfo.action';
// import { initialBillInfoState,billInfoReducer} from './billInfo.reducer';

// describe('Bill Info Reducer Test',()=>{

//      // bill list reducer test to get default state
//      it('Bill list returns default state',()=>{
//         const state = billInfoReducer(initialBillInfoState, BillInfoActions.billList({} as any));
//         expect(state).toEqual({loanBillResponse: {} as LnBilSrchResponseModel,lnBilInfo: [],isBillInfoUpdated: false,isBillInfoDeleted:false, 
//         billDueDate: '',action:'view',            showoverridedialogbox:false,
//         faultRecInfoArray:[]});
//     });

//     // bill list reducer test to get latest state
//     it('Bill list returns latest state',()=>{
//         const responseModel = { data: 'data' };
//         const state = billInfoReducer(initialBillInfoState, BillInfoActions.billListRetrived({response: responseModel as any}));
//         expect(state).toEqual({loanBillResponse: responseModel,lnBilInfo: [],isBillInfoUpdated: false,isBillInfoDeleted:false ,billDueDate: '',action:'view',
//         showoverridedialogbox:false,
//         faultRecInfoArray:[]});
//     });

//     // Bill details by bill due date success response reducer test to get latest state
//     it('Bill details succcess by bill due date',()=>{
//         const responseModel = { lnbilInfoRec: {bilDueDt:''} };
//         const state = billInfoReducer(initialBillInfoState,
//             BillInfoActions.getbilldetailssuccess({loanbillinforesponse:responseModel as any}));
//             expect(state).toEqual({loanBillResponse: {},
//                 lnBilInfo: [responseModel.lnbilInfoRec],
//                 isBillInfoUpdated: false,
//                 isBillInfoDeleted:false ,
//                 billDueDate: responseModel.lnbilInfoRec.bilDueDt
//                 ,action:'view',
//             showoverridedialogbox:false,
//             faultRecInfoArray:[]});
//     });

//     // Bill details by bill due date error response reducer test to get latest state
//     it('Bill details error by bill due date returns latest state',()=>{
//         const responseModel = { error: 'error' };
//         const state = billInfoReducer(initialBillInfoState,
//             BillInfoActions.getbilldetailserror({error:responseModel as any}));
//             expect(state).toEqual({loanBillResponse: {},lnBilInfo: [],
//                 isBillInfoUpdated: false,
//                 isBillInfoDeleted:false ,
//                 billDueDate: '',
//                 action:'view',
//                 showoverridedialogbox:false,
//             faultRecInfoArray:[]});
//     });

//     // update bill details  reducer test after success response to get latest state
//     it('update bill details after success response',()=>{
//         const responseModel = { rsStat: true};
//         const state = billInfoReducer(initialBillInfoState,
//             BillInfoActions.updatebilldetailssuccess({billmodresponse:responseModel as any}));
//             expect(state).toEqual({loanBillResponse: {},lnBilInfo: [],
//                 isBillInfoUpdated: false,
//                 isBillInfoDeleted:false,
//                 billDueDate: '',
//                 action:'view',
//             showoverridedialogbox:false,
//             faultRecInfoArray:[]});
//     });

//     // update bill details after error response reducer test to get latest state
//     it('update bill details after error response',()=>{
//         const responseModel = { error: false };
//         const state = billInfoReducer(initialBillInfoState,
//             BillInfoActions.updatebilldetailserror({billmodresponse:responseModel as any}));
//             expect(state).toEqual({loanBillResponse: {},lnBilInfo: [],isBillInfoUpdated: false,isBillInfoDeleted:false ,billDueDate: '',action:'view',
//             showoverridedialogbox:false,
//             faultRecInfoArray:[]});
//     });

//         // add bill details  reducer test after success response to get latest state
//         it('add bill details after success response',()=>{
//             const responseModel = { rsStat: true};
//             const state = billInfoReducer(initialBillInfoState,
//                 BillInfoActions.addbilldetailssuccess({billaddres:responseModel as any}));
//                 expect(state).toEqual({loanBillResponse: {},lnBilInfo: [],isBillInfoUpdated: false,isBillInfoDeleted:false,billDueDate: '',action:'view',
//                 showoverridedialogbox:false,
//                 faultRecInfoArray:[]});
//         });

//         // add bill details after error response reducer test to get latest state
//         it('add bill details after error response',()=>{
//             const responseModel = { error: false };
//             const state = billInfoReducer(initialBillInfoState,
//                 BillInfoActions.addbilldetailserror({billaddres:responseModel as any}));
//                 expect(state).toEqual({loanBillResponse: {},lnBilInfo: [],isBillInfoUpdated: false,isBillInfoDeleted:false ,billDueDate: '',action:'view',
//                 showoverridedialogbox:false,
//                 faultRecInfoArray:[]});
//         });
//          // delete bill details  reducer test after success response to get latest state
//          it('delete bill details after success response',()=>{
//             const responseModel = { rsStat: true};
//             const state = billInfoReducer(initialBillInfoState,
//                 BillInfoActions.deletebilldetailssuccess({deleteres:responseModel as any}));
//                 expect(state).toEqual({loanBillResponse: {},lnBilInfo: [],isBillInfoUpdated: false,
//                     isBillInfoDeleted:true,billDueDate: ''
//                     ,action:'view',
//                 showoverridedialogbox:false,
//                 faultRecInfoArray:[]});
//         });
//         // delete bill details after error response reducer test to get latest state
//         it('delete bill details after error response',()=>{
//             const responseModel = { error: false };
//             const state = billInfoReducer(initialBillInfoState,
//                 BillInfoActions.deletebilldetailserror({deleteres:responseModel as any}));
//                 expect(state).toEqual({loanBillResponse: {},lnBilInfo: [],isBillInfoUpdated: false,isBillInfoDeleted:false ,billDueDate: '',action:'view',
//                 showoverridedialogbox:false,
//                 faultRecInfoArray:[]});
//         });

//         // bill action tracking
//         it('bill detail click action test',()=>{
//             const responseModel = { clickaction: 'add' };
//             const state = billInfoReducer(initialBillInfoState,
//                 BillInfoActions.billclickaction({clickaction:responseModel as any}));
//                 expect(state).toEqual({loanBillResponse: {},lnBilInfo: [],isBillInfoUpdated: false,isBillInfoDeleted:false ,billDueDate: '',
//                 action: responseModel,
//                 showoverridedialogbox:false,
//                 faultRecInfoArray:[]});
//         });
// });
