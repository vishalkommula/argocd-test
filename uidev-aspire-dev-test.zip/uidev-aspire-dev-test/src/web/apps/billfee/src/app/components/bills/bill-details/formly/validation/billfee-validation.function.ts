import { AbstractControl } from '@angular/forms';
import { LuxonDateFormatterPipe } from '@uid/uid-pipes';
import { PageMode } from 'apps/billfee/src/app/models/bill-fee-enums';

export function billDueDtInvalidValidator(control: AbstractControl,model: any) {
    const addBilDueDt = control.value;
    if(model.options?.formState.pageMode=== PageMode.Add && model.form?.dirty
    && (addBilDueDt === null || addBilDueDt === '')){
        model.options.formState.billDueDtValidation=false;
        return {billDueDtInvalid:true};
    } else if(model.options?.formState.pageMode===PageMode.Add && model.form?.dirty
    && addBilDueDt !== undefined && addBilDueDt != null && addBilDueDt !== ''){
        const pipe = new LuxonDateFormatterPipe();
        const extractDueDate=pipe.transform(new Date(addBilDueDt), 'yyyy-MM-dd');
        const index=model.options?.formState.addedBillDueDtList.findIndex((x: string)=>x===extractDueDate);
           if(index !==-1){
            model.options.formState.billDueDtValidation=true;
            return {billDueDtInvalid:true};
           } else{
            model.options.formState.billDueDtValidation=false;
               return null;
           }
    }
    return null;
  }