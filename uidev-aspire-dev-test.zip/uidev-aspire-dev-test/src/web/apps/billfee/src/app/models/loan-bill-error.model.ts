export interface FaultMsgRec{
    errCode: string;
    errCat: string;
    errDesc: string;
    errElem: string;
    errElemVal: string;
    errLoc: string;
};
