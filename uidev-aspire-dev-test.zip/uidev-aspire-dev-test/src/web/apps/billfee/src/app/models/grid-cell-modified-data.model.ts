export interface GridCellModifiedData <T>{
    uniqueRowIdentifier: number;
    oldData: string;
    newData: string;
    oldRowData: T;
    newRowData: T;
    field: string;
}
