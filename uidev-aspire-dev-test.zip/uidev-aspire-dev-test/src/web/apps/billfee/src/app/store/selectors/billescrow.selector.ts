import { createFeatureSelector, createSelector } from '@ngrx/store';
import { BillFeeState } from '../states/billfee.state';
import { PageMode } from '../../models/bill-fee-enums';


export const selectEscrowRoot = createFeatureSelector<BillFeeState>('billFees');
// select escrowlist selector
export const selectEscrowDetails = createSelector(selectEscrowRoot, (state: BillFeeState)=> state.escrowDetailsResponse.lnBilEscrwInfoRec);
export const selectEscrowEditDetails = createSelector(selectEscrowRoot, (state: BillFeeState)=> state.escrowDetailsEditResponse);
 // get showoverride dialogbox
// export const selectShowOverride=createSelector(selectRoot,
//     (state: BillFeeState)=>state.showoverridedialogbox);
// // get errorModel dialogbox
// export const selectErrorModel=createSelector(selectRoot,
// (state: BillFeeState)=>state.faultRecInfoArray);

// get action.
export const selectPageMode = createSelector(selectEscrowRoot, (state: BillFeeState) => state.pageMode);
