import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule, DatePipe, CurrencyPipe } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AngularSplitModule } from 'angular-split';
import { JhaFormsModule } from '@jha/rui-angular/jha-forms';
import { HomeComponent } from './home.component';
import { HttpClientModule } from '@angular/common/http';

// JHA web components
// import '@jha/rui-wc/components/rui-layout/rui-layout-imports';
// import '@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports';
// import '@jha/rui-wc/components/rui-buttons/rui-buttons-imports';
// import '@jha/rui-wc/components/rui-input/rui-input-imports';
// import '@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports';
// import '@jha/rui-wc/components/rui-master-detail/rui-master-detail-imports';
// import '@jha/rui-wc/components/rui-notifications/rui-notifications-imports';

// Ag-grid
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';

// prime-ng
import { CalendarModule } from 'primeng/calendar';
import { InputNumberModule } from 'primeng/inputnumber';
import { CheckboxModule } from 'primeng/checkbox';

// NGRX
import { ReactiveComponentModule } from '@ngrx/component';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

// UID
import { UidPrimaryDetailModule } from '@uid/uid-primary-detail';
import { UidPipesModule } from '@uid/uid-pipes';
import { UidAngularControlsModule } from '@uid/uid-angular-controls';
import { UidDirectivesModule } from '@uid/uid-directives';

// Formly
import { FormlyModule } from '@ngx-formly/core';
import { FormlyPrimeNGModule } from '@ngx-formly/primeng';

// Components
import { BillDetailsComponent } from '../bills/bill-details/bill-details.component';
import { BillListComponent } from '../bills/bill-list/bill-list.component';
import { FeesGridDetailsComponent } from '../fees-details/fees-grid-details/fees-grid-details.component';
import { EscrowDetailsComponent } from '../escrow/escrow-details/escrow-details.component';
import { FeeListComponent } from '../fees-details/fee-list/fee-list.component';
import { BillDashboardComponent } from '../bills/bill-dashboard.component';
import { FeeDetailAgGridCheckboxRendererComponent } from '../fees-details/fees-grid-details/fee-detail-ag-grid-checkbox-renderer/fee-detail-ag-grid-checkbox-renderer.component';
import { BillTableTypeComponent } from '../bills/bill-details/formly/type/bill-table-type/bill-table-type.component';
import { DisplayRecordFieldComponent } from '../bills/bill-details/formly/type/display-record-field/display-record-field.component';
import { FormDisplayWithoutRuiFormComponent } from '../bills/bill-details/formly/wrapper/form-display-without-rui-form/form-display-without-rui-form.component';

// Store
import { BillInfoEffects } from '../../store/effects/billInfo.effects';
import { BillFeesEffects } from '../../store/effects/billfee.effects';
import { EscrowInfoEffects } from '../../store/effects/escrowinfo.effects';
import { billFeeReducer } from '../../store/reducers/billfee.reducer';

// service
import { EscrowgridcoldefService } from '../escrow/escrow-details/escrow-grid-coldef.service';
import { DataService } from '../../service/data.service';

// function
import { billDueDtInvalidValidator } from '../bills/bill-details/formly/validation/billfee-validation.function';

// enum
import { BillFeeFormDateTypeEnum } from '../../models/bill-fee-enums';
import { EscrowComponent } from '../escrow/escrow.component';

// routes
const routes: Routes = [
  {path: '', component: HomeComponent, children: [
    {path: '', redirectTo: 'bills'},
    {path: 'bills', component: BillDashboardComponent},
    {path: 'fees', component: FeeListComponent},
    {path: 'escrow', component: EscrowComponent},
  ]},
];

@NgModule({
  declarations: [HomeComponent,
    BillListComponent,
    BillDetailsComponent,
     FeesGridDetailsComponent,
     FeeListComponent,
     EscrowDetailsComponent,
     BillDashboardComponent,
     FeeDetailAgGridCheckboxRendererComponent,
     BillTableTypeComponent,
     DisplayRecordFieldComponent,
     FormDisplayWithoutRuiFormComponent,
     EscrowComponent],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    UidDirectivesModule,
    UidAngularControlsModule,
    UidPipesModule,
    UidPrimaryDetailModule,
    AgGridModule.withComponents([FeeDetailAgGridCheckboxRendererComponent]),
    AngularSplitModule,
    FormlyModule.forRoot({
      validators: [{ name: BillFeeFormDateTypeEnum.billDueDtInvalid, validation: billDueDtInvalidValidator }],
      validationMessages: [{ name: BillFeeFormDateTypeEnum.billDueDtInvalid, message: BillFeeFormDateTypeEnum.billDueDateValidationMsg }],
      types: [
        {
          name: BillFeeFormDateTypeEnum.billTableType,
          component: BillTableTypeComponent,
        },
        {
          name: BillFeeFormDateTypeEnum.displayRecord,
          component: DisplayRecordFieldComponent,
        },
      ],
      wrappers: [
        {
          name: BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer,
          component: FormDisplayWithoutRuiFormComponent,
        },
      ],
    }),
    FormlyPrimeNGModule,
    StoreModule.forFeature('billFees', billFeeReducer),
    EffectsModule.forFeature([BillInfoEffects, BillFeesEffects, EscrowInfoEffects]),
    JhaFormsModule.forRoot(),
    ReactiveComponentModule,
    FormlyModule,
    CheckboxModule,
    InputNumberModule,
    CalendarModule,
  ],
  providers: [EscrowgridcoldefService, DataService, CurrencyPipe, DatePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class HomeModule {}
