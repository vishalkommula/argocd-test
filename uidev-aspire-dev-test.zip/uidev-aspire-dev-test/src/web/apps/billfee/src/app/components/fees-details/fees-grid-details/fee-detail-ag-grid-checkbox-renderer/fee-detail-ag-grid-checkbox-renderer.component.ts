import { Component, OnInit } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ICellRendererParams } from 'ag-grid-community';
import { PageMode } from 'apps/billfee/src/app/models/bill-fee-enums';

@Component({
  selector: 'uid-fee-detail-ag-grid-checkbox-renderer',
  templateUrl: './fee-detail-ag-grid-checkbox-renderer.component.html',
  styleUrls: ['./fee-detail-ag-grid-checkbox-renderer.component.scss']
})
export class FeeDetailAgGridCheckboxRendererComponent implements ICellRendererAngularComp {

  params: any;
  isCheckboxdisable!: boolean;
  pageMode!: string;
  checkBoxValue=false;

  pageModeEnum = PageMode;

  agInit(params: ICellRendererParams): void {
    this.params = params;
    this.isCheckboxdisable=this.params.isCheckboxdisable;
    this.pageMode= this.params.pageMode;
    this.checkBoxValue=false;
  }

  refresh(params: ICellRendererParams): boolean {
    this.params = params;
    return true;
  }

  onChange(){
    this.params.node.setSelected(this.checkBoxValue);
    this.params.emitSelectedValue(this.params.data, this.checkBoxValue);
  }
  navFeeID(){
    this.params.navFeeID(this.params.data?.lnFeeId);
  }
}
