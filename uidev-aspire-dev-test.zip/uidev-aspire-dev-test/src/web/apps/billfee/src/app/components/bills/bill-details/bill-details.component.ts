import { Component,Input, SimpleChanges, OnChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
// formly
import { FormlyFormOptions } from '@ngx-formly/core';

// functions
import * as BillDetailsFunction from './bill-details.function';
// ngrx store
import * as BillInfoActions from '../../../store/actions/billInfo.action';
import * as BillInfoSelect from '../../../store/selectors/billInfo.selector';
import * as BillFeeActions from '../../../store/actions/billfee.action';
import * as BillFeeSelect from '../../../store/selectors/billfee.selector';
// models
import { BillFormStateModel } from '../../../models/bill-info-formstate.model';
import { LnBilSrchRecModel } from '../../../models/loan-bill-search-record.model';
import { LnBilDeleteRequestModel } from '../../../models/loan-bill-delete-request.model';
import { LnBilInfoRecItemModel } from '../../../models/loan-bill-info-record-item.model';
import { LnFeeInfoRecModel } from '../../../models/loan-fee-info-record.model';
import { LnBilModRequestModel } from '../../../models/loan-bill-mod-request.model';
import { LnBilAddRequestModel } from '../../../models/loan-billI-add-request.model';
import { billFeeValueTypes, FeesGridParentEnum, PageMode } from '../../../models/bill-fee-enums';
import { LnBilEscrwInfoRecModel } from '../../../models/loan-bill-escrow-info-record.model';
import { GridCellSelectedRecord } from '../../../models/grid-cell-selected-data.model';
import { LnBilInfoResponseModel } from '../../../models/loan-bill-info-response.model';
// uid-utilities.
import { formatDate, specificFormateDate } from '@uid/uid-utilities';
import { LnBilInfoRequestModel } from '../../../models/loan-bill-inq-request.model';

@Component({
  selector: 'uid-bill-details',
  templateUrl: './bill-details.component.html',
  styleUrls: ['./bill-details.component.scss'],
})
export class BillDetailsComponent implements OnChanges {
  @Input() pageMode!: PageMode;
  @Input() billDetails!: LnBilInfoResponseModel | null;
  // get bill due date
  billDueDt$!: Observable<string>;
  // assign the actions of bill action
  billInfoActions = BillInfoActions;
  // assign the selector of bill selectors
  billInfoSelector = BillInfoSelect;
  // actions and selectors for bill fee
  billFeeSelect = BillFeeSelect;

  billFeeActions = BillFeeActions;
  // formly definitions
  billInfoForm = new FormGroup({});

  billInfoOptions: FormlyFormOptions = {};

  billInfoFields = BillDetailsFunction.getBillDetailFormField();
  statementInfoFields = BillDetailsFunction.getStatementDetailFormField();

  // this model is used to render the default value for properties in add screeen.
  addBillInfoModel!: LnBilInfoRecItemModel;

  // formState holds the state variable of formly
  formState$!: Observable<BillFormStateModel>;

  // bill search info
  billSearchData$!: Observable<LnBilSrchRecModel | null>;

  // showDialogBox displays the dialog box on cancel click and delete click .
  showDialogBox = false;

  // generic dialog box title display for delete and cancel click.
  dialogBoxTitle = '';
  // dialogBoxType defines the type of dialogbox like delete and cencel.
  dialogBoxType = '';

  // dialogBoxText contains the body of dialog box
  dialogBoxText: string[] = [];
  billFeeData$!: Observable<LnFeeInfoRecModel[]>;
  // enums
  pageModeEnum = PageMode;
  feesGridParentEnum = FeesGridParentEnum;
  billFeeValues = billFeeValueTypes;
  // to how current date and time for delete confirmation
  currentDateTime = new Date();

  // get the form state of statement details
  statementDetailsFormState$: Observable<BillFormStateModel>;

  // to store previous state of print billing notice
  printBillingNotice = false;

  constructor(private store: Store) {

    this.formState$ = this.store.select(this.billInfoSelector.selectFormState);

    this.billDueDt$ = this.store.select(this.billInfoSelector.selectBillDueDt);

    this.billFeeData$ = this.store.select(this.billFeeSelect.selectLoanFee);

    this.billSearchData$ = this.store.select(this.billInfoSelector.selectBillSearchByBillDueDt);

    this.statementDetailsFormState$ = this.store.select(this.billInfoSelector.selectStatementDetailsFormState);

  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes['pageMode']){
      if (this.pageMode === PageMode.Add) {
        // form reset.
        this.billInfoForm.reset();
        this.bindBillInfoModelForAdd();
        this.store.dispatch(this.billFeeActions.getLoanFees({ request: {} as any }));
      }
    }
    if(changes['billDetails']){
      this.printBillingNotice = this.billDetails?.lnbilInfoRec.printbillingnotice ?? false;
    }
  }
  editBill() {
    this.store.dispatch(this.billInfoActions.changePageMode({ clickAction: PageMode.Edit }));
  }
  deleteBill() {
    this.dialogBoxType = billFeeValueTypes.deleteMsg;
    this.dialogBoxTitle = billFeeValueTypes.deleteDialogBoxTitle;
    this.dialogBoxText = [];
    this.showDialogBox = true;
  }
  cancelBill() {
    this.dialogBoxType = billFeeValueTypes.cancelMsg;
    this.dialogBoxTitle = billFeeValueTypes.cancelDialogBoxTitle;
    this.dialogBoxText = [];
    this.dialogBoxText.push(billFeeValueTypes.cancelDialogBoxText);
    this.showDialogBox = true;
  }
  dialogBoxClose(e: any) {
    if (e.detail === billFeeValueTypes.deleteMsg) {
      const loanBillDelReq: LnBilDeleteRequestModel = {
        srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
        acctId: '12',
        acctType: 'A',
        billduedate: specificFormateDate(this.billDetails?.lnbilInfoRec.bilDueDt??'',billFeeValueTypes.displayedDateFormatter,billFeeValueTypes.isoDateFormatter),
        overrideFaultMsg: false,
      };
      this.store.dispatch(this.billInfoActions.deleteBillDetails({ deleteRequest: loanBillDelReq }));
    }
    if (e.detail === billFeeValueTypes.donotSave) {
      if (this.pageMode === PageMode.Edit) {
        // get billinfo by billduedate
        // this logic reverts all store update after user is clicking on don't save button in edit screen
        const loanBillInfoReq: LnBilInfoRequestModel = {
          srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
          acctId: '12',
          acctType: 'A',
          bilDueDt: specificFormateDate(this.billDetails?.lnbilInfoRec.bilDueDt??'',billFeeValueTypes.displayedDateFormatter,billFeeValueTypes.isoDateFormatter),
        };
        this.store.dispatch(this.billInfoActions.getBillDetails({ loanBillInfoRequest: loanBillInfoReq }));
      } else {
        this.store.dispatch(this.billInfoActions.changePageMode({ clickAction: this.pageModeEnum.Inquiry }));
      }
    }
    this.showDialogBox = false;

  }
  // this event will execute before closing of override dialog box
  // TODO : complete functionality for override dailog box will be implemented when screen is integrated with api.
  overridedialogBoxClose(event: any) {
    if (event.detail === billFeeValueTypes.overrideMsg) {
      this.saveBill();
    }
  }

  // bind the billInfoModel for add screen to set the initial values.
  bindBillInfoModelForAdd() {
    this.addBillInfoModel = {
      bilPrincAmt: 0,
      remBilPrincAmt: 0,
      bilIntAmt: 0,
      remBilIntAmt: 0,
      bilEscrwAmt: 0,
      remBilEscrwAmt: 0,
      bilLateChgAmt: 0,
      remBilLateChgAmt: 0,
      bilOtherChgAmt: 0,
      remBilOtherChgAmt: 0,
      totalBilled: 0,
      totalRemaining: 0,
      printbillingnotice: false,
      bilDueDt: '',
      bilPaidDt: '',
      nxtPayDt: '',
      // set addBilDuedt to undefined to block the validation.
      addBilDueDt: undefined,
      lnFeeInfoRec: [],
      lnBilEscrwInfoRec: {} as LnBilEscrwInfoRecModel,
    };
  }
  // save logic for edit and add save click
  saveBill() {
    if (this.pageMode === PageMode.Edit) {
      const loanbillinforeq: LnBilModRequestModel = {
        srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
        acctId: '12',
        acctType: 'A',
        lnBilInfoRec:this.billDetails?.lnbilInfoRec ?? {},
        overrideFaultMsg: false,
      };
      this.store.dispatch(this.billInfoActions.updateBillDetails({ billModRequest: loanbillinforeq }));
    } else if (this.pageMode === PageMode.Add) {
      // formatting the add bill due date to ISO for posting in api
        this.addBillInfoModel.bilDueDt = formatDate(this.addBillInfoModel.addBilDueDt ?? '',billFeeValueTypes.isoDateFormatter);
      const loanbilladdreq: LnBilAddRequestModel = {
        srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
        acctId: '12',
        acctType: 'A',
        lnBilInfoRec: {...this.addBillInfoModel},/// shallow copy to avoid immutable refer excpetion,
        overrideFaultMsg: false,
      };
      // dispatching the add bill details action to post updated data to api.
      this.store.dispatch(this.billInfoActions.addBillDetails({ billAddRequest: loanbilladdreq }));
    }
  }
  // add and remove selected fee record in attached fee of bill add screen.
  // this logic update the late Charges and Other Charges of bill info model when user selects checkbox of respective charge types.
  selectedFeeRecord(event: GridCellSelectedRecord<LnFeeInfoRecModel>) {
    const index = this.addBillInfoModel.lnFeeInfoRec !== undefined ? this.addBillInfoModel.lnFeeInfoRec.findIndex((x) => x.lnFeeId === event?.selectedRecord.lnFeeId) : -1;
      if(event.selectedStatus && index===-1){
      this.addBillInfoModel.lnFeeInfoRec?.push(event.selectedRecord as LnFeeInfoRecModel);
      }else if(!event.selectedStatus && index!==-1){
      this.addBillInfoModel.lnFeeInfoRec?.splice(index, 1);
      }
      if (event.selectedRecord?.lnFeeConcatDescription === billFeeValueTypes.lateCharge && this.addBillInfoModel.bilLateChgAmt !== undefined) {
        if (event.selectedStatus) {
          this.addBillInfoModel.bilLateChgAmt += event.selectedRecord.lnFeeAmt;
        } else {
          this.addBillInfoModel.bilLateChgAmt -= event.selectedRecord.lnFeeAmt;
        }
        this.billInfoForm.patchValue({ bilLateChgAmt: this.addBillInfoModel.bilLateChgAmt });
      } else if (event.selectedRecord?.lnFeeConcatDescription === billFeeValueTypes.otherCharges && this.addBillInfoModel.bilOtherChgAmt !== undefined) {
        if (event.selectedStatus) {
          this.addBillInfoModel.bilOtherChgAmt += event.selectedRecord?.lnFeeAmt;
        } else {
          this.addBillInfoModel.bilOtherChgAmt -= event.selectedRecord.lnFeeAmt;
        }
        this.billInfoForm.patchValue({ bilOtherChgAmt: this.addBillInfoModel.bilOtherChgAmt });
      }
  }
  // bill info model change
  billInfoModelChange(model: LnBilInfoRecItemModel) {
    this.calTotalBilled(model);
    this.calTotalRemaining(model);
    if(this.pageMode === PageMode.Edit){
      if(model.lnStmtInfoRec?.crLineAmt !== undefined){
        model.lnStmtInfoRec.nxtPmtDueDt = formatDate(model.lnStmtInfoRec.nxtPmtDueDt ?? '',billFeeValueTypes.isoDateFormatter);
        if(this.billDetails?.lnbilInfoRec.printbillingnotice === false && this.printBillingNotice){
          this.printBillingNotice = this.billDetails.lnbilInfoRec.printbillingnotice;
        }
      }
      model.bilDueDt = formatDate(model.bilDueDt ?? '', billFeeValueTypes.isoDateFormatter);
      this.store.dispatch(this.billInfoActions.updateBillInfoModel({ updateBillInfoModel: model }));
    }
  }

  calTotalBilled(model: any) {
    model.totalBilled = model?.bilPrincAmt + model?.bilIntAmt + model?.bilEscrwAmt + model?.bilLateChgAmt + model?.bilOtherChgAmt;
    this.billInfoForm.patchValue({ totalBilled: model.totalBilled });
  }
  calTotalRemaining(model: any) {
    model.totalRemaining  = model?.remBilPrincAmt + model?.remBilIntAmt + model?.remBilEscrwAmt + model?.remBilLateChgAmt + model?.remBilOtherChgAmt;
    this.billInfoForm.patchValue({ totalRemaining: model.totalRemaining });
  }

}
