import { FeeDetailAgGridCheckboxRendererComponent } from './fee-detail-ag-grid-checkbox-renderer.component';

describe('FeeDetailAgGridCheckboxRendererComponent', () => {
  let component: FeeDetailAgGridCheckboxRendererComponent;

  beforeEach(() => {
      component = new FeeDetailAgGridCheckboxRendererComponent();
  });

  it('should create', () => {
      expect(component).toBeTruthy();
  });
  it('agInit call on FeeDetailAgGridCheckboxRendererComponent created',()=>{
    const params={checked:1};
    component.agInit(params as any);
    expect(component.params).toBe(params);
  });

  it('refresh call on FeeDetailAgGridCheckboxRendererComponent updated',()=>{
    const params={checked:1};
    component.refresh(params as any);
    expect(component.params).toBe(params);
  });

  it('onChange called on checkbox checked',()=>{
    const params={checked:1,node:{setSelected:jest.fn()},emitSelectedValue:jest.fn(),data:{lnFeeID:1}};
    component.params=params;
    component.onChange();
    expect(component.params.node.setSelected).toBeCalledTimes(1);
  });

  it('navFeeID called for redirecting to fee screen',()=>{
    const params={navFeeID:jest.fn(),data:{lnFeeId:1}};
    component.params=params;
    component.navFeeID();
    expect(component.params.navFeeID).toBeCalledTimes(1);
    expect(component.params.navFeeID).toBeCalledWith(params.data.lnFeeId);
  });
});
