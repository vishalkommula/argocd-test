import { Component, EventEmitter, Input, OnInit, Output, ViewChild, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';
import { Observable, Subscription } from 'rxjs';

import { Store } from '@ngrx/store';
import * as BillInfoActions from '../../../store/actions/billInfo.action';
import * as BillInfoSelectors from '../../../store/selectors/billInfo.selector';

import { LnBilSrchFilterModel } from '../../../models/loan-bill-search-filter.model';
import { LnBilSrchRecModel } from '../../../models/loan-bill-search-record.model';
import { PageMode ,billFeeValueTypes} from '../../../models/bill-fee-enums';
import { SpecialCharacterBlockDirective } from '@uid/uid-directives';

@Component({
  selector: 'uid-bill-list',
  templateUrl: './bill-list.component.html',
  styleUrls: ['./bill-list.component.scss'],
})
export class BillListComponent implements OnInit, OnDestroy {
  // p-calendar control
  @ViewChild('calendar') public calendar: any;
  uidSpecialCharacterBlock = {} as SpecialCharacterBlockDirective;

  // get the bill due date from bill dashboard component
  @Input() billDueDate!: string;
  // get the page mode from bill dashboard component
  @Input() pageMode!: PageMode;

  // output emitter to show unsaved changes dialog box
  @Output() showUnsavedChangesDialogBox = new EventEmitter<boolean>();
  // output emitter to send current selected bill due date to bill dashboard component
  @Output() billDueDateSelectedEvent = new EventEmitter<string>();

  filterRecordModel: LnBilSrchFilterModel = {} as LnBilSrchFilterModel;
  billListInfoArray$: Observable<LnBilSrchRecModel[]> = new Observable<LnBilSrchRecModel[]>();
  subscriptions: Subscription[] = [];
  isBillInfoFormDirty=false;
  previousSelectedBillDueDt= '';
  currentSelectedBillDueDate = '';
  nextSelectedBillDueDt= '';
  skipFormValidation = false;
  // to enable or disable apply and reset action buttons in bill lister filter popup
  isFilterActionButtonsDisabled = true;
  // get the bill info actions
  billInfoActions = BillInfoActions;
  // get the bill info selectors
  billInfoSelectors = BillInfoSelectors;
  // enums
  billFeeValues = billFeeValueTypes;

  constructor(private store: Store) {
    // get the bill list array from store
    this.billListInfoArray$ = this.store.select(this.billInfoSelectors.selectFilteredBills);

    // set the selected bill due date fom the list or from the bill dashboard component
    const subFilteredBills = this.billListInfoArray$.subscribe((billsList) => {
      if (billsList && billsList.length > 0) {
        // set the selected bill due from the incoming bill due date.
        if(this.billDueDate !== undefined && this.billDueDate !== ''){
          this.currentSelectedBillDueDate = this.billDueDate;
          this.billDueDate = '';
          return;
        }
        // set selected bill due date from the bills list
        this.currentSelectedBillDueDate = billsList[0].billDueDt != null ? billsList[0].billDueDt : '';
      }else if (this.currentSelectedBillDueDate !== '') {
          // If Filter didnt return rows. i.e., When no rows are available to display in list.
          this.currentSelectedBillDueDate = '';
          this.previousSelectedBillDueDt = '';
          this.billDueDateSelectedEvent.emit('');
        }
    });

    // get status of deleted bill info record
    const subIsBillInfoDeleted =  this.store.select(this.billInfoSelectors.selectIsBillInfoDeleted).subscribe((isBillInfoDeleted) => {
      // reload after bill info is deleted
      if (isBillInfoDeleted) {
        this.currentSelectedBillDueDate = '';
        this.previousSelectedBillDueDt = '';
        // want to change this logic, remove the flag from store and rewrite
        setTimeout(() => {
          this.store.dispatch(BillInfoActions.getBillList({ request: {} as any }));
        }, 20);
      }
    });

    // get status of updated bill info record
    const subIsBillInfoUpdated = this.store.select(this.billInfoSelectors.selectIsBillInfoUpdated).subscribe((isBillInfoUpdated) => {
      if(isBillInfoUpdated){
        this.billDueDateSelectedEvent.emit(this.currentSelectedBillDueDate);
      }
    });

    this.resetFilterRecordModel();
    this.subscriptions.push(subFilteredBills,subIsBillInfoUpdated,subIsBillInfoDeleted);
  }

  ngOnInit(): void {
    this.store.dispatch(this.billInfoActions.getBillList({ request: {} as any }));
  }

  // to display add button
  // add button is hidden for specific type of loans, that logic will be implemented in future.
  isAddBillAllowed() {
    return true;
  }

  // to get total over due days for a bill
  getOverdueDays(date?: string) {
    const dueDate = new Date(date as string);
    const currentDate = new Date();
    const passDueDays = ((currentDate.getTime() - dueDate.getTime()) / (1000 * 3600 * 24) - 1).toFixed(0);
    return passDueDays;
  }

  // get the selected bill due date from master list and send to bill dashboard component
  // event.detail is the selected bill due date from master list
  getDataForSelectedBillDueDate(event: any) {
    if (event.detail !== '' && this.previousSelectedBillDueDt !== event.detail) {
      this.nextSelectedBillDueDt = event.detail;
      if (this.skipFormValidation || !(this.pageMode === PageMode.Edit)) {
        this.skipFormValidation = false;
        this.currentSelectedBillDueDate = event.detail;
        this.previousSelectedBillDueDt = this.currentSelectedBillDueDate;
        this.billDueDateSelectedEvent.emit(event.detail);
      } else {
        // to show unsaved changes dialog box when bill details are not saved
        // this.showUnsavedChangesDialogBox.emit(true);
        this.currentSelectedBillDueDate = '';
        // there are no properties to stop selecting the row in rui master list
        setTimeout(() => {
          this.currentSelectedBillDueDate = this.previousSelectedBillDueDt;
        }, 50);
      }
    }
  }

  // click on add new bill button
  addBill() {
    if(this.pageMode!==PageMode.Edit){
    this.store.dispatch(BillInfoActions.changePageMode({ clickAction: PageMode.Add }));
    }
  }

  // reset the filter model data
  resetFilterRecordModel() {
    this.filterRecordModel = {} as LnBilSrchFilterModel;
  }

  // click on apply button from filter popup
  applyFilter() {
    this.store.dispatch(this.billInfoActions.setBillListFilter({ filterRecordModel: JSON.parse(JSON.stringify(this.filterRecordModel))}));
  }
  // click on reset button from filter popup
  resetFilter() {
    this.resetFilterRecordModel();
    this.isFilterActionButtonsDisabled = true;
    this.store.dispatch(this.billInfoActions.clearBillListFilter());
  }

  // to close p-calendar popup
  onClickPCalendarPopup() {
    if (this.filterRecordModel.dateRange !== undefined && this.filterRecordModel.dateRange[1]) {
      // If second date is selected
      this.calendar.overlayVisible = false;
    }
  }

  // detect the changes in filter model to enable/disable the apply and reset buttons in filter popup.
  filterModelChange(){
    this.isFilterActionButtonsDisabled = true;
    // p-calendar input field validation
    if(this.filterRecordModel.dateRange !== undefined && this.filterRecordModel.dateRange !== null){
      // check if the to date is selected
      if(this.filterRecordModel.dateRange[1] === null){
        this.isFilterActionButtonsDisabled = true;
        return;
      }
      this.isFilterActionButtonsDisabled = false;
      return;
    }
    // payment amount from input field validation
    if(this.filterRecordModel.paymentAmountFrom !== undefined && this.filterRecordModel.paymentAmountFrom !== null && this.filterRecordModel.paymentAmountFrom > 0){
      this.isFilterActionButtonsDisabled = false;
      return;
    }
    // payment amount to input field validation
    if(this.filterRecordModel.paymentAmountTo !== undefined && this.filterRecordModel.paymentAmountTo !== null && this.filterRecordModel.paymentAmountTo > 0){
      this.isFilterActionButtonsDisabled = false;
      return;
    }
  }

  // TODO: after changing the date fromat from string to datetime
  // set the data test id for master list options
  // getDataTestIdForBillListOption(dueDate?: string){
  //   if(dueDate){
  //     const billDueDate = new Date(dueDate);
  //     return 'billList-record-'+billDueDate.getFullYear()+billDueDate.getMonth()+billDueDate.getDate();
  //   }
  //   return dueDate;
  // }

  ngOnDestroy(): void {
    // unsubscribe all the subscriptions
    this.subscriptions.forEach((sub) => sub.unsubscribe());
  }
}
