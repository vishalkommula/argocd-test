// import { createReducer, on, State } from '@ngrx/store';
// import { BillInfoState } from '../states/billInfo.state';
// import * as BillInfoActions from '../actions/billInfo.action';
// import { LnBilSrchResponseModel } from '../../models/loan-bill-search-response.model';
// import { LnBilInfoRecItemModel } from '../../models/loan-bill-info-record-item.model';
// import { LnBilSrchFilterModel } from '../../models/loan-bill-search-filter.model';
// import { BillFeeDataTypeEnum } from '../../models/bill-fee-data-type.enum';

// // Initial state for bill list
// export const initialBillInfoState: BillInfoState = {
//     loanBillResponse: {} as LnBilSrchResponseModel,
//     action:'view',
//     billDueDate:'',
//     lnBilInfo:[],
//     isBillInfoUpdated: false,
//     isBillInfoDeleted:false,
//     showoverridedialogbox:false,
//     faultRecInfoArray:[],
//     filterRecordModel: {} as LnBilSrchFilterModel,
//     isBillInfoFormDirty:false,
// };

// export const billInfoReducer = createReducer(
//   initialBillInfoState,
//   // // reducer for bill list entry  - IS IT REALLY NEEDED? - Karthik
//   // on(BillInfoActions.fetchBillList,(state): BillInfoState =>({
//   //     loanBillResponse: {} as LnBilSrchResponseModel,
//   //     action:'view',
//   //     billDueDate:'',
//   //     lnBilInfo:[],
//   //     isBillInfoUpdated: false,
//   //     isBillInfoDeleted:false,
//   //     showoverridedialogbox:false,
//   //     faultRecInfoArray:[],
//   //     filterRecordModel: {} as LnBilSrchFilterModel
//   // })),

//   // reducer for bill list success response
//   on(
//     BillInfoActions.fetchBillListSuccess,
//     (state, action): BillInfoState => ({
//       ...state,
//       loanBillResponse: action.response,
//       billDueDate: '',
//       lnBilInfo: [],
//       isBillInfoUpdated: false,
//       isBillInfoDeleted: false,
//     })
//   ),

//   on(
//     BillInfoActions.updateSelectedBillDueDate,
//     (state, action): BillInfoState => ({
//       ...state,
//       billDueDate: action.dueDate,
//       action: 'view',
//       isBillInfoUpdated: false,
//       isBillInfoDeleted: false,
//       isBillInfoFormDirty: false,
//     })
//   ),

//   // reducer for bill list success response
//   on(
//     BillInfoActions.setBillListFilter,
//     (state, action): BillInfoState => ({
//       ...state,
//       filterRecordModel: action.filterRecordModel,
//     })
//   ),

//   // reducer for bill list success response
//   on(
//     BillInfoActions.clearBillListFilter,
//     (state): BillInfoState => ({
//       ...state,
//       filterRecordModel: {} as LnBilSrchFilterModel,
//     })
//   ),
//   // Reducer for bill details success.
//   on(BillInfoActions.getbilldetailssuccess, (state, action): BillInfoState => {
//     const billsearch = { ...state };
//     if (billsearch != null && action.loanbillinforesponse !== undefined && Object.keys(action.loanbillinforesponse).length !== 0) {
//       if (billsearch.lnBilInfo.length > 0 && billsearch.lnBilInfo.findIndex((x) => x.bilDueDt === action.loanbillinforesponse.lnbilInfoRec.bilDueDt) !== -1) {
//         return {
//           ...state,
//           action: 'view',
//           isBillInfoUpdated: false,
//           isBillInfoDeleted: false,
//           isBillInfoFormDirty: false,
//           billDueDate: action.loanbillinforesponse.lnbilInfoRec.bilDueDt !== undefined ? action.loanbillinforesponse.lnbilInfoRec.bilDueDt : '',
//           lnBilInfo: state.lnBilInfo.map((x) => (x.bilDueDt === action.loanbillinforesponse.lnbilInfoRec.bilDueDt ? action.loanbillinforesponse.lnbilInfoRec : x)),
//         };
//       } else {
//         return {
//           ...state,
//           action: 'view',
//           isBillInfoUpdated: false,
//           isBillInfoDeleted: false,
//           isBillInfoFormDirty: false,
//           billDueDate: action.loanbillinforesponse.lnbilInfoRec.bilDueDt !== undefined ? action.loanbillinforesponse.lnbilInfoRec.bilDueDt : '',
//           lnBilInfo: [...state.lnBilInfo, action.loanbillinforesponse.lnbilInfoRec !== undefined ? action.loanbillinforesponse.lnbilInfoRec : { lnFeeInfoRec: [] }],
//         };
//       }
//     } else {
//       return {
//         ...state,
//         lnBilInfo: [...state.lnBilInfo],
//       };
//     }
//   }),
//   // reducer for bill details error
//   on(
//     BillInfoActions.getbilldetailserror,
//     (state, action): BillInfoState => ({
//       ...state,
//       loanBillResponse: state.loanBillResponse,
//     })
//   ),
//   // Reducer for update bill details success.
//   on(BillInfoActions.updatebilldetailssuccess, (state, action): BillInfoState => {
//     if (action.billmodresponse.rsStat) {
//       if (state.showoverridedialogbox) {
//         return {
//           ...state,
//           action: 'view',
//           isBillInfoFormDirty:false,
//           lnBilInfo: state.lnBilInfo.map((x) => (x.bilDueDt === action.billmodresponse.lnBilInfoRec.bilDueDt ? action.billmodresponse.lnBilInfoRec : x)),
//           showoverridedialogbox: false,
//           faultRecInfoArray: [],
//         };
//       } else {
//         return {
//           ...state,
//           action: 'view',
//           isBillInfoFormDirty:false,
//           lnBilInfo: state.lnBilInfo.map((x) => (x.bilDueDt === action.billmodresponse.lnBilInfoRec.bilDueDt ? action.billmodresponse.lnBilInfoRec : x)),
//         };
//       }
//     } else if (!action.billmodresponse.rsStat && action.billmodresponse.canOverride) {
//       return {
//         ...state,
//         faultRecInfoArray: action.billmodresponse.faultRecInfoArray,
//         showoverridedialogbox: true,
//       };
//     } else {
//       return {
//         ...state,
//         faultRecInfoArray: action.billmodresponse.faultRecInfoArray,
//       };
//     }
//   }),
//   // Reducer for update bill details error.
//   on(
//     BillInfoActions.updatebilldetailserror,
//     (state): BillInfoState => ({
//       ...state,
//     })
//   ),
//   // Reducer for add bill details success.
//   on(BillInfoActions.addbilldetailssuccess, (state, action): BillInfoState => {
//     if (action.billaddres.rsStat) {
//       if (state.showoverridedialogbox) {
//         return {
//           ...state,
//           action: 'view',
//           showoverridedialogbox: false,
//           isBillInfoFormDirty: false,
//           faultRecInfoArray: [],
//         };
//       } else {
//         return {
//           ...state,
//           action: 'view',
//           isBillInfoFormDirty: false,
//         };
//       }
//     } else if (!action.billaddres.rsStat && action.billaddres.canOverride) {
//       return {
//         ...state,
//         faultRecInfoArray: action.billaddres.faultRecInfoArray,
//         showoverridedialogbox: true,
//       };
//     } else {
//       return {
//         ...state,
//         faultRecInfoArray: action.billaddres.faultRecInfoArray,
//       };
//     }
//   }),
//   // Reducer for add bill details error.
//   on(
//     BillInfoActions.addbilldetailserror,
//     (state, action): BillInfoState => ({
//       ...state,
//     })
//   ),

//   // Reducer for delete bill details success.
//   on(BillInfoActions.deletebilldetailssuccess, (state, action): BillInfoState => {
//     if (action.deleteres.rsStat) {
//       return {
//         ...state,
//         isBillInfoDeleted: true,
//         faultRecInfoArray: [],
//       };
//     } else {
//       return {
//         ...state,
//         faultRecInfoArray: action.deleteres.faultRecInfoArray,
//       };
//     }
//   }),
//   // Reducer for delete bill details error.
//   on(
//     BillInfoActions.deletebilldetailserror,
//     (state, action): BillInfoState => ({
//       ...state,
//     })
//   ),
//   // Reducer for bill detail click action.
//   on(
//     BillInfoActions.billclickaction,
//     (state, action): BillInfoState => {
//       if(action.clickaction===BillFeeDataTypeEnum.viewMode){
//         return {
//           ...state,
//           action: action.clickaction,
//           isBillInfoFormDirty: false,
//           showoverridedialogbox: false,
//           faultRecInfoArray: [],
//         };
//       }else {
//         return {
//           ...state,
//           action: action.clickaction,
//           isBillInfoFormDirty: true,
//           showoverridedialogbox: false,
//           faultRecInfoArray: [],
//         };
//       }
//     }
//   ),
//   // change override flog status
//   on(
//     BillInfoActions.blockoverridedialog,
//     (state, action): BillInfoState => ({
//       ...state,
//       showoverridedialogbox: action.blockoverridedialog,
//       faultRecInfoArray: [],
//     })
//   ),
//   // reducer for update attachedfee.
//   on(BillInfoActions.updateAttachedFee, (state, action): BillInfoState => {
//     const lnBilInfoRecIndex = state.lnBilInfo.findIndex((x) => x.bilDueDt === action.billDueDt);
//     if (lnBilInfoRecIndex !== -1) {
//       const lnFeeRecIndex = state.lnBilInfo[lnBilInfoRecIndex].lnFeeInfoRec?.findIndex((feeID) => feeID.lnFeeId === action.updateAttachedFee.lnFeeId);
//       return {
//         ...state,
//         lnBilInfo: [
//           ...state.lnBilInfo.slice(0, lnBilInfoRecIndex),
//           {
//             ...state.lnBilInfo[lnBilInfoRecIndex],
//             lnFeeInfoRec: state.lnBilInfo[lnBilInfoRecIndex].lnFeeInfoRec?.map((feeID) => (feeID.lnFeeId === action.updateAttachedFee.lnFeeId ? action.updateAttachedFee : feeID)),
//           },
//           ...state.lnBilInfo.slice(lnBilInfoRecIndex + 1),
//         ],
//       };
//     } else {
//       return {
//         ...state,
//       };
//     }
//   }),
//   // reducer for update escrow.
//   on(BillInfoActions.updateBillInfoEscrowModel, (state, action): BillInfoState => {
//     const lnBilInfoRecIndex = state.lnBilInfo.findIndex((x) => x.bilDueDt === action.billDueDt);
//     if (lnBilInfoRecIndex !== -1) {
//       return {
//         ...state,
//         lnBilInfo: state.lnBilInfo.map((x) =>
//           x.bilDueDt === action.billDueDt
//             ? {
//                 ...x,
//                 lnBilEscrwInfoRec: {
//                   billDt: x.lnBilEscrwInfoRec?.billDt !== undefined ? x.lnBilEscrwInfoRec.billDt : '',
//                   override: x.lnBilEscrwInfoRec?.override !== undefined ? x.lnBilEscrwInfoRec.override : false,
//                   lnBilEscrowId: x.lnBilEscrwInfoRec?.lnBilEscrowId ? x.lnBilEscrwInfoRec?.lnBilEscrowId : '',
//                   escrowInfo: x.lnBilEscrwInfoRec?.escrowInfo !== undefined ? x.lnBilEscrwInfoRec?.escrowInfo : {},
//                   escrowBalances:
//                     x.lnBilEscrwInfoRec?.escrowBalances !== undefined
//                       ? x.lnBilEscrwInfoRec?.escrowBalances?.map((escrow) => (escrow.balFldAff === action.updateBillInfoEscrowModel.uniqueRowIdentifier ? action.updateBillInfoEscrowModel.newRowData : escrow))
//                       : [],
//                 },
//               }
//             : x
//         ),
//       };
//     } else {
//       return {
//         ...state,
//       };
//     }
//   }),
//   // reducer for update billinfo.
//   on(BillInfoActions.updateBillInfoModel, (state, action): BillInfoState => {
//     const lnBilInfoRecIndex = state.lnBilInfo.findIndex((x) => x.bilDueDt === action.updateBillInfoModel.bilDueDt);
//     if (lnBilInfoRecIndex !== -1) {
//       return {
//         ...state,
//         lnBilInfo: state.lnBilInfo.map((x) => (x.bilDueDt === action.updateBillInfoModel.bilDueDt ? action.updateBillInfoModel : x)),
//       };
//     } else {
//       return {
//         ...state,
//       };
//     }
//   }),
//   // reducer for update escrow.
//   on(BillInfoActions.updateBillInfoEscrowDetails, (state, action): BillInfoState => {
//     const lnBilInfoRecIndex = state.lnBilInfo.findIndex((x) => x.bilDueDt === action.billDueDt);
//     if (lnBilInfoRecIndex !== -1) {
//       return {
//         ...state,
//         lnBilInfo: state.lnBilInfo.map((x) =>
//           x.bilDueDt === action.billDueDt
//             ? {
//                 ...x,
//                 lnBilEscrwInfoRec: {
//                   billDt: x.lnBilEscrwInfoRec?.billDt !== undefined ? x.lnBilEscrwInfoRec.billDt : '',
//                   override: x.lnBilEscrwInfoRec?.override !== undefined ? x.lnBilEscrwInfoRec.override : false,
//                   lnBilEscrowId: x.lnBilEscrwInfoRec?.lnBilEscrowId ? x.lnBilEscrwInfoRec?.lnBilEscrowId : '',
//                   escrowBalances: x.lnBilEscrwInfoRec?.escrowBalances ? x.lnBilEscrwInfoRec?.escrowBalances : [],
//                   escrowInfo: action.updateBillEscrowDetails,
//                 },
//               }
//             : x
//         ),
//       };
//     } else {
//       return {
//         ...state,
//       };
//     }
//   }),
// );
