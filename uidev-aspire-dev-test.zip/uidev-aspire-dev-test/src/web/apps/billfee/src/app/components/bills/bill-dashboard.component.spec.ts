import exp from 'constants';
import { Observable, of, Subscription } from 'rxjs';
import { PageMode } from '../../models/bill-fee-enums';
import { BillDashboardComponent } from './bill-dashboard.component';


jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

let component: BillDashboardComponent;
const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(()=> ({
    subscribe:jest.fn()
    })),
};

const routerMock = {
  getCurrentNavigation: jest.fn(()=>({
    extras:{
      state: '202-04-30'
    }
  }))
};

const billInfoSelectorMock = {
  selectPageMode: jest.fn(),
  selectBillInfoByBillDueDt: jest.fn(),
  selectAvailiableBillDueDates: jest.fn(),
};

const billInfoActionMock = {
  getBillDetails: jest.fn(),
  updateSelectedBillDueDate: jest.fn()
};

const subscriptions: Subscription[] = [new Subscription];

describe('Bill Dashboard Component Test',()=>{
  beforeEach(()=>{
    component = new BillDashboardComponent(storeMock as any, routerMock as any);
    component.billInfoAction = billInfoActionMock as any;
    component.billInfoSelector = billInfoSelectorMock as any;
    component.subscriptions = subscriptions;
  });

  it('Component should be created',()=>{
    expect(component).toBeTruthy();
  });

  it('onInit should be executed',()=>{
    const data = ['2022-05-30', '2022-03-31'];
    const observableData: Observable<string[]> = of(data);
    component.availableBillDueDates$ = observableData;
    component.ngOnInit();
    expect(component.allBillDetails).toEqual(data);
  });

  it('billsloaded should be executed',()=>{
    const event = true;
    component.billsloaded(event);
    expect(component.isBillsLoaded).toBeTruthy();
  });

  it('ngOnDestroy should be executed',()=>{
    component.ngOnDestroy();
  });

  it('getBillInfoByBillDueDt should be executed for first time call',()=>{
    const billDueDate = '2022-05-30';
    component.getBillInfoByBillDueDt(billDueDate);
    const data = {
      acctId: '12',
      acctType: 'A',
      bilDueDt: billDueDate,
      srchMsgRqHdr:{
        cursor: '123',
        instEnv: '1',
        jXLogTrackingId: '',
        maxRec: '10'
      }
    };
    expect(billInfoActionMock.getBillDetails).toBeCalledWith({loanBillInfoRequest: data});
    expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
    expect(billInfoActionMock.getBillDetails).toHaveBeenCalledTimes(1);
  });

  it('getBillInfoByBillDueDt should be executed for repeated calls',()=>{
    const billDueDate = '2022-05-30';
    component.allBillDetails = [billDueDate];
    component.getBillInfoByBillDueDt(billDueDate);
    expect(billInfoActionMock.updateSelectedBillDueDate).toBeCalledWith({dueDate: billDueDate});
    expect(billInfoActionMock.updateSelectedBillDueDate).toHaveBeenCalledTimes(1);
  });

  it('getBillInfoByBillDueDt should be executed for empty bill due date',()=>{
    const billDueDate = null;
    component.getBillInfoByBillDueDt(billDueDate as any);
    expect(billInfoActionMock.updateSelectedBillDueDate).toBeCalledWith({dueDate: ''});
    expect(billInfoActionMock.updateSelectedBillDueDate).toHaveBeenCalledTimes(2);
  });

});
