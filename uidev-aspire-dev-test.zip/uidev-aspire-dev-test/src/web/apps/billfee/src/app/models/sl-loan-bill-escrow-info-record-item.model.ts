export interface SLLnBilEscrwInfoRecItemModel{
    nonEscrwPmt?: number;
    nonEscrwPmtRem?: number;
};
