import { FaultMsgRec, SearchMessageResponseHeaderModel } from '@uid/uid-models';
import { LnBilInfoRecItemModel } from './loan-bill-info-record-item.model';

export interface LnBilInfoResponseModel{
    srchMsgRsHdr:    SearchMessageResponseHeaderModel;
    acctId:          string;
    acctType:        string;
    lnbilInfoRec:    LnBilInfoRecItemModel;
    faultRecInfoArray: FaultMsgRec[];
};
