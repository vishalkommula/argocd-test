import { createFeatureSelector, createSelector } from '@ngrx/store';
import { BillFeeState } from '../states/billfee.state';
import * as fromRootStore from '@uid/uid-root-store';
import { BillFormStateModel } from '../../models/bill-info-formstate.model';
import { PageMode } from '../../models/bill-fee-enums';
import { formatISODate } from '@uid/uid-utilities';

export const selectRoot = createFeatureSelector<BillFeeState>('billFees');
export const selectBillList = createSelector(selectRoot, (state) => state.loanBillResponse.lnBilSrchRec);
export const selectBillDueDt = createSelector(selectRoot, (state) => state.selectedBillDueDate);

// get lnbillinfo by duedate
export const selectBillInfoByBillDueDt =
  createSelector(selectRoot, selectBillDueDt, (state, billDueDt) => {
    if (Object.keys(state.lnBillInfoResponse).length !== 0 && billDueDt !== '') {
      let billDetailResponse = state.lnBillInfoResponse.find((x) => x.lnbilInfoRec.bilDueDt === billDueDt);
      // bill search response model
      const billsearchinfo = state.loanBillResponse.lnBilSrchRec.find((x) => x.lnbilSrchRec?.bilDueDt === billDueDt);
      if (billDetailResponse !== undefined && billDetailResponse !== null) {
        billDetailResponse={...billDetailResponse};
        billDetailResponse.lnbilInfoRec={...billDetailResponse.lnbilInfoRec};
        // without using spread operator edit mode not working as expected
        billDetailResponse.lnbilInfoRec.lnStmtInfoRec = {...billDetailResponse.lnbilInfoRec.lnStmtInfoRec};
        // converting date from iso to specified formatter using common ISODate
        billDetailResponse.lnbilInfoRec.bilDueDt=formatISODate(billsearchinfo?.lnbilSrchRec?.bilDueDt ?? '','MM/dd/yyyy');
        billDetailResponse.lnbilInfoRec.bilPaidDt=formatISODate(billsearchinfo?.lnbilSrchRec?.bilCrtDt ?? '','MM/dd/yyyy');
        billDetailResponse.lnbilInfoRec.nxtPayDt=formatISODate(billsearchinfo?.nxtPayDt ?? '','MM/dd/yyyy');
        // date conversion for payment due date in statement details
        if(billDetailResponse.lnbilInfoRec.lnStmtInfoRec.nxtPmtDueDt !== undefined){
          billDetailResponse.lnbilInfoRec.lnStmtInfoRec.nxtPmtDueDt = formatISODate(billDetailResponse.lnbilInfoRec.lnStmtInfoRec.nxtPmtDueDt ?? '','MM/dd/yyyy');
        }
        return billDetailResponse;
      } else {
        return null;
      }
    } else {
      return null;
    }
  });

// get lnbillsearch by duedate
export const selectBillSearchByBillDueDt =
  createSelector(selectRoot, selectBillDueDt, (state, billDueDt) => {


    if (Object.keys(state.loanBillResponse).length !== 0 && billDueDt !== '') {
      const billsearchinfo = state.loanBillResponse.lnBilSrchRec.find((x) => x.lnbilSrchRec?.bilDueDt === billDueDt);
      if (billsearchinfo !== undefined && billsearchinfo !== null) {
        return billsearchinfo;
      } else {
        return null;
      }
    } else {
      return null;
    }
  });

// get lnbillinfo by duedate
export const selectAvailiableBillDueDates = createSelector(selectRoot, (state) => {
  const billDueDt: string[] = [];
  if (state.lnBillInfoResponse != null && state.lnBillInfoResponse.length > 0) {
    state.lnBillInfoResponse.forEach((item) => {
      billDueDt.push(item?.lnbilInfoRec.bilDueDt !== undefined ? item?.lnbilInfoRec.bilDueDt : '');
    });
  }

  return billDueDt;
});

// get lnbillinfo by duedate
export const selectBillDueDtList = createSelector(selectRoot, (state) => {

  // console.log ('inside selectBillduedtArray SELECTOR');

  const billDueDtList: string[] = [];
  if (state.loanBillResponse != null && Object.keys(state.loanBillResponse).length !== 0) {
    state.loanBillResponse.lnBilSrchRec.forEach((x) => {
      billDueDtList.push(x.lnbilSrchRec?.bilDueDt !== undefined ? x.lnbilSrchRec?.bilDueDt : '');
    });
  }
  return billDueDtList;
});

// get selectIsBillInfoUpdated.
export const selectIsBillInfoUpdated = createSelector(selectRoot, (state: BillFeeState) => state.isBillInfoUpdated);

// get selectIsBillInfoDeleted.
export const selectIsBillInfoDeleted = createSelector(selectRoot, (state: BillFeeState) => state.isBillInfoDeleted);

// get action.
export const selectPageMode = createSelector(selectRoot, (state: BillFeeState) => state.pageMode);

// get formstate.
export const selectFormState = createSelector(
  fromRootStore.selectCurrentAccountType,
  selectPageMode,
  selectBillDueDtList,
  (accountType, pageMode,billDueDtList): BillFormStateModel => ({
    accountType,
    pageMode,
    width: 'medium',
    addedBillDueDtList:billDueDtList,
    billDueDtValidation: false,
    editMode: pageMode
  })
);

// get statement details form state
export const selectStatementDetailsFormState = createSelector(
  selectPageMode,selectBillInfoByBillDueDt,(pageMode,billInfo): BillFormStateModel=>{
    console.log('Inside statement form state selector');
    return{
      editMode: (pageMode === PageMode.Edit && billInfo?.lnbilInfoRec.printbillingnotice) ? pageMode : PageMode.Inquiry,
      width: (pageMode === PageMode.Edit && billInfo?.lnbilInfoRec.printbillingnotice) ? 'wide' : 'medium',
      accountType: '',
      addedBillDueDtList: [],
      billDueDtValidation: false,
      pageMode: (pageMode === PageMode.Edit && billInfo?.lnbilInfoRec.printbillingnotice) ? pageMode : PageMode.Inquiry
    };
  });

// get showoverride dialogbox
// export const selectShowOverrideDialogBox = createSelector(selectRoot, (state: BillFeeState) => state.showoverridedialogbox);

// // get errorModel dialogbox
// export const selectErrorModel = createSelector(selectRoot, (state: BillFeeState) => state.faultRecInfoArray);

export const selectBillListFilter = createSelector(selectRoot, (state: BillFeeState) => state.filterRecordModel);

export const selectFilteredBills =  createSelector(selectRoot, selectBillListFilter,
  (state, filterOptions) => {

    let bills = state.loanBillResponse.lnBilSrchRec;
    if (bills !== undefined && bills !== null && bills.length > 1) {
      // reset
      if (
        filterOptions.paymentAmountFrom !== undefined &&
        filterOptions.paymentAmountFrom === 0 &&
        filterOptions.paymentAmountTo !== undefined &&
        filterOptions.paymentAmountTo === 0 &&
        filterOptions.dateRange !== undefined &&
        filterOptions.dateRange.length !== 2
      ) {

        return bills;
      }
      // filter payment amount from
      if (filterOptions.paymentAmountFrom !== undefined && filterOptions.paymentAmountFrom !== null && filterOptions.paymentAmountFrom !== 0) {
        bills =
          filterOptions.paymentAmountFrom !== 0
            ? bills.filter((bill) => {
                if (bill.lnbilSrchRec?.orgTotAmt !== undefined && filterOptions.paymentAmountFrom !== undefined) {
                  return bill.lnbilSrchRec.orgTotAmt >= filterOptions.paymentAmountFrom;
                }
                return bill;
              })
            : bills;
      }
      // filter payment amount to
      if (filterOptions.paymentAmountTo !== undefined && filterOptions.paymentAmountTo !== null && filterOptions.paymentAmountTo !== 0) {
        bills =
          filterOptions.paymentAmountTo !== 0
            ? bills.filter((bill) => {
                if (bill.lnbilSrchRec?.orgTotAmt !== undefined && filterOptions.paymentAmountTo !== undefined) {
                  return bill.lnbilSrchRec.orgTotAmt <= filterOptions.paymentAmountTo;
                }
                return bill;
              })
            : bills;
      }
      // filter payment due date
      if (filterOptions.dateRange !== undefined && filterOptions.dateRange !== null && filterOptions.dateRange.length === 2) {
        bills =
          filterOptions.dateRange.length === 2
            ? bills.filter((bill) => {
                if (filterOptions.dateRange !== undefined && bill.lnbilSrchRec?.bilDueDt !== undefined) {
                  return new Date(bill.lnbilSrchRec.bilDueDt) >= new Date(filterOptions.dateRange[0]) &&
                         new Date(bill.lnbilSrchRec.bilDueDt) <= new Date(filterOptions.dateRange[1]);
                }
                return bill;
              })
            : bills;
      }
    }
    return bills;
  });

// to get the current selected module
export const selectSelectedModule = createSelector(selectRoot,(state: BillFeeState) => state.selectedModule);


