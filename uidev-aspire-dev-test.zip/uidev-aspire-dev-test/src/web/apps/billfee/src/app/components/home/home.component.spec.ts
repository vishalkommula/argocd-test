import { Subscription } from 'rxjs';
import { PageMode } from '../../models/bill-fee-enums';
import {HomeComponent} from './home.component';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

let component: HomeComponent;

const router = {
  navigateByUrl: jest.fn(),
  navigate: jest.fn()
};

const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn()
};

const pageMode = PageMode.Inquiry;

describe('Home component test',()=>{
  beforeEach(()=> {
    component = new HomeComponent(router as any,storeMock as any);
  });

  it('component should be created',()=> {
    expect(component).toBeTruthy();
  });

  it('ngOnInit method test',()=>{
    component.ngOnInit();
  });

  it('viewBills method test',()=>{
    component.viewBills(pageMode);
  });

  it('viewFees method test',()=>{
    component.viewFees(pageMode);
  });

  it('viewEscrow method test',()=>{
    component.viewEscrow(pageMode);
  });

});

