export interface LnFeeInfoModel{
    lnFeeCode: string;
    lnFeeConcatDescription: string;
    capitalized: string;
    lnFeeSeq: string;
    lnFeeDebtProtType: string;
    lnFeeDebtProtSeq: string;
    shdwFeeBasis: string;
    lnFeeAmt: number;
    lnFeeRemAmt: number;
    lnFeeLastPmtDt: string;
    lnFeeAssmntDt: string;
    lnBillDt: string;
    lnPaidDt: string;
    lnFeeWavDt: string;
}
