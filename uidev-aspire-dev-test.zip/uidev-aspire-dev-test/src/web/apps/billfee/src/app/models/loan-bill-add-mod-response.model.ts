import { FaultMsgRec, SearchMessageRequestHeaderModel } from '@uid/uid-models';
import { LnBilInfoRecItemModel } from './loan-bill-info-record-item.model';

export interface LnBillAddModResponse {
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    lnBilInfoRec: LnBilInfoRecItemModel;
    faultRecInfoArray: FaultMsgRec[];
    rsStat: boolean;
}
