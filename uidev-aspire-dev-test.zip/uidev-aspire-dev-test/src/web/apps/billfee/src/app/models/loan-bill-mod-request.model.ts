import { SearchMessageRequestHeaderModel } from '@uid/uid-models';
import { LnBilInfoRecItemModel } from './loan-bill-info-record-item.model';

export interface LnBilModRequestModel{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    lnBilInfoRec: LnBilInfoRecItemModel;
    overrideFaultMsg: boolean;
};
