import { FormlyField, FormlyFieldConfig } from '@ngx-formly/core';
import * as feeFormFunction from './fee-form.function';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';



describe('bill details function test',()=>{
    // hide debt fields
    it('Hide debt fields if feeCode is 815', () => {
      const model   = {};
      const feeCode = feeFormFunction.isHideDebtFields({lnFeeCode: '815'} as any, {} as any, {} as any);
      expect(feeCode).toBeFalsy();
    });

    it('Hide debt fields if feeCode is 700', () => {
        const model = {lnFeeCode: '700'};
        const feeCode = feeFormFunction.isHideDebtFields({lnFeeCode: '700'} as any, {} as any, {} as any);
        expect(feeCode).toBeTruthy();
    });

    it('Make fields not read only if fee waived date is null', () => {
        const result = feeFormFunction.isReadOnly({lnFeeWavDt: null} as any, {} as any, {} as any);
        expect(result).toBeFalsy();
    });

    it('Make fields read only if fee waived date is available', () => {
        const result = feeFormFunction.isReadOnly({lnFeeWavDt: '22-02-2022'} as any, {} as any, {} as any);
        expect(result).toBeTruthy();
    });

    it('generate formly config should return truthy', () => {
        const formConfig = feeFormFunction.generateFormlyConfig();
        expect(formConfig).toBeTruthy();
    });

});
