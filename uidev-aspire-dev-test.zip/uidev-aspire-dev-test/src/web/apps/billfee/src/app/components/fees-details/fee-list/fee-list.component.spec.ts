import { Observable, of } from 'rxjs';
import { FeesType } from '../fees-enum';
import { FeeListComponent } from './fee-list.component';

import feemockdata from '../../../mock-data/loanBillFeeResponse.mock.json';
import { LnFeeInfoRecModel } from '../../../models/loan-fee-info-record.model';
import { LnFeeModResponse } from '../../../models/loan-bill-fee-mod-response.model';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());

let component: FeeListComponent;
const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(()=> ({
    subscribe:jest.fn()
    })),
};

const router = {
  getCurrentNavigation: jest.fn(() => ({
    extras:{
      state: '2'
    }
  })),
};

const billFeeActionsMock = {
  getLoanFees: jest.fn(),
  getShadowFees: jest.fn(),
  setPageToEditMode:jest.fn(),
  setPageToInquiryMode: jest.fn(),
  selectRecord: jest.fn(),
  saveModifiedFee: jest.fn(),
  cancelModifiedFee: jest.fn(),
  updateLoanFeeFormModel: jest.fn()
};

const billFeeSelectorsMock = {
  selectLoanFee: jest.fn(),
  selectShadowFee: jest.fn(),
  selectIsPageMode: jest.fn(),
  selectFormState: jest.fn(),
  selectFeeRecord: jest.fn(),
  selectModifidedFeeResponse: jest.fn(),
  selectUpdatedFees: jest.fn(),
};


describe('FeeListComponent', () => {
beforeEach(() => {
    component = new FeeListComponent(storeMock as any, router as any);
    component.billFeeActions = billFeeActionsMock as any;
    component.billFeeSelector = billFeeSelectorsMock as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit should call dispatch loanFees', () => {
   const dataa = [{'lnFeeId': 900}];
   const obsvdata: Observable<any[]> = of(dataa);
   component.selectedRecords = obsvdata;
   component.ngOnInit();
    expect(billFeeActionsMock.setPageToInquiryMode).toHaveBeenCalledTimes(1);
    expect(billFeeActionsMock.getLoanFees).toBeCalledWith({ request: {} as any });
    // expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
    expect(billFeeActionsMock.getLoanFees).toHaveBeenCalledTimes(1);
    component.selectedRecords.subscribe((response: LnFeeInfoRecModel) => {
      expect(response).toBeNull();
      expect(component.currentLoanFeeRecord).toEqual(response);
    });

  });

// get shadow loan fees test case
it('on click of shadow loan fees dispatch getShadowLoanFees', () => {
    const event = {detail: 'shadowLoanFees'} as any;
    component.getFeesType(event);
    expect(event.detail).toEqual('shadowLoanFees');
    expect(billFeeActionsMock.getShadowFees).toBeCalledWith({request: {} as any});
    expect(billFeeActionsMock.getShadowFees).toHaveBeenCalledTimes(1);
});

// get loan fees test case
it('on click of loan fees dispatch getLoanFees', () => {
    const event = {detail: 'loanFees'} as any;
    component.getFeesType(event);
    expect(event.detail).toEqual('loanFees');
    expect(billFeeActionsMock.getLoanFees).toBeCalledWith({request: {} as any});
});

  // set page mode to edit
it('on click of edit button set page mode to edit', () => {
    const event = {'lnFeeId': 700} as any;
    component.editSelectedRecord(event);
    expect(billFeeActionsMock.setPageToEditMode).toHaveBeenCalledTimes(1);
});

it('unsave dialogbox', ()=> {
    const event = {detail: 'Don\'t Save'};
    const detail = component.unsaveDialogBoxClose(event);
    expect(billFeeActionsMock.cancelModifiedFee).toHaveBeenCalledTimes(1);
});

it('override dialogbox', ()=> {
    const overrideDialogBoxEvent = {detail: 'Override'};
    component.overrideDialogBoxClose(overrideDialogBoxEvent);
    expect(component.showOverrideDialogBox).toBeFalsy();
    expect(overrideDialogBoxEvent.detail).toEqual('Override');
    component.saveBillFeeEdit();
    expect(billFeeActionsMock.setPageToInquiryMode).toHaveBeenCalledTimes(2);
});

it('cancel Edit in fee form', () => {
    component.cancelBillFeeEdit();
    expect(component.showUnsaveDialogBox).toBeTruthy();
});

it('selected fee', () => {
    const feedata = {data: {'lnFeeCode': 1, 'lnFeeConcatDescription': 'test', 'lnFeeWavDt': '2021-05-30'}};
    component.getSelectedRecord(feedata);
    expect(billFeeActionsMock.selectRecord).toBeCalledWith({currentRecord: feedata['data']});
});

it('on change event of billfee foem', () => {
    const feedata = {   lnFeeCode: '815',
    lnFeeId: 6,
    lnFeeConcatDescription: 'Other Charges',
    capitalized: 'Yes',
    lnFeeSeq: 'Test Data',
    lnFeeDebtProtType: '',
    lnFeeDebtProtSeq: '',
    lnFeeAmt: 2000,
    lnFeeRemAmt: 9000,
    lnFeeLastPmtDt: '2021-04-03',
    lnFeeAssmntDt: '2021-04-20',
    lnBillDt: '2021-12-31',
    lnPaidDt: '2021-01-26',
    lnFeeWavDt: '2021-04-03',
    loanFeeCategory: '',
    shdwFeeBasis: ''};
    component.currentLoanFeeModelChange(feedata);
    expect(billFeeActionsMock.updateLoanFeeFormModel).toBeCalledWith({updateFeeFormModel: feedata});
});

// saveModifiedFee response is success
it('save edit fee no fault/error and success response', () => {
  component.currentLoanFeeRecord =  { lnFeeCode: 1, lnFeeConcatDescription: 'test', lnFeeWavDt: '2021-05-30', lnFeeBillDt: '2022-01-22'} as any;
   const updatedFeeMockRequest = {
    srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
    acctId: '12',
    acctType: 'A',
    lnFeeInfo: {...component.currentLoanFeeRecord},
    overrideFaultMsg: false,
   };
   const updatedFeeMockResponse = {
    srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
    acctId: '12',
    acctType: 'A',
    faultRecInfoArray: [],
    rsStat: true,
    lnFeeInfo: feemockdata as any,};


   const modifiedFeeObservableData: Observable<LnFeeModResponse> = of(updatedFeeMockResponse);
   component.modFeeObservable = modifiedFeeObservableData;
   component.saveBillFeeEdit();
   billFeeSelectorsMock.selectUpdatedFees = updatedFeeMockResponse.lnFeeInfo;
   expect(billFeeActionsMock.saveModifiedFee).toBeCalledWith({request: updatedFeeMockRequest as any});
   component.modFeeObservable.subscribe(response => {
     expect(response.faultRecInfoArray.length).toEqual(0);
     expect(component.feeData$).toEqual(feemockdata);
    });
});


// saveModifiedFee response has Faultarray with error category as fault
it('save edit fee fault array response with error as fault', () => {
  component.currentLoanFeeRecord =  { lnFeeCode: 1, lnFeeConcatDescription: 'test', lnFeeWavDt: '2021-05-30', lnFeeBillDt: '2022-01-22'} as any;
  const updatedFeeMockRequest = {
   srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
   acctId: '12',
   acctType: 'A',
   lnFeeInfo: {...component.currentLoanFeeRecord},
   overrideFaultMsg: false,
  };
  const feedata = {
    srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
    acctId: '12',
    acctType: 'A',
    faultRecInfoArray: [{
       errCode:'200924',
       errCat:'Fault',
       errDesc:'Paid date may not be valid',
       errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
       errElemVal:'88880/L/ 2022026',
       errLoc:'LNBILLMOD',
      }],
  rsStat: true,
  lnFeeInfo: feemockdata as any,};

  const modifiedFeeObservableData: Observable<LnFeeModResponse> = of(feedata);
  component.modFeeObservable = modifiedFeeObservableData;
  component.saveBillFeeEdit();
  expect(billFeeActionsMock.saveModifiedFee).toBeCalledWith({request: updatedFeeMockRequest as any});
  expect(component.showOverrideDialogBox).toBeTruthy();
});

// save edit response has faultarray with error category has error
it('save edit fee fault array response with error', () => {
  component.currentLoanFeeRecord =  { lnFeeCode: 1, lnFeeConcatDescription: 'test', lnFeeWavDt: '2021-05-30', lnFeeBillDt: '2022-01-22'} as any;
  const updatedFeeMockRequest = {
   srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
   acctId: '12',
   acctType: 'A',
   lnFeeInfo: {...component.currentLoanFeeRecord},
   overrideFaultMsg: false,
  };
  const feedata = {
    srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
    acctId: '12',
    acctType: 'A',
    faultRecInfoArray: [{
       errCode:'200924',
       errCat:'Error',
       errDesc:'Paid date may not be valid',
       errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
       errElemVal:'88880/L/ 2022026',
       errLoc:'LNBILLMOD',
      }],
  rsStat: true,
  lnFeeInfo: feemockdata as any,};


  const modifiedFeeObservableData: Observable<LnFeeModResponse> = of(feedata);
  component.modFeeObservable = modifiedFeeObservableData;
  component.saveBillFeeEdit();
  expect(billFeeActionsMock.saveModifiedFee).toBeCalledWith({request: updatedFeeMockRequest as any});
  component.modFeeObservable.subscribe(response => {
   expect(response.faultRecInfoArray.filter(err => err.errCat === 'Error').length).toBeGreaterThan(0);
   expect(component.errorInfoArray).toEqual(response.faultRecInfoArray.filter(err => err.errCat === 'Error'));
  });
});


it('save edit fee fault array response with response status as false', () => {
  component.currentLoanFeeRecord =  { lnFeeCode: 1, lnFeeConcatDescription: 'test', lnFeeWavDt: '2021-05-30', lnFeeBillDt: '2022-01-22'} as any;
  const updatedFeeMockRequest = {
   srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
   acctId: '12',
   acctType: 'A',
   lnFeeInfo: {...component.currentLoanFeeRecord},
   overrideFaultMsg: false,
  };
  const feedata = {
    srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
    acctId: '12',
    acctType: 'A',
    faultRecInfoArray: [{
       errCode:'200924',
       errCat:'Error',
       errDesc:'Paid date may not be valid',
       errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
       errElemVal:'88880/L/ 2022026',
       errLoc:'LNBILLMOD',
      }],
  rsStat: false,
  lnFeeInfo: feemockdata as any,};

  const loanFeeMock = { lnFeeCode: 1, lnFeeConcatDescription: 'test', lnFeeWavDt: '2021-05-30', lnFeeBillDt: '2022-01-22'};

  const modifiedFeeObservableData: Observable<LnFeeModResponse> = of(feedata);
  component.modFeeObservable = modifiedFeeObservableData;
  component.currentLoanFeeRecord = loanFeeMock as any;
  component.saveBillFeeEdit();
  expect(billFeeActionsMock.saveModifiedFee).toBeCalledWith({request: updatedFeeMockRequest as any});
  component.modFeeObservable.subscribe(response => {
  expect(response.rsStat).toBeFalsy();
  });
});

it('if event in getSelectedRecord case is false', () => {
   const eventdata = false;
   component.getSelectedRecord(eventdata);
   expect(component.getSelectedRecord(eventdata)).toBeFalsy();
});

it('on ngOnDestroy', () => {
    const testdata1 = of(feemockdata);
    const subscription1 = testdata1.subscribe();
    const subscription2 = testdata1.subscribe();
    component.ngOnDestroy();
    component.subscriptions = [subscription1, subscription2];
    component.subscriptions.forEach(subs => subs.unsubscribe());
    expect(component.subscriptions).toBeTruthy();
});

});
