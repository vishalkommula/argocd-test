export interface LnFeeInqRecItemModel{
    lnFeeCode?: string;
};
