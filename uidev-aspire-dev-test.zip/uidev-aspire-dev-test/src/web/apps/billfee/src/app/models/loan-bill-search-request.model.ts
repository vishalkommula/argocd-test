import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface LnBilSrchRequestModel{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
};
