import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { formatFaultMessages } from '@uid/uid-utilities';
import { Observable, Subscription } from 'rxjs';
import { BillFeeModulesEnum, billFeeValueTypes, PageMode } from '../../models/bill-fee-enums';
import { FaultMsgRec } from '../../models/loan-bill-error.model';
import { LnBilEscrwEditSrchRequest } from '../../models/loan-bill-escrow-edit-request.model';
import { LnBilEscrwInfoRecModel } from '../../models/loan-bill-escrow-info-record.model';
import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';
import { SLLnBilEscrwPmtBalInfoRecItem } from '../../models/sl-loan-bill-escrow-pmt-bal-info-record-item.model';
import * as escrowActionsMock from '../../store/actions/billescrow.action';
import * as escrowSelectorMock from '../../store/selectors/billescrow.selector';
import * as BillInfoActions from '../../store/actions/billInfo.action';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import { SelectedFaultError } from '@uid/uid-angular-controls';

@Component({
  selector: 'uid-escrow',
  templateUrl: './escrow.component.html',
  styleUrls: ['./escrow.component.scss'],
})
export class EscrowComponent implements OnInit, OnDestroy {
  escrowDetails$!: Observable<LnBilEscrwInfoRecModel>;
  escrowEditDetails$!: Observable<LnBilEscrwSrchResponse>;
  // this property used to store temporary data of escrowDetails on click of save. so escrowDetail is passed on override clic
  escrowDetails!: LnBilEscrwInfoRecModel;
  subs: Subscription[] = [];
   // faultRecInfoArray
  faultRecInfoArray: FaultMsgRec[] = [];
  errorRecInfoArray: FaultMsgRec[] = [];

  // dailog box
  public showDialogBox = false;
  public cancelDialogBox = false;
  public showDialogBoxWithCanClose = false;
  public canClose = true;
  // override dailog box
  showOverrideDialogBox = false;
  canCloseDialogBox = true;

  selectedBoxes: string[] = [];
  billScreenTypeEnum = BillFeeModulesEnum;
  billFeeValue = billFeeValueTypes;
  escrowPageMode!: PageMode;
  pageMode$: Observable<PageMode>;
  pageModeEnum = PageMode;
  public screenType!: string;
  escrowActions = escrowActionsMock;
  escrowSelector = escrowSelectorMock;
  billInfoAction = BillInfoActions;

  constructor(private store: Store, private router: Router) {
    this.pageMode$ = this.store.select(this.escrowSelector.selectPageMode);
    this.screenType = this.billScreenTypeEnum.escrow;
    this.escrowPageMode = this.pageModeEnum.Inquiry;
    if (this.router.getCurrentNavigation()?.extras.state !== undefined) {
      const stateData = this.router.getCurrentNavigation()?.extras.state;
      this.screenType = stateData !== undefined ? stateData['pageType'] : 'Escrow';
      this.escrowPageMode = this.pageModeEnum.Inquiry;
    }
    this.escrowEditDetails$ = this.store.select(this.escrowSelector.selectEscrowEditDetails);
  }

  ngOnInit(): void {
    this.store.dispatch(this.escrowActions.getEscrow({ request: {} as any }));
    this.escrowDetails$ = this.store.select(this.escrowSelector.selectEscrowDetails);
  }

  enableEditMode() {
    this.escrowPageMode = PageMode.Edit;
    this.togglePageMode(PageMode.Edit);
  }

  // Cancelfunction
  cancelChanges() {
    this.cancelDialogBox = true;
  }

  // Savefunction
  saveChanges(formEscrowDetails: LnBilEscrwInfoRecModel, overWarning = false) {
    this.escrowDetails = formEscrowDetails;
    const updatedEscrowDetails: LnBilEscrwEditSrchRequest = {
      srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
      acctId: '12',
      acctType: 'A',
      lnBilEscrwInfoRec: {
        escrowInfo: this.escrowDetails.escrowInfo,
        escrowBalances: this.escrowDetails.escrowBalances,
        lnBilEscrowId: this.escrowDetails.lnBilEscrowId,
        billDt: this.escrowDetails.billDt,
        override: overWarning,
      },
    };
    // after click on save button geting the data
    this.store.dispatch(this.escrowActions.saveEscrow({ updateRecord: updatedEscrowDetails }));
    const subSelectEscrowEditDetails = this.escrowEditDetails$.subscribe((data) => {
      if (data !== undefined) {
        const faultArrayMessages = formatFaultMessages(data.faultRecInfoArray);
        this.faultRecInfoArray = faultArrayMessages.faultArray; // fault Array
        this.errorRecInfoArray = faultArrayMessages.errorArray; // Error Array

        this.showOverrideDialogBox = this.errorRecInfoArray.length < 1 && this.faultRecInfoArray.length > 0;
      }
    });
    this.subs.push(subSelectEscrowEditDetails);
  }

  overridedialogBoxClose(selectedFaultError: SelectedFaultError) {
    this.showOverrideDialogBox = false;
    if (selectedFaultError.clickAction === this.billFeeValue.overrideMsg) {
      this.saveChanges(this.escrowDetails, true);
      this.escrowPageMode = PageMode.Inquiry;
 	// TODO: After API integration, need to move to the save logic based on override warning
      this.togglePageMode(PageMode.Inquiry);
      this.showOverrideDialogBox = false;
    }
  }


  public dialogBeforeClose() {
    this.showDialogBox = false;
  }

  // globalClose
  public dialogBoxClose(event: any) {
    this.cancelDialogBox = false;
    if (event.detail === this.billFeeValue.donotSave) {
      this.togglePageMode(PageMode.Inquiry);
      this.escrowPageMode = PageMode.Inquiry;
      this.store.dispatch(this.escrowActions.getEscrow({ request: {} as any }));
    } else {
      this.showDialogBox = false;
      this.cancelDialogBox = false;
    }
  }

  ngOnDestroy(): void {
    this.subs.forEach((sub) => sub.unsubscribe());
  }

  togglePageMode(currentPageMode: PageMode):void{
    this.store.dispatch(this.billInfoAction.changePageMode({ clickAction: currentPageMode }));
  }

}
