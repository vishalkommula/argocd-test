import { FeesGridParentEnum, PageMode } from '../../../models/bill-fee-enums';
import { FeeGridDetailsDef } from './fees-grid-details.def';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

let service: FeeGridDetailsDef;
const router = {
  navigate: jest.fn(),
};
const billActionMock={
  updateAttachedFee:jest.fn()
};
const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(() => ({
    subscribe: jest.fn(),
  })),
};
describe('FeeGridDetailsDef', () => {
  beforeEach(() => {
    service = new FeeGridDetailsDef(router as any, storeMock as any);
    service.billInfoActions=billActionMock as any;
  });
  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('dateFormatter convert date to MM/dd/YYYY format', () => {
    const params = { value: '2022-07-07' };
    expect(service.dateFormatter(params as any)).toBe('07/07/2022');
  });

  it('dateFormatter invalid date', () => {
    const params = { value: '07-07-2022' };
    expect(service.dateFormatter(params as any)).toBe('07-07-2022');
  });
  it('currencyFormatter convert number to currency and returns currency format', () => {
    const params = { value: '2000' };
    expect(service.currencyFormatter(params as any)).toBe('$2,000.00');
  });

  it('currencyFormatter returns empty if value is empty', () => {
    const params = { value: undefined };
    expect(service.currencyFormatter(params as any)).toBe('');
  });

  it('feeDescriptionValueGetter returns empty if value is empty', () => {
    const params = { data: {lnFeeCode:'01',lnFeeConcatDescription:'LateCharge'} };
    expect(service.feeDescriptionValueGetter(params as any)).toBe('01 - LateCharge');
  });

  it('onDueDateClick navigates to particular bill due date in bill screen', () => {
    service.onDueDateClick({ rowData: { lnBillDt: '10/22/2022' } });
    expect(router.navigate).toBeCalledTimes(1);
  });

  it('onEdit function convert readonly screen to editable in fee', () => {
    service.editSelectedFee = { emit: jest.fn() } as any;
    service.onEdit({} as any);
    expect(service.editSelectedFee.emit).toBeCalledTimes(1);
  });

  it('getDefaultColumnDef returns defaultColumnDef on editMode is true', () => {
    const defaultColumnDef = {
      filter: false,
      resizable: false,
      sortable: false,
      editable: false,
      enableValue: false,
      enablePivot: false,
      enableRowGroup: false,
      suppressMenu: true,
      suppressMovable: true,
    };
    expect(service.getDefaultColumnDef(true)).toStrictEqual(defaultColumnDef);
  });

  it('getautoGroupColumnDef returns autoGroupColumnDef for pageType is fee', () => {
    const autoGroupColumnDef=service.getautoGroupColumnDef(FeesGridParentEnum.FeeDetails,PageMode.Inquiry,true);
    expect(autoGroupColumnDef)
    .toBeInstanceOf(Object);
  });
  it('getautoGroupColumnDef returns autoGroupColumnDef for pageType is billFee', () => {
    const autoGroupColumnDef=service.getautoGroupColumnDef(FeesGridParentEnum.BillFee,PageMode.Inquiry,true);
    expect(autoGroupColumnDef)
    .toBeInstanceOf(Object);
  });
  it('getautoGroupColumnDef returns autoGroupColumnDef for pageType is billFee and valueFormatter', () => {
    const autoGroupColumnDef=service.getautoGroupColumnDef(FeesGridParentEnum.BillFee,PageMode.Inquiry,true);
    const params={data:{lnFeeCode :'1',lnFeeConcatDescription:'lateCharge'}};
    expect(autoGroupColumnDef)
    .toBeInstanceOf(Object);
  });
  it('numberParser returns number', () => {
    const params = { newValue: 10 };
    expect(service.numberParser(params as any)).toBe(10);
  });

  it('modifyGridOptionsDef returns GridOptions for pageMode add', () => {
    const gridOptions=service.modifyGridOptionsDef(PageMode.Add);
    expect(gridOptions).toStrictEqual(service.billAGridOptions);
  });

  it('modifyGridOptionsDef returns GridOptions for pageMode edit', () => {
    const gridOptions=service.modifyGridOptionsDef(PageMode.Edit);
    expect(gridOptions).toStrictEqual(service.billAGridOptions);
  });

  it('modifyGridOptionsDef returns GridOptions for pageMode inquiry', () => {
    const gridOptions=service.modifyGridOptionsDef(PageMode.Inquiry);
    expect(gridOptions).toStrictEqual(service.billAGridOptions);
  });

  // it('cellEditRequest dispatch updateAttachedFee after ediing the cell', () => {
  //   service.billDueDt='2022-07-07';
  //   const event={data:{value1:'data'},colDef:{field:'value1'}};
  //   service.cellEditRequest(event as any);
  //   expect(storeMock.dispatch).toBeCalledTimes(1);
  //   expect(billActionMock.updateAttachedFee).toBeCalledTimes(1);
  // });

  it('modifyColumnDef returns colDef for pageMode inquiry', () => {
    const colDefList=service.modifyColumnDef(PageMode.Inquiry);
    expect(colDefList).toStrictEqual(service.billFeeGridColumns);
  });

  it('modifyColumnDef returns colDef for pageMode edit', () => {
    const colDefList=service.modifyColumnDef(PageMode.Edit);
    expect(colDefList).toStrictEqual(service.billFeeGridColumns);
  });
  it('modifyColumnDef returns colDef for pageMode add', () => {
    const colDefList=service.modifyColumnDef(PageMode.Add);
    expect(colDefList).toStrictEqual(service.billFeeGridColumns);
  });
});
