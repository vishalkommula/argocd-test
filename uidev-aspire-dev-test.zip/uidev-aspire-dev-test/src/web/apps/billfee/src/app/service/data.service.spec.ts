import { DataService } from './data.service';

let service: DataService;
const httpMock = {
    get:jest.fn(),
    post:jest.fn()
};
describe('DataService', () => {
  beforeEach(() => {
    service = new DataService(httpMock as any);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

    // to get the bill list data test
    test('getBillsList returns bill list response', async ()=> {
      expect(await service.getBills({} as any).toPromise()).toBeTruthy();
    });

  it('getBillDetailsbyBillduedt should return response',()=>{
    const billInqRes=service.getBillDetailsbyBillduedt({srchMsgRqHdr:{bilDueDt:new Date('2022-02-15')}} as any);
    expect(billInqRes).not.toBeNull();
  });

  it('httpclient get call',()=>{
      expect(httpMock.get).toBeCalledTimes(0);
  });

    it('updatebilldetails should call to update billdetails',()=>{
        const value=service.updatebilldetails({}as  any);
        expect(value.toPromise()).resolves.toBe(true);
    });

    it('addbilldetails should call to update billdetails',()=>{
        const value=service.addbilldetails({}as  any);
        expect(value.toPromise()).resolves.toBe(true);
    });

    it('updatebilldetails should call http post',()=>{
        expect(httpMock.post).toBeCalledTimes(0);
    });

    it('addbilldetails should call http post',()=>{
        expect(httpMock.post).toBeCalledTimes(0);
    });

    it('deletebilldetails should call to update billdetails',()=>{
      const value=service.deletebilldetails({}as  any);
      expect(value.toPromise()).resolves.toBe(true);
  });

    it('deletebilldetails should call http post',()=>{
      expect(httpMock.post).toBeCalledTimes(0);
  });

  it('getLoanFees method should fetch the data', async ()=> {
    expect(service.getLoanFees({} as any).toPromise()).toBeTruthy();
  });

  it('getShadowFees method should fetch the data', async ()=> {
    expect(service.getShadowFees({} as any).toPromise()).toBeTruthy();
  });

  it('setUpdatedBillFee should return a promise', async ()=> {
    const value=service.setUpdatedBillFee({}as  any);
        expect(value.toPromise()).resolves.toBe(true);
  });

  it('getEscrowDetails returns escorw list response', async ()=> {
    expect(await service.getEscrowDetails({} as any).toPromise()).toBeTruthy();
  });

  it('saveEscrowDetails returns escrow edit list response', async ()=> {
    expect(await service.saveEscrowDetails({} as any).toPromise()).toBeTruthy();
  });
});
