/* eslint-disable brace-style */
import { Component,OnDestroy, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { Observable, Subscription } from 'rxjs';

// model
import { LoanFeeFormStateModel } from '../../../models/loan-fee-form-state.model';
import { LnFeeInfoRecModel } from '../../../models/loan-fee-info-record.model';
import { FaultMsgRec } from '@uid/uid-models';

// action and selectores
import * as BillFeesActions from '../../../store/actions/billfee.action';
import * as BillFeesSelectors from '../../../store/selectors/billfee.selector';
import { BillFeeState } from '../../../store/states/billfee.state';

// formly configuration
import { generateFormlyConfig} from '../fees-details-functions/fee-form.function';

// enums
import {  billFeeValueTypes, FeesGridParentEnum, PageMode } from '../../../models/bill-fee-enums';
import { FeesType } from '../fees-enum';
import { LnFeeModResponse } from '../../../models/loan-bill-fee-mod-response.model';
import { formatDate } from '@uid/uid-utilities';
import { SelectedFaultError } from '@uid/uid-angular-controls';



@Component({
  selector: 'uid-fee-list',
  templateUrl: './fee-list.component.html',
  styleUrls: ['./fee-list.component.scss'],
})
export class FeeListComponent implements OnInit, OnDestroy {
  // fee grid data
  public feeData$!: Observable<LnFeeInfoRecModel[]>;
  public feeDetailsPageType: FeesGridParentEnum = FeesGridParentEnum.FeeDetails;
  public selectedFeesType = FeesType.loanFees;
  modFeeObservable!: Observable<LnFeeModResponse>;

  // formly property binding
  billFeeForm = new FormGroup({});
  currentLoanFeeRecordGroup!: FormlyFieldConfig[];
  currentLoanFeeRecord!: LnFeeInfoRecModel;
  formState$!: Observable<LoanFeeFormStateModel>;
  pageMode$!: Observable<PageMode>;

  // to get selected fee code & fee description
  feeCode = {};
  feeDesc!: string;
  feeWaivedDt!: string;
  // flag for showing unsave changes dialog box
  showUnsaveDialogBox = false;
  // flag for showing override dialog box
  public showOverrideDialogBox = false;
  // faultRecInfoArray
  faultRecInfoArray: FaultMsgRec[] = [];
  errorInfoArray: FaultMsgRec[] = [];
  selectedRecords!: any;
  // enums
  pageMode = PageMode;
  feesType = FeesType;
  billFeeTypeValues = billFeeValueTypes;
  isSelectedShadowFees = false;
  // subscriptions
  subscriptions: Subscription[] = [];
  // route to the selected fee ID
  routeFeeID='';

  // actions
  billFeeActions = BillFeesActions;
  billFeeSelector = BillFeesSelectors;
  subscribeFeeRecord!: Subscription;

  constructor(private store: Store<BillFeeState>, private route: Router) {

    // router and higlighing theselected fee id
    if(this.route.getCurrentNavigation()?.extras.state !== undefined){
      const stateData = this.route.getCurrentNavigation()?.extras.state;
      this.routeFeeID = stateData !== undefined ? stateData['selectedFeeID'] : '';
    }
    this.store.dispatch(BillFeesActions.setPageToInquiryMode());

    this.selectedRecords =  this.store.select(this.billFeeSelector.selectFeeRecord);
    this.modFeeObservable = this.store.select(this.billFeeSelector.selectModifiedFeeResponse);
  }

  ngOnInit(): void {

    // set page mode to inquiry
    this.store.dispatch(this.billFeeActions.setPageToInquiryMode());

    // dispatch event for get loan fees
    this.store.dispatch(this.billFeeActions.getLoanFees({ request: {} as any }));

    // assign loan fees grid data
    this.feeData$ = this.store.select(this.billFeeSelector.selectLoanFee);

    // assign loan fees grid data
    this.feeData$ = this.store.select(this.billFeeSelector.selectShadowFee);

    // assign selected formly form mode inquiry/editMode for header data binding
    this.pageMode$ = this.store.select(this.billFeeSelector.selectPageMode);

    // assign current formstate to change formly formstate property binding
    this.formState$ = this.store.select(this.billFeeSelector.selectFormState);

    // trigger formly form fields
    this.currentLoanFeeRecordGroup = generateFormlyConfig();


    // subscribe to selectedfee record data
    this.subscribeFeeRecord = this.selectedRecords.subscribe((res: LnFeeInfoRecModel) => {
      if ((res != null)) {
        this.currentLoanFeeRecord = res;
      }
    });

    // push all subscripbe into subscription array
    this.subscriptions.push(this.subscribeFeeRecord);

  }

  // get selected fees type
  getFeesType(selectFeesTypeEvent: any, pageMode: any){
    if(PageMode.Inquiry === pageMode){
      this.selectedFeesType = selectFeesTypeEvent.detail;
    }
    switch(this.selectedFeesType){
      case this.feesType.shadowFees:
        this.store.dispatch(this.billFeeActions.getShadowFees({ request: {} as any }));
      break;
      case this.feesType.loanFees:
        this.currentLoanFeeRecordGroup = generateFormlyConfig();
        this.store.dispatch(this.billFeeActions.getLoanFees({ request: {} as any }));
      break;
    }
    return true;
  }

  // select current fee record
  getSelectedRecord(selectFeeRecordEvent: any) {
  if(selectFeeRecordEvent === false){
   this.showUnsaveDialogBox = true;
  }else{
    this.store.dispatch(
      this.billFeeActions.selectRecord({
        currentRecord: selectFeeRecordEvent['data']
      })
    );
    this.feeCode = selectFeeRecordEvent.data.lnFeeCode;
    this.feeDesc = selectFeeRecordEvent.data.lnFeeConcatDescription;
    this.feeWaivedDt = selectFeeRecordEvent.data.lnFeeWavDt;
  }
  }

  // on grid edit button click
  editSelectedRecord(e: any){
    return this.editSelectedFee();
  }

  // edit selected fee on form edit button click
  editSelectedFee() {
    this.store.dispatch(this.billFeeActions.setPageToEditMode());
  }

  // model change
  currentLoanFeeModelChange(formData: LnFeeInfoRecModel){
     if(Date.parse(formData['lnBillDt'])){
      formData.lnBillDt = formatDate(formData.lnBillDt ?? '',billFeeValueTypes.isoDateFormatter);
   }
    if(Date.parse(formData['lnPaidDt'])){
      formData.lnPaidDt = formatDate(formData.lnPaidDt ?? '',billFeeValueTypes.isoDateFormatter);
   }
    this.store.dispatch(
      this.billFeeActions.updateLoanFeeFormModel({
        updateFeeFormModel: formData as LnFeeInfoRecModel
      })
      );
  }

  // dialog box close event trigger for dialog box buttons
  unsaveDialogBoxClose(unsaveDialogBoxEvent: any) {
    this.showUnsaveDialogBox = false;
     if (unsaveDialogBoxEvent.detail === this.billFeeTypeValues.donotSave) {
      this.store.dispatch(this.billFeeActions.cancelModifiedFee());
    }
  }

  // dispatch an event if override is clicked
  overrideDialogBoxClose(selectedFaultError: SelectedFaultError){
    this.showOverrideDialogBox = false;
   if(selectedFaultError.clickAction === this.billFeeTypeValues.overrideMsg) {
      this.saveBillFeeEdit();
      // to-do will be removed during api integration
      this.store.dispatch(this.billFeeActions.setPageToInquiryMode());
    }
  }


  // cancel modified fee form
  cancelBillFeeEdit() {
    return this.showUnsaveDialogBox = true;
  }

  // save modified fee form
  saveBillFeeEdit() {
  // dispatch save event on bill fee save
    // eslint-disable-next-line no-debugger 
   const loanFeeModRequest ={
    srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
    acctId: '12',
    acctType: 'A',
    lnFeeInfo: {...this.currentLoanFeeRecord},/// shallow copy to avoid immutable refer excpetion,
    overrideFaultMsg: false,
   };
    this.store.dispatch(
      this.billFeeActions.saveModifiedFee({
        request: loanFeeModRequest as any,
      })
    );

  // selector for once form data is saved
      const subscribeEditedData = this.modFeeObservable.subscribe((response) => {
        if(response !== undefined){
          // if response status is true
        if (response.rsStat === true) {
          // scenario 1 no fault/errors
          if(response.faultRecInfoArray.length === 0){
            this.feeData$ = this.store.select(this.billFeeSelector.selectUpdatedFees);
            }
            // secenario 2 if faultrec array has errors/faults
            else if(response.faultRecInfoArray.length !== 0){
              this.faultRecInfoArray = response.faultRecInfoArray;
              // case 1 if error exists
               if(response.faultRecInfoArray.filter((fault: any) => fault.errCat === this.billFeeTypeValues.errMsg).length !== 0){
                this.errorInfoArray = response.faultRecInfoArray.filter((fault: any) => fault.errCat === this.billFeeTypeValues.errMsg);
                return;
              }
                else if(response.faultRecInfoArray.filter((fault: any) => fault.errCat === this.billFeeTypeValues.faultMsg).length !== 0){

                  this.showOverrideDialogBox = !this.showOverrideDialogBox;
                }

            }
        }
        // if response status is false
         else if (response.rsStat === false) {
           };
          }
      });

      this.subscriptions.push(subscribeEditedData);

  }

  ngOnDestroy(){
    this.subscriptions.forEach(subs => subs.unsubscribe());
  }
}
