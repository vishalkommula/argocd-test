import { Injectable} from '@angular/core';
import { ColDef, GridOptions, ValueFormatterParams } from 'ag-grid-community';
import {
  AgGridPInputnumberEditorComponent,
  AgGridPInputnumberRendererComponent,
} from '@uid/uid-angular-controls';

@Injectable({
  providedIn: 'root',
})
export class EscrowgridcoldefService {
  constructor() {
  }


  public default: ColDef = {
    enablePivot: false,
    resizable:true,
    sortable:true,
    filter: true,
    editable: false,
    enableValue: false,
    suppressMenu: false,
    suppressMovable: true,
  };
  public defaultEditableScreen: ColDef = {
    enablePivot: false,
    filter: false,
    resizable:false,
    sortable:false,
    suppressMenu:true
  };

  public editableColumns: ColDef[] = [
    {
      field: 'balFldAff',
      headerName: 'Balance Field to Affect',
      suppressMovable: true,

    },
    {
      field: 'escrwPmtBalDesc',
      headerName: 'Balance Description',
      suppressMovable: true
    },
    {
      field: 'escrwPmtAmt',
      headerName: 'Payment Due',
      editable: true,
      filter: 'agNumberColumnFilter',
      cellEditor: 'agGridPInputnumberEditor',
      cellEditorParams :{
        minFractionDigits: 2,
        maxFractionDigits: 2,
        locale: 'en-US',
        step: .01,
        prefix: '$',
        mode: 'currency',
        currency:'USD',
        maxlength: 15,
        inputStyleClass:'prime-inputNumber',
        dataTestId:'escrow-PmtAmt'
      },
      cellRenderer: 'agGridPInputnumber',
      cellRendererParams :{
        minFractionDigits: 2,
        maxFractionDigits: 2,
        locale: 'en-US',
        step: .01,
        prefix: '$',
        mode: 'currency',
        currency:'USD',
        maxlength: 15,
        inputStyleClass:'prime-inputNumber',
        dataTestId:'escrow-PmtAmt'
      },
      suppressMovable: true
    },
    {
      field: 'escrwPmtAmtRem',
      headerName: 'Payment Remaining',
      editable: true,
      filter: 'agNumberColumnFilter',
      cellEditor: 'agGridPInputnumberEditor',
      cellEditorParams :{
        minFractionDigits: 2,
        maxFractionDigits: 2,
        locale: 'en-US',
        step: .01,
        prefix: '$',
        mode: 'currency',
        currency:'USD',
        maxlength: 15,
        inputStyleClass:'prime-inputNumber',
        dataTestId:'escrow-PmtAmtRem'
      },
      cellRenderer: 'agGridPInputnumber',
      cellRendererParams :{
        minFractionDigits: 2,
        maxFractionDigits: 2,
        locale: 'en-US',
        step: .01,
        prefix: '$',
        mode: 'currency',
        currency:'USD',
        maxlength: 15,
        inputStyleClass:'prime-inputNumber',
        dataTestId:'escrow-PmtAmtRem'
      },
      suppressMovable: true
    },
  ];

  public readonlyColumns: ColDef[] = [
    {
      field: 'balFldAff',
      headerName: 'Balance Field to Affect',
      suppressMovable: true,
      filter: 'agSetColumnFilter',
      filterParams: {
        comparator: (a: any, b: any) => {
            // eslint-disable-next-line radix
            const valA = parseInt(a);
            // eslint-disable-next-line radix
            const valB = parseInt(b);
            if (valA === valB){
               return 0;
            }
            return valA > valB ? 1 : -1;
        }
    }
    },
    {
      field: 'escrwPmtBalDesc',
      headerName: 'Balance Description',
      suppressMovable: true
    },
    {
      field: 'escrwPmtAmt',
      headerName: 'Payment Due',
      valueFormatter: this.amountFormatter,
      cellClass: 'ag-right-aligned-cell',
      resizable: true,
      suppressMovable: true,
      filterParams: {
        valueFormatter: this.currencyFormatter
      },
    },
    {
      field: 'escrwPmtAmtRem',
      headerName: 'Payment Remaining',
      valueFormatter: this.amountFormatter,
      filter: true,
      cellClass: 'ag-right-aligned-cell',
      resizable: true,
      suppressMovable: true,
      filterParams: {
        valueFormatter: this.currencyFormatter
      },
    },
  ];

  public gridOptions: GridOptions = {
    sideBar: false,
    rowSelection: 'single',
    cacheBlockSize: 100,
    maxBlocksInCache: 25,
    rowHeight: 30,
    suppressDragLeaveHidesColumns: true,
    frameworkComponents: {
      agGridPInputnumber: AgGridPInputnumberRendererComponent,
      agGridPInputnumberEditor: AgGridPInputnumberEditorComponent,
    },
  };

  amountFormatter(params: ValueFormatterParams) {
    if (!params || !params.value) {
      return '';
    }
    const currentRecord = params.value;

    const inrFormat = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    });
    return `${inrFormat.format(currentRecord)}`;
  }

  currencyFormatter(params: ValueFormatterParams) {
    const currentRecord = params.value;
    const inrFormat = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    });
    const formattedRecord = inrFormat.format(currentRecord);
    return formattedRecord;
  }
}
