import { BillFeeModulesEnum, BillFeeRoutesEnum, PageMode } from '../../../models/bill-fee-enums';
import { EscrowDetailsComponent } from './escrow-details.component';
import escrowMockData from '../../../mock-data/loanBillescrowResponse.mock.json';
import escrowmockeditdata from '../../../mock-data/loanBillescrowEditResponse.mock.json';
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());

import 'ag-grid-enterprise';
import { AgGridModule } from 'ag-grid-angular';
import { LnBilEscrwEditSrchRequest } from '../../../models/loan-bill-escrow-edit-request.model';
import { EscrowgridcoldefService } from './escrow-grid-coldef.service';
import { Observable, of } from 'rxjs';
import { LnBilEscrwSrchResponse } from '../../../models/loan-bill-escrow-response.model';
import { Column, GridReadyEvent, GridSizeChangedEvent } from 'ag-grid-community';
import { SLLnBilEscrwInfoRecItemModel } from '../../../models/sl-loan-bill-escrow-info-record-item.model';
import { ANALYZE_FOR_ENTRY_COMPONENTS } from '@angular/core';
import { SLLnBilEscrwPmtBalInfoRecItem } from '../../../models/sl-loan-bill-escrow-pmt-bal-info-record-item.model';

let component: EscrowDetailsComponent;
let service: EscrowgridcoldefService;

  const escrowActionsMock = {
    getEscrow: jest.fn(),
    saveEscrow:jest.fn(),
    updateEscrowDetails:jest.fn(),
    updateEscrowBalance:jest.fn()
  };
  const billActionsMock = {
    updateBillInfoEscrowDetails:jest.fn(),
    updateBillInfoEscrowModel:jest.fn()
  };
  const escrowSelectorMock ={
    selectEscrowDetails:jest.fn(),
  };
  const escrowGridDefMock = {
    readonlyColumns:jest.fn(),
    default:jest.fn(),
    defaultEditableScreen:jest.fn(),
    editableColumns:jest.fn(),
    gridOptions:{
      stopEditingWhenCellsLoseFocus:true,
      singleClickEdit : true,
      rowHeight:2,
      readOnlyEdit:true
    }
  };
  const router = {
    getCurrentNavigation:jest.fn(),
    navigate:jest.fn()
  };
  const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(() =>({
      subscribe:jest.fn(),
    })),
  };
describe('EscrowComponent', () => {
  beforeEach(() => {
    component = new EscrowDetailsComponent(storeMock as any,escrowGridDefMock as any,router as any);
    component.escrowActions = escrowActionsMock as any;
    component.escrowSelector = escrowSelectorMock as any;
    component.billInfoActions = billActionsMock as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

    it('data should be fetched on oninit', () => {
    component.ngOnInit();
    const actualValue = component.gridOptions;
    const expectedValue = escrowGridDefMock.gridOptions;
    expect(actualValue).toEqual(expectedValue);
    });
    it('screen type should set when passing the page type', ()=>{
     component.pageType = 'bill';
     expect(component.screenType).toBe('bill');
    });
    it('ngOnChanges() method should be execute when the escrowPageMode is inquiry', () => {
      const changes = {
        escrowPageMode : PageMode.Inquiry
      } as any;
      component.escrowPageMode = PageMode.Inquiry;
      component.defaultColDef = escrowGridDefMock.default as any;
      component.columnDefs = escrowGridDefMock.readonlyColumns as any;
      component.gridOptions = {
        stopEditingWhenCellsLoseFocus:true,
        singleClickEdit : true,
        rowHeight:component.rowHeight,
        readOnlyEdit:true,
        api: {
          stopEditing:jest.fn()
        }
      } as any;
      component.ngOnChanges(changes);
      const expectedValue = PageMode.Inquiry;
      const escrowColDef = escrowGridDefMock.default as any;
      const escrowReadOnly = escrowGridDefMock.readonlyColumns as any;
      expect(component.escrowPageMode).toStrictEqual(expectedValue);
      expect(component.defaultColDef).toStrictEqual(escrowColDef);
      expect(component.columnDefs).toStrictEqual(escrowReadOnly);
    });
    it('ngOnChanges() method should be execute when the pagemode is the edit', () => {
      const changes = {
        escrowPageMode:PageMode.Edit
      } as any;
      component.escrowPageMode = PageMode.Edit;
      component.defaultColDef = escrowGridDefMock.defaultEditableScreen as any;
      component.columnDefs = escrowGridDefMock.editableColumns as any;
      component.rowHeight = 30;
      component.gridOptions = {
        stopEditingWhenCellsLoseFocus:true,
        singleClickEdit : true,
        rowHeight:component.rowHeight,
        readOnlyEdit:true
      };
      component.ngOnChanges(changes);
      const expectedValue = PageMode.Edit;
      const escrowColDef = escrowGridDefMock.defaultEditableScreen as any;
      const escrowEditOnly = escrowGridDefMock.editableColumns as any;
      expect(component.escrowPageMode).toStrictEqual(expectedValue);
      expect(component.defaultColDef).toStrictEqual(escrowColDef);
      expect(component.columnDefs).toStrictEqual(escrowEditOnly);
    });
    it('ngonChanges() method should be execute escrow data', ()=>{
       const changes = {
        escrowData:{
          escrowInfo:{
            nonEscrwPmt:767,
            nonEscrwPmtRem:565
          }
        }
       } as any;
       component.escrowData = changes.escrowData;
       component.ngOnChanges(changes);
       const expectedValue = changes.escrowData;
       const nonEscrwPmt = changes.escrowData.escrowInfo.nonEscrwPmt;
       const nonEscrwPmtRem = changes.escrowData.escrowInfo.nonEscrwPmtRem;
       expect(component.escrowDetails).toEqual(expectedValue);
       expect(component.nonEscrwPmt).toEqual(nonEscrwPmt);
       expect(component.nonEscrwPmtRem).toEqual(nonEscrwPmtRem);
    });
    it('onGridReady() method should be execute', () => {
      const event: GridReadyEvent = {} as any;
      component.onGridReady(event);
      component.gridApi = event.api;
      const actualValue = component.gridApi;
      const expectedValue = event.api;
      expect(actualValue).toEqual(expectedValue);
    });
    it('onGridSizeChanged() method should be execute', () => {
      const event = {
        api:{
          sizeColumnsToFit:jest.fn()
        }
      } as any;
      component.onGridSizeChanged(event);
      const actualValue = event.api.sizeColumnsToFit;
      expect(actualValue).toBeCalled();
    });
    it('onCellEditRequest() method screen type escrow should be execute', () =>{
      const event = {
        newValue:1,
        oldValue:0,
        data:{
          balFldAff: 1,
          escrwPmtAmt: 1,
          escrwPmtAmtRem: 47761,
          escrwPmtBalDesc: ''
        },
        colDef:{
          field:'escrwPmtAmt'
        },
        value:566
      } as any;
      component.screenType = BillFeeModulesEnum.escrow;
      component.onCellEditRequest(event);
      const cellModifiedData = {
        uniqueRowIdentifier: event.data.balFldAff,
        oldData: event.oldValue,
        newData: event.newValue,
        oldRowData: event.data,
        newRowData: event.data,
        field: event.colDef.field,
      } as any;
      const expectedValue = BillFeeModulesEnum.escrow;
      expect(component.screenType).toEqual(expectedValue);
      expect(escrowActionsMock.updateEscrowBalance).toBeCalledWith({cellModifiedData: cellModifiedData});
      expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
      expect(escrowActionsMock.updateEscrowBalance).toHaveBeenCalledTimes(1);
    });
    it('onCellEditRequest() method screen type bill escrow should be execute', () =>{
      const event = {
        newValue:1,
        oldValue:0,
        data:{
          balFldAff: 1,
          escrwPmtAmt: 1,
          escrwPmtAmtRem: 47761,
          escrwPmtBalDesc: ''
        },
        colDef:{
          field:'escrwPmtAmt'
        },
        value:566
      } as any;
      component.screenType = BillFeeModulesEnum.billsEscrow;
      component.billDueDt = escrowMockData.lnBilEscrwInfoRec.billDt;
      component.onCellEditRequest(event);
      const cellModifiedData = {
        uniqueRowIdentifier: event.data.balFldAff,
        oldData: event.oldValue,
        newData: event.newValue,
        oldRowData: event.data,
        newRowData: event.data,
        field: event.colDef.field,
      } as any;
      const expectedValue = BillFeeModulesEnum.billsEscrow;
      expect(component.screenType).toEqual(expectedValue);
      expect(billActionsMock.updateBillInfoEscrowModel).toBeCalledWith({updateBillInfoEscrowModel: cellModifiedData,billDueDt:escrowMockData.lnBilEscrwInfoRec.billDt});
      // expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
      expect(billActionsMock.updateBillInfoEscrowModel).toHaveBeenCalledTimes(1);
    });
    it('onFirstDataRendered() method should be execute', () => {
      const params = {
        columnApi:{
          getAllColumns:jest.fn(()=>({
            forEach: jest.fn(column=> column.colId)
          })),
          autoSizeColumns:jest.fn(),
        }
      } as any;
      component.onFirstDataRendered(params);
      const actualValue = params.columnApi.getAllColumns;
      expect(actualValue).toBeCalled();
    });
    it('nonEscrwPmtUpdate() method should be execute', () => {
      const value = {} as any;
      component.nonEscrwPmtUpdate(value);
      const escrowInfo = {
            'nonEscrwPmt': 48611.00,
            'nonEscrwPmtRem': 47761.00
      };
      component.nonEscrwPmt = escrowInfo.nonEscrwPmt as any;
      component.nonEscrwPmtRem = escrowInfo.nonEscrwPmtRem as any;
      component.updateEscorwInfo(escrowInfo);
      const expectedValue: SLLnBilEscrwInfoRecItemModel = escrowMockData.lnBilEscrwInfoRec.escrowInfo;
      expect(escrowInfo).toEqual(expectedValue);
    });
    it('updateEscorwInfo() if method should be execute', () => {
      const event = escrowMockData.lnBilEscrwInfoRec.escrowInfo as any;
      component.screenType = BillFeeModulesEnum.escrow;
      component.updateEscorwInfo(event);
      expect(escrowActionsMock.updateEscrowDetails).toBeCalledWith({updateEscrowDetails:event});
      expect(storeMock.dispatch).toHaveBeenCalledTimes(3);
      expect(escrowActionsMock.updateEscrowDetails).toHaveBeenCalledTimes(1);
    });
    it('updateEscorwInfo() else method should be execute', () => {
      const escrowInfo = {updateBillEscrowDetails: {
        nonEscrwPmt: 48611, nonEscrwPmtRem: 47761}
      };
      component.billDueDt = '2022-01-31';
      component.screenType = BillFeeModulesEnum.billsEscrow;
      component.updateEscorwInfo(escrowInfo.updateBillEscrowDetails);
      const expectedValue = BillFeeModulesEnum.billsEscrow;
      expect(component.screenType).toEqual(expectedValue);
      expect(billActionsMock.updateBillInfoEscrowDetails).toBeCalledWith({updateBillEscrowDetails:escrowInfo.updateBillEscrowDetails, billDueDt:component.billDueDt});
      // expect(storeMock.dispatch).toHaveBeenCalledTimes(4);
      expect(billActionsMock.updateBillInfoEscrowDetails).toHaveBeenCalledTimes(1);
    });
    it('loadBillDetailsForDueDate() method should be execute', () => {
      component.escrowDetails = escrowMockData.lnBilEscrwInfoRec;
      component.loadBillDetailsForDueDate();
      expect(router.navigate).toBeCalledTimes(1);
    });
});
