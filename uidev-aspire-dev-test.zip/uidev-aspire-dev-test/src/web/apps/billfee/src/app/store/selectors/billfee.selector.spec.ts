import { PageMode } from '../../models/bill-fee-enums';
import * as BillFeeSelector from './billfee.selector';
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
import {SplitterViewEnum} from '@uid/uid-primary-detail';


describe('Fee List Selector Test',()=> {

    // Bill list selector test
    it('selectBillFeeList selector test',()=> {
        const billfeeListMock = {
            loanBillFeeResponse: {lnFeeInfoRec:[{this: 'test data 1'},{this: 'test data 2'}]}
        };
        const selector = BillFeeSelector.selectLoanFee.projector(billfeeListMock);
        expect(selector).toEqual(billfeeListMock.loanBillFeeResponse.lnFeeInfoRec);
    });

     // Bill list selector test
     it('selectShadowFees selector test',()=> {
        const billfeeListMock = {
            loanBillFeeResponse: {lnFeeInfoRec:[{this: 'test data 1'},{this: 'test data 2'}]}
        };
        const selector = BillFeeSelector.selectShadowFee.projector(billfeeListMock);
        expect(selector).toEqual(billfeeListMock.loanBillFeeResponse.lnFeeInfoRec);
    });

     it('selectupdatedFees selector test',()=> {
        const billfeeListMock = {
            updatedLoanFeeResponse:{
            lnFeeInfoRecArray: {lnFeeInfoRec:[{this: 'test data 1'},{this: 'test data 2'}]}
            }
        };
        const selector = BillFeeSelector.selectUpdatedFees.projector(billfeeListMock);
        expect(selector).toEqual(billfeeListMock.updatedLoanFeeResponse.lnFeeInfoRecArray.lnFeeInfoRec);
    });

    it('selectCurrentLoanFee selector test', () => {
        const currentRecord = {'lnFeeId': 2};
        const selector = BillFeeSelector.selectCurrentLoanFeeRecord.projector(currentRecord);
         expect(selector).toMatchSnapshot();
    });

    it('selectCurrentLoanFee selector test format dates to "MM/dd/yyyy" format', () => {
        const billfeeListMock = {
            loanBillFeeResponse: {lnFeeInfoRec:[{this: 'test data 1'},{this: 'test data 2'}]}
        };
        const selectLoanFeeRecord = {
             lnFeeLastPmtDt: '2021-01-07', lnFeeAssmntDt: '2022-05-31', lnPaidDt: '2022-01-01',
             lnBillDt: '2022-02-02', lnFeeWavDt: '2022-06-02'};
        const formattedRecord = {
             lnFeeLastPmtDt: '01/07/2021', lnFeeAssmntDt: '05/31/2022', lnPaidDt: '01/01/2022',
             lnBillDt: '02/02/2022', 'lnFeeWavDt': '06/02/2022'};
        const result = BillFeeSelector.selectFeeRecord.projector(billfeeListMock, selectLoanFeeRecord);
        expect(result).toEqual(formattedRecord);
    });

    it('selectModifiedFee selector test',()=> {
        const billfeeListMock = {
            updatedLoanFeeResponse:{
            lnFeeInfoRecArray: {lnFeeInfoRec:[{this: 'test data 1'},{this: 'test data 2'}]}
            }
        };
        const selector = BillFeeSelector.selectModifiedFeeResponse.projector(billfeeListMock);
        expect(selector).toEqual(billfeeListMock.updatedLoanFeeResponse);
    });

     // Bill list selector test
     it('selectPageMode selector',()=> {
        const pageModeMock = {pageMode: PageMode.Inquiry};
        const selector = BillFeeSelector.selectPageMode.projector(pageModeMock);
        expect(selector).toEqual(pageModeMock.pageMode);
    });


    it('selectShowACHAutoReturn should project test array', () => {
        const state = { loanBillFeeResponse: { showACHAutoReturn: true} };
        const result = BillFeeSelector.selectShowACHAutoReturn.projector(state);
        expect(result).toBe(true);
      });

      it('select formstate', () => {
        const formStateMock = {
          accountType: 'D',
          editMode: PageMode.Inquiry,
          showACHAutoReturn: true,
          width: 'full'
        };
        const accountType =  'D';
        const editMode    =  PageMode.Inquiry;
        const splitView  = SplitterViewEnum.splitView;
        const showACHAutoReturn = true;
        const selector = BillFeeSelector.selectFormState.projector(accountType, editMode, showACHAutoReturn, splitView);
        expect(selector).toEqual(formStateMock);
      });

      it('select formstate', () => {
        const formStateMock = {
          accountType: 'D',
          editMode: PageMode.Inquiry,
          showACHAutoReturn: true,
          width: 'medium'
        };
        const accountType =  'D';
        const editMode    =  PageMode.Inquiry;
        const splitView  = SplitterViewEnum.detailView;
        const showACHAutoReturn = true;
        const selector = BillFeeSelector.selectFormState.projector(accountType, editMode, showACHAutoReturn, splitView);
        expect(selector).toEqual(formStateMock);
      });

});
