import { SearchMessageResponseHeaderModel } from '@uid/uid-models';
import { LnBilSrchRecModel } from './loan-bill-search-record.model';

export interface LnBilSrchResponseModel{
    srchMsgRsHdr:    SearchMessageResponseHeaderModel;
    acctId:          string;
    acctType:        string;
    lnBilSrchRec:    LnBilSrchRecModel[];
};
