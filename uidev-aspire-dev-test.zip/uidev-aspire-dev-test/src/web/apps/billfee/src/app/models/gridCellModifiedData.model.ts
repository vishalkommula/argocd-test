
//TODO: Remove this model and use the one in common
export interface GridCellModifiedData <T>{
    uniqueRowIdentifier: number;
    oldData: string;
    newData: string;
    oldRowData: T;
    newRowData: T;
    field: string;
}
