import { createReducer, on } from '@ngrx/store';
import { LoanBillFeeResponseModel } from '../../models/loan-bill-fee-response.model';
import { BillFeeState } from '../states/billfee.state';
import { LnFeeInfoRecModel } from '../../models/loan-fee-info-record.model';
import { LnBilSrchResponseModel } from '../../models/loan-bill-search-response.model';
import { LnBilSrchFilterModel } from '../../models/loan-bill-search-filter.model';
import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';

import * as BillFeeActions from '../actions/billfee.action';
import * as EscrowInfoActions from '../actions/billescrow.action';
import * as BillInfoActions from '../actions/billInfo.action';
import { PageMode } from '../../models/bill-fee-enums';
import { LnFeeModResponse } from '../../models/loan-bill-fee-mod-response.model';

export const initialBillFeeState: BillFeeState = {
  loanBillFeeResponse: {} as LoanBillFeeResponseModel,
  updatedLoanFeeResponse: {} as LnFeeModResponse,
  currentBillFeeRecord: {} as LnFeeInfoRecModel,
  pageMode: PageMode.Inquiry,

  // billinfo state
  loanBillResponse: {} as LnBilSrchResponseModel,
  selectedBillDueDate: '',
  lnBillInfoResponse: [],
  isBillInfoUpdated: false,
  isBillInfoDeleted: false,
  filterRecordModel: {} as LnBilSrchFilterModel,

  // escrow state
  escrowDetailsResponse: {} as LnBilEscrwSrchResponse,
  escrowDetailsEditResponse: {} as LnBilEscrwSrchResponse,
  selectedModule: 'Bills'
};

export const billFeeReducer = createReducer(
  initialBillFeeState,

  // reducer for loanfee response success
  on(
    BillFeeActions.getLoanFeeSuccess,
    (state, action): BillFeeState => ({
      ...state,
      loanBillFeeResponse: action.response,
      selectedModule: state.pageMode === PageMode.Add ? 'Bills' : 'Fees',
    })
  ),

  // reducer to select a record
  on(
    BillFeeActions.selectRecord,
    (state, action): BillFeeState => ({
      ...state,
      currentBillFeeRecord: action.currentRecord,
    })
  ),

  // reducer to set inquiry mode
  on(
    BillFeeActions.setPageToInquiryMode,
    (state): BillFeeState => ({
      ...state,
      pageMode: PageMode.Inquiry,
    })
  ),

  // reducer to set edit mode
  on(
    BillFeeActions.setPageToEditMode,
    (state): BillFeeState => ({
      ...state,
      pageMode: PageMode.Edit,
    })
  ),

  //  reducer to get shadow fees
  on(
    BillFeeActions.getShadowFees,
    (state): BillFeeState => ({
      ...state,
      loanBillFeeResponse: {} as LoanBillFeeResponseModel,
      pageMode: PageMode.Inquiry
    })
  ),

  // reducer for shadowfee success
  on(
    BillFeeActions.getShadowFeeSuccess,
    (state, action): BillFeeState => ({
      ...state,
      loanBillFeeResponse: action.response,
    })
  ),

  // reducer for form cancel action
  on(
    BillFeeActions.cancelModifiedFee,
    (state): BillFeeState => ({
      ...state,
      pageMode: PageMode.Inquiry,
    //  canOverride: false
    })
  ),

  // reducer for formly model onChange event
  on(
    BillFeeActions.updateLoanFeeFormModel,
    (state, action): BillFeeState => ({
      ...state,
      currentBillFeeRecord: action.updateFeeFormModel
    })
  ),

  // reducer for form save action
  on(BillFeeActions.saveModifiedFeeSuccess, (state, action): BillFeeState => {
    if (action.response.faultRecInfoArray.length === 0) {
      return {
        ...state,
        updatedLoanFeeResponse: action.response,
        pageMode: PageMode.Inquiry,
      };
    } else {
      return {
        ...state,
        pageMode: PageMode.Edit,
        updatedLoanFeeResponse: action.response
      };
    }
  }),

  // Bill Info
  // reducer for bill list success response
  on(
    BillInfoActions.getBillListSuccess,
    (state, action): BillFeeState => ({
      ...state,
      loanBillResponse: action.response,
      selectedBillDueDate: '',
      lnBillInfoResponse: [],
      isBillInfoUpdated: false,
      isBillInfoDeleted: false,
      selectedModule: 'Bills',
      filterRecordModel: {} as LnBilSrchFilterModel,
    })
  ),

  // reducer for update the selected bill due date
  on(
    BillInfoActions.updateSelectedBillDueDate,
    (state, action): BillFeeState => ({
      ...state,
      selectedBillDueDate: action.dueDate,
      pageMode: PageMode.Inquiry,
    })
  ),

  // reducer for updating filter record model
  on(
    BillInfoActions.setBillListFilter,
    (state, action): BillFeeState => ({
      ...state,
      filterRecordModel: action.filterRecordModel,
    })
  ),

  // reducer for clearing filter record model
  on(
    BillInfoActions.clearBillListFilter,
    (state): BillFeeState => ({
      ...state,
      filterRecordModel: {} as LnBilSrchFilterModel,
    })
  ),
  // Reducer for bill details success.
  // Since there is no deep copy and frequently data is updating in store, there should be a api call to update
  // the particular model in array of lnBillInfoResponse.
  on(BillInfoActions.getBillDetailsSuccess, (state, action): BillFeeState => {
    const lnBilInfoRecIndex = state.lnBillInfoResponse.
    findIndex((x) => x.lnbilInfoRec.bilDueDt === action.loanBillInfoResponse.lnbilInfoRec.bilDueDt);
    if(lnBilInfoRecIndex>-1){
      return {
        ...state,
        pageMode: PageMode.Inquiry,
        isBillInfoUpdated: false,
        selectedBillDueDate:action.loanBillInfoResponse.lnbilInfoRec.bilDueDt ?? '',
        lnBillInfoResponse: [
          ...state.lnBillInfoResponse.slice(0, lnBilInfoRecIndex),
         action.loanBillInfoResponse,
          ...state.lnBillInfoResponse.slice(lnBilInfoRecIndex + 1),
        ],
      };
    }else{
    return {
      ...state,
      pageMode: PageMode.Inquiry,
      isBillInfoUpdated: false,
      selectedBillDueDate:action.loanBillInfoResponse.lnbilInfoRec.bilDueDt ?? '',
      lnBillInfoResponse: [...state.lnBillInfoResponse, action.loanBillInfoResponse],
    };
  }
  }),

  // reducer for bill details error
  on(
    BillInfoActions.getBillDetailsError,
    (state): BillFeeState => ({
      ...state,
      loanBillResponse: state.loanBillResponse,
    })
  ),

  // Reducer for update bill details success.
  on(BillInfoActions.updateBillDetailsSuccess, (state, action): BillFeeState => {
    const lnBilInfoRecIndex = state.lnBillInfoResponse.
    findIndex((x) => x.lnbilInfoRec.bilDueDt === action.billModResponse.lnBilInfoRec.bilDueDt);
    if(action.billModResponse.faultRecInfoArray!=null && action.billModResponse.faultRecInfoArray.length>0){
      return {
        ...state,
        pageMode: PageMode.Inquiry,
        lnBillInfoResponse: [
          ...state.lnBillInfoResponse.slice(0, lnBilInfoRecIndex),
          {
            ...state.lnBillInfoResponse[lnBilInfoRecIndex],
            faultRecInfoArray:action.billModResponse.faultRecInfoArray
          },
          ...state.lnBillInfoResponse.slice(lnBilInfoRecIndex + 1),
        ],
      };
    }else{
      return {
        ...state,
        pageMode: PageMode.Inquiry,
      };
    }
  }),

  // Reducer for update bill details error.
  on(
    BillInfoActions.updateBillDetailsError,
    (state): BillFeeState => ({
      ...state,
    })
  ),

  // Reducer for add bill details success - logic change.
  on(BillInfoActions.addBillDetailsSuccess, (state, action): BillFeeState => ({
          ...state,
          pageMode: PageMode.Inquiry,
  })),

  // Reducer for add bill details error.
  on(
    BillInfoActions.addBillDetailsError,
    (state, action): BillFeeState => ({
      ...state,
    })
  ),

  // Reducer for delete bill details success.
  on(BillInfoActions.deleteBillDetailsSuccess, (state, action): BillFeeState => {
    if (action.deleteResponse.rsStat) {
      return {
        ...state,
        isBillInfoDeleted: true,
      };
    } else {
      return {
        ...state,
      //  faultRecInfoArray: action.deleteResponse.faultRecInfoArray,
      };
    }
  }),

  // Reducer for delete bill details error.
  on(
    BillInfoActions.deleteBillDetailsError,
    (state, action): BillFeeState => ({
      ...state,
    })
  ),

  // Reducer for bill detail click action.
  on(
    BillInfoActions.changePageMode,
    (state, action): BillFeeState => ({
          ...state,
          pageMode: action.clickAction
        })
  ),

  // change override flog status
  on(
    BillInfoActions.blockOverrideDialog,
    (state, action): BillFeeState => ({
      ...state,
     // showoverridedialogbox: action.blockOverrideDialog,
     // faultRecInfoArray: [],
    })
  ),

  // reducer for update attachedfee.
  on(BillInfoActions.updateAttachedFee, (state, action): BillFeeState => {
    const lnBilInfoRecIndex = state.lnBillInfoResponse.findIndex((x) => x.lnbilInfoRec.bilDueDt === action.billDueDt);
    if (lnBilInfoRecIndex !== -1) {
      return {
        ...state,
        lnBillInfoResponse: [
          ...state.lnBillInfoResponse.slice(0, lnBilInfoRecIndex),
          {
            ...state.lnBillInfoResponse[lnBilInfoRecIndex],
            lnbilInfoRec:{
              ...state.lnBillInfoResponse[lnBilInfoRecIndex].lnbilInfoRec,
              lnFeeInfoRec: state.lnBillInfoResponse[lnBilInfoRecIndex].lnbilInfoRec.lnFeeInfoRec?.map((feeData) => (feeData.lnFeeId === action.cellModifiedData.newRowData.lnFeeId ? action.cellModifiedData.newRowData : feeData)),
            }
          },
          ...state.lnBillInfoResponse.slice(lnBilInfoRecIndex + 1),
        ],
      };
    } else {
      return {
        ...state,
      };
    }
  }),

  // reducer for update escrow.
  on(BillInfoActions.updateBillInfoEscrowModel, (state, action): BillFeeState => {
    const lnBilInfoRecIndex = state.lnBillInfoResponse.findIndex((x) => x.lnbilInfoRec.bilDueDt === action.billDueDt);
    if (lnBilInfoRecIndex !== -1) {
      return {
        ...state,
        lnBillInfoResponse: state.lnBillInfoResponse.map((x) =>
          x.lnbilInfoRec.bilDueDt === action.billDueDt
            ? {
                ...x,
                lnbilInfoRec:{
                  ...x.lnbilInfoRec,
                  lnBilEscrwInfoRec: {
                    billDt: x.lnbilInfoRec.lnBilEscrwInfoRec?.billDt !== undefined ? x.lnbilInfoRec.lnBilEscrwInfoRec.billDt : '',
                    override: x.lnbilInfoRec.lnBilEscrwInfoRec?.override !== undefined ? x.lnbilInfoRec.lnBilEscrwInfoRec.override : false,
                    lnBilEscrowId: x.lnbilInfoRec.lnBilEscrwInfoRec?.lnBilEscrowId ? x.lnbilInfoRec.lnBilEscrwInfoRec?.lnBilEscrowId : '',
                    escrowInfo: x.lnbilInfoRec.lnBilEscrwInfoRec?.escrowInfo !== undefined ? x.lnbilInfoRec.lnBilEscrwInfoRec?.escrowInfo : {},
                    escrowBalances:
                      x.lnbilInfoRec.lnBilEscrwInfoRec?.escrowBalances !== undefined
                        ? x.lnbilInfoRec.lnBilEscrwInfoRec?.escrowBalances?.map((escrow) => (escrow.balFldAff === action.updateBillInfoEscrowModel.uniqueRowIdentifier ? action.updateBillInfoEscrowModel.newRowData : escrow))
                        : [],
                  }
                }
              }
            : x
        ),
      };
    } else {
      return {
        ...state,
      };
    }
  }),

  // reducer for update billinfo.
  on(BillInfoActions.updateBillInfoModel, (state, action): BillFeeState => {
    const lnBilInfoRecIndex = state.lnBillInfoResponse.findIndex((x) => x.lnbilInfoRec.bilDueDt === action.updateBillInfoModel.bilDueDt);
    if (lnBilInfoRecIndex !== -1) {
      return {
        ...state,
        lnBillInfoResponse: [
          ...state.lnBillInfoResponse.slice(0, lnBilInfoRecIndex),
          {
            ...state.lnBillInfoResponse[lnBilInfoRecIndex],
            lnbilInfoRec:action.updateBillInfoModel
          },
          ...state.lnBillInfoResponse.slice(lnBilInfoRecIndex + 1),
        ],
      };
    } else {
      return {
        ...state,
      };
    }
  }),

  // reducer for update escrow.
  on(BillInfoActions.updateBillInfoEscrowDetails, (state, action): BillFeeState => {
    const lnBilInfoRecIndex = state.lnBillInfoResponse.findIndex((x) => x.lnbilInfoRec.bilDueDt === action.billDueDt);
    if (lnBilInfoRecIndex !== -1) {
      return {
        ...state,
        lnBillInfoResponse: state.lnBillInfoResponse.map((x) =>
          x.lnbilInfoRec.bilDueDt === action.billDueDt
            ? {
                ...x,
                lnbilInfoRec:{
                  ...x.lnbilInfoRec,
                  lnBilEscrwInfoRec: {
                    billDt: x.lnbilInfoRec.lnBilEscrwInfoRec?.billDt !== undefined ? x.lnbilInfoRec.lnBilEscrwInfoRec.billDt : '',
                    override: x.lnbilInfoRec.lnBilEscrwInfoRec?.override !== undefined ? x.lnbilInfoRec.lnBilEscrwInfoRec.override : false,
                    lnBilEscrowId: x.lnbilInfoRec.lnBilEscrwInfoRec?.lnBilEscrowId ? x.lnbilInfoRec.lnBilEscrwInfoRec?.lnBilEscrowId : '',
                    escrowBalances: x.lnbilInfoRec.lnBilEscrwInfoRec?.escrowBalances ? x.lnbilInfoRec.lnBilEscrwInfoRec?.escrowBalances : [],
                    escrowInfo: action.updateBillEscrowDetails,
                  }
                }
              }
            : x
        ),
      };
    } else {
      return {
        ...state,
      };
    }
  }),

  // Bill Escrow

  // Reducer for escrow details initial entry
  // on(
  //   EscrowInfoActions.getEscrow,
  //   (state): BillFeeState => ({
  //     ...state,
  //     escrowDetailsResponse: {} as LnBilEscrwSrchResponse,
  //   })),

  // Reducer for escrow details success response
  on(
    EscrowInfoActions.getEscrowSuccess,
    (state, action): BillFeeState => ({
      ...state,
      escrowDetailsResponse: action.response,
      selectedModule: 'Escrow',
    })
  ),

  // Reducer for escrow details edit response
  on(
    EscrowInfoActions.saveEscrowSuccess,
    (state, action): BillFeeState => ({
      ...state,
      escrowDetailsEditResponse: action.response,
    })
  ),

  // on(EscrowInfoActions.saveEscrowSuccess, (state, action): BillFeeState => {
  //   if (action.response.rsStat) {
  //     return {
  //       ...state,
  //     };
  //   } else if (!action.response.rsStat && action.response.canOverride) {
  //     return {
  //       ...state,
  //       faultRecInfoArray: action.response.faultRecInfoArray,
  //       showoverridedialogbox: true,
  //     };
  //   } else {
  //     return {
  //       ...state,
  //       faultRecInfoArray: action.response.faultRecInfoArray,
  //     };
  //   }
  // }),

  //    override cancel popup
  // on(
  //   EscrowInfoActions.cancelOverrideDialogBox,
  //   (state, action): BillFeeState => ({
  //     ...state,
  //    // showoverridedialogbox: action.cancelOverrideBox,
  //    // faultRecInfoArray: [],
  //   })
  // ),

  // update escrow balances
  on(
    EscrowInfoActions.updateEscrowBalance,
    (state, action): BillFeeState => ({
      ...state,
      escrowDetailsResponse: {
        srchMsgRsHdr: state.escrowDetailsResponse.srchMsgRsHdr,
        acctId: state.escrowDetailsResponse.acctId,
        acctType: state.escrowDetailsResponse.acctType,
        canOverride: state.escrowDetailsResponse.canOverride,
        faultRecInfoArray: state.escrowDetailsResponse.faultRecInfoArray,
        rsStat: state.escrowDetailsResponse.rsStat,
        lnBilEscrwInfoRec: {
          billDt: state.escrowDetailsResponse.lnBilEscrwInfoRec.billDt,
          override: state.escrowDetailsResponse.lnBilEscrwInfoRec.override,
          lnBilEscrowId: state.escrowDetailsResponse.lnBilEscrwInfoRec.lnBilEscrowId,
          escrowInfo: state.escrowDetailsResponse.lnBilEscrwInfoRec.escrowInfo,
          escrowBalances: state.escrowDetailsResponse.lnBilEscrwInfoRec.escrowBalances.map((escrow) => (escrow.balFldAff === action.cellModifiedData.uniqueRowIdentifier ? action.cellModifiedData.newRowData : escrow)),
        },
      },
    })
  ),

  // update escrow balances
  on(
    EscrowInfoActions.updateEscrowDetails,
    (state, action): BillFeeState => ({
      ...state,
      escrowDetailsResponse: {
        srchMsgRsHdr: state.escrowDetailsResponse.srchMsgRsHdr,
        acctId: state.escrowDetailsResponse.acctId,
        acctType: state.escrowDetailsResponse.acctType,
        canOverride: state.escrowDetailsResponse.canOverride,
        faultRecInfoArray: state.escrowDetailsResponse.faultRecInfoArray,
        rsStat: state.escrowDetailsResponse.rsStat,
        lnBilEscrwInfoRec: {
          billDt: state.escrowDetailsResponse.lnBilEscrwInfoRec.billDt,
          override: state.escrowDetailsResponse.lnBilEscrwInfoRec.override,
          lnBilEscrowId: state.escrowDetailsResponse.lnBilEscrwInfoRec.lnBilEscrowId,
          escrowInfo: action.updateEscrowDetails,
          escrowBalances: state.escrowDetailsResponse.lnBilEscrwInfoRec.escrowBalances,
        },
      },
    })
  )
);
