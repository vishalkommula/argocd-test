import * as EscrowListSelector from './billescrow.selector';
import escrowDetailsEditResponse from '../../mock-data/loanBillescrowResponse.mock.json';
describe('Escrow List Selector Test',()=> {

    // Escrow list selector test
    it('selectBillList selector test',()=> {
        const escrowListMock = {escrowDetailsResponse: {lnBilEscrwInfoRec:[{this: 'test data 1'},{this: 'test data 2'}]}};
        const selector = EscrowListSelector.selectEscrowDetails.projector(escrowListMock);
        expect(selector).toEqual(escrowListMock.escrowDetailsResponse.lnBilEscrwInfoRec);
    });
    it('selectBillList selector test',()=> {
        const escrowListMock = {escrowDetailsEditResponse:escrowDetailsEditResponse};
        const selector = EscrowListSelector.selectEscrowEditDetails.projector(escrowListMock);
        expect(selector).toEqual(escrowListMock.escrowDetailsEditResponse);
    });
});
