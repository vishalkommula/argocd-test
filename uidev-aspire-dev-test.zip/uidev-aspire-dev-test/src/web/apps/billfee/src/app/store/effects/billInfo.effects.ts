import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { DataService } from '../../service/data.service';
import * as BillInfoActions from '../actions/billInfo.action';

@Injectable()
export class BillInfoEffects{

    constructor(private dataservice: DataService, private actions$: Actions){}

    // get bills from service
        loadBillListResponse$ = createEffect(() => this.actions$.pipe(
                    ofType(BillInfoActions.getBillList),
                    switchMap((action) =>
                        this.dataservice
                            .getBills(action.request)
                            .pipe(
                                map((response) => BillInfoActions.getBillListSuccess({response})),
                                catchError((error) =>
                                    of(BillInfoActions.getBillListFailure({error}))
                                )
                            )
                    )
                )
        );
        // Get bills from service
        // eslint-disable-next-line arrow-body-style
        loadbillinfo$ = createEffect(() => {
            return this.actions$.pipe(
                       ofType(BillInfoActions.getBillDetails),
                       switchMap((action) =>
                           this.dataservice
                               .getBillDetailsbyBillduedt(action.loanBillInfoRequest)
                               .pipe(
                                   map((response) => BillInfoActions.getBillDetailsSuccess({loanBillInfoResponse:response })),
                                   catchError((error) =>
                                       of(BillInfoActions.getBillDetailsError({error}))
                                   )
                               )
                       )
                );
           }
        );

        // update bills from service
        // eslint-disable-next-line arrow-body-style
        updatebillinfo$ = createEffect(() => {
            return this.actions$.pipe(
                       ofType(BillInfoActions.updateBillDetails),
                       switchMap((action) =>
                           this.dataservice
                               .updatebilldetails(action.billModRequest)
                               .pipe(
                                   map((response) => BillInfoActions.updateBillDetailsSuccess({billModResponse:response})),
                                   catchError((error) =>
                                       of(BillInfoActions.updateBillDetailsError({billModResponse:false}))
                                   )
                               )
                       )
                );
           }
        );

        // add bills from service
        // eslint-disable-next-line arrow-body-style
        addbillinfo$ = createEffect(() => {
            return this.actions$.pipe(
                       ofType(BillInfoActions.addBillDetails),
                       switchMap((action) =>
                           this.dataservice
                               .addbilldetails(action.billAddRequest)
                               .pipe(
                                   map((response) => BillInfoActions.addBillDetailsSuccess({billAddResponse:response })),
                                   catchError((error) =>
                                       of(BillInfoActions.addBillDetailsError({billAddResponse:false}))
                                   )
                               )
                       )
                );
           }
        );

                // add bills from service
        // eslint-disable-next-line arrow-body-style
        deletebilldetail$ = createEffect(() => {
            return this.actions$.pipe(
                       ofType(BillInfoActions.deleteBillDetails),
                       switchMap((action) =>
                           this.dataservice
                               .deletebilldetails(action.deleteRequest)
                               .pipe(
                                   map((response) => BillInfoActions.deleteBillDetailsSuccess({deleteResponse:response })),
                                   catchError((error) =>
                                       of(BillInfoActions.deleteBillDetailsError({deleteResponse:false}))
                                   )
                               )
                       )
                );
           }
        );
}
