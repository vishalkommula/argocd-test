import { Component, OnInit } from '@angular/core';
import { FieldWrapper } from '@ngx-formly/core';

@Component({
  selector: 'uid-form-display-without-rui-form',
  templateUrl: './form-display-without-rui-form.component.html',
  styleUrls: ['./form-display-without-rui-form.component.scss']
})
export class FormDisplayWithoutRuiFormComponent extends FieldWrapper {
  
}
