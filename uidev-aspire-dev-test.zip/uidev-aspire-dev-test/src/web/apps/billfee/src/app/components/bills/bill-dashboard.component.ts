import { Component, OnInit, OnDestroy } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, Subscription } from 'rxjs';
import * as BillInfoSelect from '../../store/selectors/billInfo.selector';
import * as BillInfoActions from '../../store/actions/billInfo.action';
import { LnBilInfoRequestModel } from '../../models/loan-bill-inq-request.model';
import { Router } from '@angular/router';
import { PageMode } from '../../models/bill-fee-enums';
import { LnBilInfoResponseModel } from '../../models/loan-bill-info-response.model';


@Component({
  selector: 'uid-bill-dashboard',
  templateUrl: './bill-dashboard.component.html',
  styleUrls: ['./bill-dashboard.component.scss']
})
export class BillDashboardComponent implements OnInit, OnDestroy{

  // get edit or add or view bill screen
  pageMode$: Observable<PageMode>;
  // assign the selector
  billInfoSelector = BillInfoSelect;
  billInfoAction = BillInfoActions;
  // unsaved change dialog enable or disabled variable
  showUnsavedChangesDialog = false;
  availableBillDueDates$: Observable<string[]>;

  allBillDetails: string[] = [];
  // is bill loaded
  isBillsLoaded=false;
  subscriptions: Subscription[] = [];
  selectedBillDueDate= '';
  pageModeEnum = PageMode;
  billDetails$: Observable<LnBilInfoResponseModel | null>;

  constructor(private store: Store, private route: Router) {

    this.pageMode$ = this.store.select(this.billInfoSelector.selectPageMode);

    // get bill info details
    this.billDetails$ = this.store.select(this.billInfoSelector.selectBillInfoByBillDueDt);

    this.availableBillDueDates$ = this.store.select(this.billInfoSelector.selectAvailiableBillDueDates);

    if(this.route.getCurrentNavigation()?.extras.state !== undefined){
      const stateData = this.route.getCurrentNavigation()?.extras.state;
      this.selectedBillDueDate = stateData !== undefined ? stateData['billDueDate'] : '';
    }
  }

  ngOnInit(): void {

    // changed the logic to get only bill due date from store for already existing records for loanbilinfo
    const subselectAvailiableBillDueDates = this.availableBillDueDates$.subscribe((data) => {
      this.allBillDetails = JSON.parse(JSON.stringify(data));
    });

    this.subscriptions.push(subselectAvailiableBillDueDates);
  }

  // get bill info by bill due date
  getBillInfoByBillDueDt(billDate: string) {
    if (billDate) {
      if (this.allBillDetails.findIndex((x) => x === billDate) === -1) {
        const loanbillinforeq: LnBilInfoRequestModel = {
          srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
          acctId: '12',
          acctType: 'A',
          bilDueDt: billDate.toString(),
        };
        this.store.dispatch(this.billInfoAction.getBillDetails({ loanBillInfoRequest: loanbillinforeq }));
      } else {
        this.store.dispatch(this.billInfoAction.updateSelectedBillDueDate({ dueDate: billDate }));
      }
    }else{
        this.store.dispatch(this.billInfoAction.updateSelectedBillDueDate({ dueDate: '' }));
      }
  }

  // bills loaded
  billsloaded(event: boolean){
    this.isBillsLoaded=event;
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((sub) => sub.unsubscribe());
  }
}
