import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EscrowgridcoldefService } from './escrow-details/escrow-grid-coldef.service';

import { EscrowComponent } from './escrow.component';
import escrowMockData from '../../mock-data/loanBillescrowResponse.mock.json';
import escrowMockEditData from '../../mock-data/loanBillescrowEditResponse.mock.json';
import { billFeeValueTypes, PageMode } from '../../models/bill-fee-enums';
jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());

import 'ag-grid-enterprise';
import { Observable, of } from 'rxjs';
import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';
import { LnBilEscrwInfoRecModel } from '../../models/loan-bill-escrow-info-record.model';
import { updateEscrowDetails } from '../../store/actions/billescrow.action';
import { LnBilEscrwEditSrchRequest } from '../../models/loan-bill-escrow-edit-request.model';
import { compose } from '@ngrx/store';

let component: EscrowComponent;
let service: EscrowgridcoldefService;

  const escrowActionsMock = {
    getEscrow: jest.fn(),
    saveEscrow:jest.fn(),
  };
  const escrowSelectorMock ={
    selectEscrowDetails:jest.fn(),
  };
  const router = {
    getCurrentNavigation:jest.fn(),
    navigate:jest.fn()
  };
  const storeMock = {
    dispatch: jest.fn(),
    select: jest.fn(() =>({
      subscribe:jest.fn(),
    })),
  };

describe('EscrowComponent', () => {
  let fixture: ComponentFixture<EscrowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EscrowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    component = new EscrowComponent(storeMock as any,router as any);
    component.escrowActions = escrowActionsMock as any;
    component.escrowSelector = escrowSelectorMock as any;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('data should be fetched on oninit', () => {
    component.ngOnInit();
    expect(escrowActionsMock.getEscrow).toBeCalledWith({request: {} as any});
    expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
    expect(escrowActionsMock.getEscrow).toHaveBeenCalledTimes(1);
  });
  it('enableEditMode() method should be execute', () => {
    component.enableEditMode();
    const actualValue = component.escrowPageMode;
    const expectedValue = PageMode.Edit;
    expect(actualValue).toEqual(expectedValue);
});
it('cancel() method should be execute', () => {
  component.cancelChanges();
  const actualValue = component.cancelDialogBox;
  const expectedValue = true;
  expect(actualValue).toEqual(expectedValue);
});
it('save() method should be execute', () => {
  const responseData = escrowMockEditData;
  const escrowEditDetailsData: Observable<LnBilEscrwSrchResponse> = of(responseData);
  component.escrowEditDetails$ = escrowEditDetailsData;
  const formEscrowDetails: LnBilEscrwInfoRecModel = escrowMockData.lnBilEscrwInfoRec;
  const overWarning = false;
  component.saveChanges(formEscrowDetails,overWarning);
  component.escrowDetails.escrowInfo = escrowMockData.lnBilEscrwInfoRec.escrowInfo;
  component.escrowDetails.escrowBalances = escrowMockData.lnBilEscrwInfoRec.escrowBalances;
  component.escrowDetails.lnBilEscrowId = escrowMockData.lnBilEscrwInfoRec.lnBilEscrowId;
  component.escrowDetails.billDt = escrowMockData.lnBilEscrwInfoRec.billDt;
  const updatedEscrowDetails = {
    srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
    acctId: '12',
    acctType: 'A',
    lnBilEscrwInfoRec: {
      escrowInfo: component.escrowDetails.escrowInfo,
      escrowBalances: component.escrowDetails.escrowBalances,
      lnBilEscrowId: component.escrowDetails.lnBilEscrowId,
      billDt: component.escrowDetails.billDt,
      override: overWarning,
    }
  };
  expect(escrowActionsMock.saveEscrow).toBeCalledWith({updateRecord: updatedEscrowDetails as any});
  expect(component.showOverrideDialogBox).toBeTruthy();
});
it('overridedialogBoxClose() method should be execute', () => {
    const event = {detail: 'Override'};
    const escroMockData =  {
      lnBilEscrwInfoRec:{
        billDt:'2022-01-31',
        escrowInfo:{
          nonEscrwPmt: 48611.00,
          nonEscrwPmtRem: 47761.00
        },
        lnBilEscrowId:1,
        escrowBalances:[
            {
                    balFldAff: 1,
                    escrwPmtBalDesc: '',
                    escrwPmtAmt: 48611,
                    escrwPmtAmtRem: 47761
            },
        ]
    },
    } as any;
    component.escrowDetails = escroMockData.lnBilEscrwInfoRec;
    component.overridedialogBoxClose(event);
    const overWarning = true;
    component.saveChanges(component.escrowDetails, overWarning);
    component.escrowPageMode = PageMode.Inquiry;
    const expectedValue = PageMode.Inquiry;
    expect(component.escrowPageMode).toStrictEqual(expectedValue);
    expect(component.showOverrideDialogBox).toBeFalsy();
});
it('dialogBeforeClose() method should be execute', () => {
  component.dialogBeforeClose();
  const actualValue = component.showDialogBox;
  const expectedValue = false;
  expect(actualValue).toStrictEqual(expectedValue);
});
it('dialogBoxClose() method should be execute', () => {
    const event = {detail: 'Don\'t Save'};
    component.escrowPageMode = PageMode.Inquiry;
    component.dialogBoxClose(event.detail);
    const expectedValue = PageMode.Inquiry;
    expect(event.detail).toEqual(billFeeValueTypes.donotSave);
    expect(component.escrowPageMode).toStrictEqual(expectedValue);
    // expect(escrowActionsMock.getEscrow).toBeCalledWith({request: {} as any});
    // expect(storeMock.dispatch).toHaveBeenCalledTimes(2);
    // expect(escrowActionsMock.getEscrow).toHaveBeenCalledTimes(1);
});
it('dialogBoxClose() else method should be execute', () => {
    const event = {detail: 'Cancel'};
    component.dialogBoxClose(event.detail);
    expect(component.showDialogBox).toBeFalsy();
    expect(component.cancelDialogBox).toBeFalsy();
});
it('ngOnDestroy() method should be execute', () => {
    component.ngOnDestroy();
});

});
