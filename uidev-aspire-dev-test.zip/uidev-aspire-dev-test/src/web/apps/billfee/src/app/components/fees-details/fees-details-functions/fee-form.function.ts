import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormDataTypeEnum } from '@uid/uid-angular-controls';
import { LoanFeeFormStateModel } from '../../../models/loan-fee-form-state.model';
import { LnFeeInfoRecModel } from '../../../models/loan-fee-info-record.model';
import { BillFeeFormDateTypeEnum} from '../../../models/bill-fee-enums';

export const isHideDebtFields = function(model: LnFeeInfoRecModel, formState: LoanFeeFormStateModel, field?: FormlyFieldConfig): boolean{
    if(model['lnFeeCode'] !== '815'){
         return true;
     }else{
        return false;
     }
};

// <--- function to make the field readonly ----->
export function isReadOnly(model: LnFeeInfoRecModel, formState: LoanFeeFormStateModel, field?: FormlyFieldConfig): boolean{
   if(model['lnFeeWavDt'] === null || model['lnFeeWavDt'] === '' || model['lnFeeWavDt'] === undefined){
       return false;
    }else{
       return true;
    }
}


// <--- formly fields ---->
export function generateFormlyConfig(): FormlyFieldConfig[]{
    // return data
    return [
        {
            templateOptions: {label: 'Fee Information'},
            wrappers: ['record-detail-block'],
            fieldGroup:[
                {
                   key: 'lnFeeId',
                   hide: true
                },
                {
                    key: 'lnFeeCode',
                    wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                    templateOptions: {
                        label: 'Fee Number',
                        labelClasses: 'col-md-5',
                        valueClasses: 'col-md-7',
                        screenMode: 'fee',
                        attributes: {
                            'data-test-id': 'feeList-lnFeeCode-01'
                          }
                        },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'lnFeeConcatDescription',
                    templateOptions: {
                        label: 'Fee Description',
                        labelClasses: 'col-md-5',
                        valueClasses: 'col-md-7',
                        inputStyleClass: 'rui-form-control',
                        maxLength: 60,
                        attributes: {
                            'data-test-id': 'feeList-feeDescription-01'
                          }
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'capitalized',
                    wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                    templateOptions: {
                        label: 'Capitalized',
                        labelClasses: 'col-md-5',
                        valueClasses: 'col-md-7',
                        screenMode: 'fee',
                        attributes: {
                            'data-test-id': 'feeList-capitalized-01'
                          }
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'lnFeeSeq',
                    wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                    templateOptions: {
                        label: 'Fee Sequence',
                        labelClasses: 'col-md-5',
                        valueClasses: 'col-md-7',
                        screenMode: 'fee',
                        attributes: {
                            'data-test-id': 'feeList-feeSeq-01'
                          }
                    },
                    type: FormDataTypeEnum.input,
                },
                {
                    key: 'lnFeeDebtProtType',
                    wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                    templateOptions: {
                        label: 'Debt Protection Type',
                        labelClasses: 'col-md-5',
                        valueClasses: 'col-md-7',
                        screenMode: 'fee',
                        attributes: {
                            'data-test-id': 'feeList-feeDebtProtType-01'
                          }
                    },
                    type: FormDataTypeEnum.input,
                    hideExpression: isHideDebtFields
                },
                {
                    key:'lnFeeDebtProtSeq',
                    wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                    templateOptions: {
                        label: 'Debt Protection Sequence',
                        labelClasses: 'col-md-5',
                        valueClasses: 'col-md-7',
                        screenMode: 'fee',
                        attributes: {
                            'data-test-id': 'feeList-feeDebtProtSeq-01'
                          }
                    },
                    type: FormDataTypeEnum.input,
                    hideExpression: isHideDebtFields,
                },
            ]
        },
        {
            templateOptions: {label: 'Amounts'},
            wrappers: ['record-detail-block'],
            fieldGroup:[
              {
                  key: 'lnFeeAmt',
                  wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                  templateOptions: {
                      label: 'Amount Assessed',
                      labelClasses: 'col-md-5',
                      valueClasses: 'col-md-7',
                      screenMode: 'fee',
                      attributes: {
                        'data-test-id': 'feeList-feeAmt-01'
                      }
                    },
                  type: FormDataTypeEnum.currency,
              },
              {
                key: 'lnFeeRemAmt',
                type: FormDataTypeEnum.currency,
                templateOptions: {
                    label: 'Amount Remaining',
                    labelClasses: 'col-md-5',
                    valueClasses: 'col-md-7',
                    maxlength: 15,
                    attributes: {
                        'data-test-id': 'feeList-feeRemAmt-01'
                      }
                },

                expressionProperties: {
                    'templateOptions.disabled': isReadOnly
                }
            },
            ],
        },
        {
            templateOptions: {label: 'Date Information'},
            wrappers: ['record-detail-block'],
            fieldGroup:[
                {
                    key: 'lnFeeLastPmtDt',
                    wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                    templateOptions: {label: 'Payment Due Date',
                    labelClasses: 'col-md-5',
                    valueClasses: 'col-md-7',
                    screenMode: 'fee',
                    attributes: {
                        'data-test-id': 'feeList-feeLastPmtDt-01'
                      }},
                    type: FormDataTypeEnum.datepicker
                },
                {
                    key: 'lnFeeAssmntDt',
                    wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                    templateOptions: {label: 'Assessed Date',
                    labelClasses: 'col-md-5',
                    valueClasses: 'col-md-7',
                    screenMode: 'fee',
                    attributes: {
                        'data-test-id': 'feeList-feeAssmntDt-01'
                      }
                },
                },
                {
                    key: 'lnBillDt',
                    className: 'sec1',
                    type: FormDataTypeEnum.datepicker,
                    templateOptions: {
                        dataTestId: 'data-lnBillDt',
                        label: 'Bill Due Date',
                        labelClasses: 'col-md-5',
                        valueClasses: 'col-md-7',
                        placeholder: 'MM/DD/YYYY',
                        dateFormat: 'mm/dd/yy',
                        showButtonBar: false,
                        attributes: {
                            'data-test-id': 'feeList-billDt-01'
                          }
                    },

                },
                {
                    key: 'lnPaidDt',
                    type: FormDataTypeEnum.datepicker,
                    templateOptions: {
                        label: 'Paid Date',
                        labelClasses: 'col-md-5',
                        valueClasses: 'col-md-7',
                        placeholder: 'MM/DD/YYYY',
                        dateFormat: 'mm/dd/yy',
                        type: 'date',
                        showButtonBar: false,
                        attributes: {
                            'data-test-id': 'feeList-paidDt-01'
                          }
                    },
                    expressionProperties: {
                        'templateOptions.disabled': isReadOnly
                    }
                },
              {
                key: 'lnFeeWavDt',
                wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
                templateOptions: {label: 'Waived Date',
                labelClasses: 'col-md-4',
                valueClasses: 'col-md-6',
                screenMode: 'fee',
                attributes: {
                    'data-test-id': 'feeList-feeWavDt-05'
                  }
            },
                type: FormDataTypeEnum.datepicker
            },
            ],
            // <--- dates close ---->
        },
    ];

}

