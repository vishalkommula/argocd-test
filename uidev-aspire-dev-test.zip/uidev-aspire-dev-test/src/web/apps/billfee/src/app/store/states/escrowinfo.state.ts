// import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';
// import { FaultMsgRec } from '../../models/loan-bill-escrow-model';


// export interface EscrowDetailsState{
//     escrowDetailsResponse: LnBilEscrwSrchResponse;
//     showoverridedialogbox: boolean;
//     faultRecInfoArray: FaultMsgRec[];
// };

// // Initial state for escrow details

// export const initialEscrowInfoState: EscrowDetailsState = {
//     escrowDetailsResponse: {} as LnBilEscrwSrchResponse,
//     showoverridedialogbox:false,
//     faultRecInfoArray:[],
// };
