import { Component} from '@angular/core';
import { FieldArrayType, FormlyFieldConfig } from '@ngx-formly/core';

@Component({
  selector: 'uid-bill-table-type',
  templateUrl: './bill-table-type.component.html',
  styleUrls: ['./bill-table-type.component.scss']
})
export class BillTableTypeComponent extends FieldArrayType  {
  formlyfields: FormlyFieldConfig[]=[];

  constructor(){
    super();
  }

}
