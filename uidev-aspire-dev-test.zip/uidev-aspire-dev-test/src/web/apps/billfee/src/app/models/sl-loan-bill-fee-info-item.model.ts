export interface SLLnFeeInfoItemModel{
    feeDesc?: string;
    amtRemaining?: number;
    billDt?: string;
    paidDt?: string;
    matDt?: Date;
};
