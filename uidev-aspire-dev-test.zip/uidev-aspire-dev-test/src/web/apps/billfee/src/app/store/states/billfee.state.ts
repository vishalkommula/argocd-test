
import { LoanBillFeeResponseModel } from '../../models/loan-bill-fee-response.model';
import { LnBilSrchFilterModel } from '../../models/loan-bill-search-filter.model';
import { LnBilSrchResponseModel } from '../../models/loan-bill-search-response.model';
import { LnFeeInfoRecModel } from '../../models/loan-fee-info-record.model';
import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';
import { PageMode } from '../../models/bill-fee-enums';
import { LnBilInfoResponseModel } from '../../models/loan-bill-info-response.model';
import { LnFeeModResponse } from '../../models/loan-bill-fee-mod-response.model';


export interface BillFeeState{
    loanBillFeeResponse: LoanBillFeeResponseModel;
    currentBillFeeRecord: LnFeeInfoRecModel;
    pageMode: PageMode;
    updatedLoanFeeResponse: LnFeeModResponse;
    // billinfo state
    loanBillResponse: LnBilSrchResponseModel;
    selectedBillDueDate: string;
    lnBillInfoResponse: LnBilInfoResponseModel[];

    isBillInfoUpdated: boolean;
    isBillInfoDeleted: boolean;

    filterRecordModel: LnBilSrchFilterModel;

    //TODO: Why do we need 2 different state properties of the same type?
    // escrow state
    escrowDetailsResponse: LnBilEscrwSrchResponse;
    escrowDetailsEditResponse: LnBilEscrwSrchResponse;
    selectedModule: string;
}
