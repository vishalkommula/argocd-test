import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface LnBilEscrwSrchRequest{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
};
