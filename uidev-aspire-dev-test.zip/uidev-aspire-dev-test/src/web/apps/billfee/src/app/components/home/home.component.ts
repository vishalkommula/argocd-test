import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable, of} from 'rxjs';
import { PageMode } from '../../models/bill-fee-enums';
// store
import { selectSelectedModule } from '../../store';
import * as BillInfoSelect from '../../store/selectors/billInfo.selector';
import { BillFeeRoutesEnum, BillFeeModulesEnum } from '../../models/bill-fee-enums';

@Component({
  selector: 'uid-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})

export class HomeComponent implements OnInit{
  // to store the current selected module (bills or fees or escrow)
  selectedModule$: Observable<string>= of(BillFeeModulesEnum.bills);
  billFeeModulesEnum = BillFeeModulesEnum;
  billFeeRoutesEnum = BillFeeRoutesEnum;
  pageMode$!: Observable<PageMode>;
  pageModeEnum = PageMode;
  // assign the selector
  billInfoSelector = BillInfoSelect;

  constructor(private route: Router, private store: Store) {
  }

  ngOnInit(): void {
    this.selectedModule$ = this.store.select(selectSelectedModule);

    // check page mode to block the routing
    this.pageMode$ = this.store.select(this.billInfoSelector.selectPageMode);
  }

  // bills button on-click
  viewBills(pageMode: PageMode) {
    // TODO : implement guards to block the routing when in editmode.
    if(pageMode===PageMode.Inquiry){
      this.route.navigateByUrl(this.billFeeRoutesEnum.billsScreen);
    }
  }
  // fees button on-click
  viewFees(pageMode: PageMode) {
     // TODO : implement guards to block the routing when in editmode.
    if(pageMode===PageMode.Inquiry){
      this.route.navigateByUrl(this.billFeeRoutesEnum.feesScreen);
    }
  }

  // escrow button on-click
  viewEscrow(pageMode: PageMode) {
    // TODO : implement guards to block the routing when in editmode.
    if(pageMode===PageMode.Inquiry){
      this.route.navigate([this.billFeeRoutesEnum.escrowScreen],{state: {pageType: this.billFeeModulesEnum.escrow}});
    }
  }
}
