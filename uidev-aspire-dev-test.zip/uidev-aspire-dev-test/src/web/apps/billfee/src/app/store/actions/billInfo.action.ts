import { createAction, props } from '@ngrx/store';
import { LnBilDeleteRequestModel } from '../../models/loan-bill-delete-request.model';
import { LnBilAddRequestModel } from '../../models/loan-billI-add-request.model';
import { LnBilInfoResponseModel } from '../../models/loan-bill-info-response.model';
import { LnBilInfoRequestModel } from '../../models/loan-bill-inq-request.model';
import { LnBilModRequestModel } from '../../models/loan-bill-mod-request.model';
import { LnBilSrchRequestModel } from '../../models/loan-bill-search-request.model';
import { LnBilSrchResponseModel } from '../../models/loan-bill-search-response.model';
import { LnBillAddModResponse } from '../../models/loan-bill-add-mod-response.model';
import { LnFeeInfoRecModel } from '../../models/loan-fee-info-record.model';
import { LnBilInfoRecItemModel } from '../../models/loan-bill-info-record-item.model';
import { GridCellModifiedData } from '../../models/grid-cell-modified-data.model';
import { SLLnBilEscrwPmtBalInfoRecItem } from '../../models/sl-loan-bill-escrow-pmt-bal-info-record-item.model';
import { LnBilSrchFilterModel } from '../../models/loan-bill-search-filter.model';
import { SLLnBilEscrwInfoRecItemModel } from '../../models/sl-loan-bill-escrow-info-record-item.model';
import { PageMode } from '../../models/bill-fee-enums';

// bill list pre load action
export const getBillList = createAction('[Bill List] Get Bill List', props<{ request: LnBilSrchRequestModel }>());

// bill list action success response
export const getBillListSuccess = createAction('[Bill List] Get Bill List Success', props<{ response: LnBilSrchResponseModel }>());

// bill list action error response
export const getBillListFailure = createAction('[Bill List] Get Bill List Success', props<{ error: Error }>());

// set bill due date
export const updateSelectedBillDueDate = createAction('[Bill List] Update Selected Bill Due Date', props<{ dueDate: string }>());

// Filter
export const setBillListFilter = createAction('[Bill List] Set Filter', props<{ filterRecordModel: LnBilSrchFilterModel }>());
export const clearBillListFilter = createAction('[Bill List] Clear Filter');

// get bill details by billduedt
export const getBillDetails = createAction('[Bills/Fees] Fetch Bill Details By Billduedt', props<{ loanBillInfoRequest: LnBilInfoRequestModel }>());

// get bill details by billduedt
export const getBillDetailsSuccess = createAction('[Bills/Fees] Fetch Bill Details Success Response', props<{ loanBillInfoResponse: LnBilInfoResponseModel }>());

// get bill details by billduedt
export const getBillDetailsError = createAction('[Bills/Fees] Fetch Bill Details Error Response', props<{ error: Error }>());

// update bill details
export const updateBillDetails = createAction('[Bills/Fees] Update Bill Details', props<{ billModRequest: LnBilModRequestModel }>());

// update bill details success
export const updateBillDetailsSuccess = createAction('[Bills/Fees] Update Bill Details Success Response', props<{ billModResponse: LnBillAddModResponse }>());

// update bill details error
export const updateBillDetailsError = createAction('[Bills/Fees] Update Bill Details Error Response', props<{ billModResponse: boolean }>());

// add bill details
export const addBillDetails = createAction('[Bills/Fees] Add Bill Details', props<{ billAddRequest: LnBilAddRequestModel }>());

// add bill details
export const addBillDetailsSuccess = createAction('[Bills/Fees] Add Bill Details Success Response', props<{ billAddResponse: LnBillAddModResponse }>());

// add bill details
export const addBillDetailsError = createAction('[Bills/Fees] Add Bill Details Error Response', props<{ billAddResponse: boolean }>());

// add bill details
export const deleteBillDetails = createAction('[Bills/Fees] Delete Bill Details', props<{ deleteRequest: LnBilDeleteRequestModel }>());

// delete bill details
export const deleteBillDetailsSuccess = createAction('[Bills/Fees] Delete Bill Details Success Response', props<{ deleteResponse: LnBillAddModResponse }>());

// delete bill details
export const deleteBillDetailsError = createAction('[Bills/Fees] Delete Bill Details Error response', props<{ deleteResponse: boolean }>());

// bill click action
export const changePageMode = createAction('[Bills/Fees] Bill Details Page Mode', props<{ clickAction: PageMode }>());

// bill click action
export const blockOverrideDialog = createAction('[Bills/Fees] Block Override Dialogbox Block Or Show', props<{ blockOverrideDialog: boolean }>());

// attached fee update
export const updateAttachedFee = createAction('[Bills/Fees] Update AttachedFee in BilInfo after grid update', props<{ cellModifiedData: GridCellModifiedData<LnFeeInfoRecModel>; billDueDt: string }>());

// billInfo escrowModel update
export const updateBillInfoEscrowModel = createAction(
  '[Bills/Fees] Update Bill Info Escrow Model in BilInfo after grid update',
  props<{ updateBillInfoEscrowModel: GridCellModifiedData<SLLnBilEscrwPmtBalInfoRecItem>; billDueDt: string }>()
);

// billInfo update
export const updateBillInfoModel = createAction('[Bills/Fees] Update Bill Info Model in BilInfo after grid update', props<{ updateBillInfoModel: LnBilInfoRecItemModel }>());

// billInfo update
export const updateBillInfoEscrowDetails = createAction('[Bills/Fees] Update Bill Info Escrow in BilInfo after grid update', props<{ updateBillEscrowDetails: SLLnBilEscrwInfoRecItemModel; billDueDt: string }>());
