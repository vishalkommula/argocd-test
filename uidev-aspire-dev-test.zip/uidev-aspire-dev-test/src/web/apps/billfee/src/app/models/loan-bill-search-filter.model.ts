export interface LnBilSrchFilterModel{
    dateRange?: Date[];
    paymentAmountTo?: number;
    paymentAmountFrom?: number;
};
