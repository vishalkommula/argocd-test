import { Observable, Subscription,of } from 'rxjs';
import { PageMode } from '../../../models/bill-fee-enums';
import { LnBilSrchFilterModel } from '../../../models/loan-bill-search-filter.model';
import { LnBilSrchRecModel } from '../../../models/loan-bill-search-record.model';
import { BillListComponent } from './bill-list.component';
import lnBilSrchResponse from '../../../mock-data/loanBillSearchResponse.mock.json';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());
jest.useFakeTimers();
jest.spyOn(global, 'setTimeout');

let component: BillListComponent;

const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(()=> ({
    subscribe:jest.fn(),
    })),
};

const billInfoActionsMock = {
  getBillList: jest.fn(),
  billDueDate: jest.fn(),
  getbilldetails:jest.fn(),
  billClickAction: jest.fn(),
  setBillListFilter: jest.fn(),
  clearBillListFilter: jest.fn()
};

const billInfoSelectorsMock = {
  selectFilteredBills: jest.fn(),
  selectIsBillInfoDeleted: jest.fn(),
  selectIsBillInfoUpdated: jest.fn(),
  selectAction: jest.fn(),
  selectIsBillInfoFormDirty: jest.fn(),
};


const calendar = {
  overlayVisible: jest.fn()
};

const billDueDateSelectedEventMock = {
  emit: jest.fn()
};

const subscriptions: Subscription[]=[new Subscription,new Subscription, new Subscription, new Subscription];

describe('bill list component test',()=>{
  beforeEach(()=>{
    component = new BillListComponent(storeMock as any);
    component.resetFilterRecordModel();
    component.billInfoActions = billInfoActionsMock as any;
    component.billInfoSelectors = billInfoSelectorsMock as any;
    component.calendar = calendar;
    component.subscriptions = subscriptions;
    component.billDueDateSelectedEvent = billDueDateSelectedEventMock as any;

  });

  it('component should be created',()=>{
    expect(component).toBeTruthy();
  });


  // ngOnInit method test
  it('ngOnInit - should be executed',()=>{
      component.ngOnInit();
      expect(billInfoActionsMock.getBillList).toBeCalledWith({request: {} as any});
      expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
      expect(billInfoActionsMock.getBillList).toHaveBeenCalledTimes(1);
  });

  it('getOverdueDays - should be executed',() => {
    const billDueDate = '2022-05-30';
    const actualValue = component.getOverdueDays(billDueDate);
    const dueDate = new Date(billDueDate);
    const currentDate = new Date();
    const expectedValue = ((currentDate.getTime() - dueDate.getTime()) / (1000 * 3600 * 24) - 1).toFixed(0);
    expect(actualValue).toEqual(expectedValue);
  });

  it('isAddBillAllowed - should be executed',()=>{
    const actualValue = component.isAddBillAllowed();
    const expectedValue = true;
    expect(actualValue).toEqual(expectedValue);
  });

  it('resetFilterRecordModel - should be executed',()=>{
    component.resetFilterRecordModel();
    expect(component.filterRecordModel).toEqual({} as LnBilSrchFilterModel);
  });

  it('applyFilter - should be executed',()=>{
    component.applyFilter();
    expect(billInfoActionsMock.setBillListFilter).toBeCalledWith({filterRecordModel : {} as any});
    expect(billInfoActionsMock.setBillListFilter).toHaveBeenCalledTimes(1);
  });

  it('resetFilter - should be executed',()=>{
    component.resetFilter();
    expect(component.isFilterActionButtonsDisabled).toEqual(true);
    expect(billInfoActionsMock.clearBillListFilter).toHaveBeenCalledTimes(1);
  });

  // ToCheck
  it('addBill - should be executed',()=>{
    component.pageMode = PageMode.Inquiry;
    component.addBill();
    // expect(billInfoActionsMock.billClickAction).toBeCalledWith({clickAction: {} as any});
    // expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
    // expect(billInfoActionsMock.billClickAction).toHaveBeenCalledTimes(1);
  });

  it('onClickPCalendarPopup - should be executed', ()=>{
    component.filterRecordModel = {dateRange:[new Date(),new Date()]};
    component.onClickPCalendarPopup();
    expect(calendar.overlayVisible).toBeFalsy();
  });

  // unsubscribe logic pending
  it('ngOnDestroy - should be executed',()=>{
    component.ngOnDestroy();
  });

  it('filterModelChange - should be executed',()=>{
    component.filterModelChange();
    expect(component.isFilterActionButtonsDisabled).toBeTruthy();
  });

  it('filterModelChange - from and to dates',()=>{
    const filterModelData = {dateRange: [new Date,new Date], paymentAmountTo: undefined, paymentAmountFrom: undefined};
    component.filterRecordModel = filterModelData as any;
    component.filterModelChange();
    expect(component.isFilterActionButtonsDisabled).toBeFalsy();
  });

  it('filterModelChange - payment amount to',()=>{
    const filterModelData = {dateRange:undefined, paymentAmountTo: 300, paymentAmountFrom: undefined};
    component.filterRecordModel = filterModelData as any;
    component.filterModelChange();
    expect(component.isFilterActionButtonsDisabled).toBeFalsy();
  });

  it('filterModelChange - payment amount from',()=>{
    const filterModelData = {dateRange:undefined, paymentAmountTo: undefined, paymentAmountFrom: 400};
    component.filterRecordModel = filterModelData as any;
    component.filterModelChange();
    expect(component.isFilterActionButtonsDisabled).toBeFalsy();
  });

  it('filterModelChange - only from date in date range',()=>{
    const filterModelData = {dateRange:[new Date,null], paymentAmountTo: undefined, paymentAmountFrom: undefined};
    component.filterRecordModel = filterModelData as any;
    component.filterModelChange();
    expect(component.isFilterActionButtonsDisabled).toBeTruthy();
  });

  it('getDataForSelectedBillDueDate - view mode',()=>{
    const event = {detail: '2022-05-30'};
    const previousSelectedBillDueDate = '';
    const skipFormValidation = true;
    component.previousSelectedBillDueDt = previousSelectedBillDueDate;
    component.skipFormValidation = skipFormValidation;
    component.getDataForSelectedBillDueDate(event as any);
    expect(component.skipFormValidation).toBeFalsy();
    expect(component.currentSelectedBillDueDate).toEqual(event.detail);
    expect(component.previousSelectedBillDueDt).toEqual(component.currentSelectedBillDueDate);
    expect(component.billDueDateSelectedEvent.emit).toHaveBeenCalledWith(event.detail);
  });

  it('getDataForSelectedBillDueDate - edit mode',()=>{
    const event = {detail: '2022-05-30'};
    const previousSelectedBillDueDate = '';
    const skipFormValidation = false;
    const pageMode = PageMode.Edit;
    component.pageMode = pageMode;
    component.previousSelectedBillDueDt = previousSelectedBillDueDate;
    component.skipFormValidation = skipFormValidation;
    component.getDataForSelectedBillDueDate(event as any);
    expect(component.nextSelectedBillDueDt).toEqual(event.detail);
    expect(component.currentSelectedBillDueDate).toEqual('');
    jest.useFakeTimers();
    expect(component.currentSelectedBillDueDate).toEqual('');
    jest.advanceTimersByTime(50);
    expect(component.currentSelectedBillDueDate).toEqual(component.previousSelectedBillDueDt);
    });

});
