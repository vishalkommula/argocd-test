import { SearchMessageRequestHeaderModel } from '@uid/uid-models';
import { LnBilEscrwInfoRecModel } from './loan-bill-escrow-info-record.model';

export interface LnBilEscrwEditSrchRequest{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    lnBilEscrwInfoRec:    LnBilEscrwInfoRecModel;
};
