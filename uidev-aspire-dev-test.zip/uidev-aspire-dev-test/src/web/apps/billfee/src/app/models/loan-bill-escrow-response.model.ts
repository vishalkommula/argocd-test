import { SearchMessageResponseHeaderModel,FaultMsgRec } from '@uid/uid-models';
import { LnBilEscrwInfoRecModel } from './loan-bill-escrow-info-record.model';


export interface LnBilEscrwSrchResponse{
    srchMsgRsHdr:    SearchMessageResponseHeaderModel;
    acctId:          string;
    acctType:        string;
    lnBilEscrwInfoRec:    LnBilEscrwInfoRecModel;
    faultRecInfoArray: FaultMsgRec[];
    rsStat: boolean;
    canOverride: boolean;
};
