import { SearchMessageRequestHeaderModel } from '@uid/uid-models';

export interface LnBilInfoRequestModel{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    bilDueDt: string;
};
