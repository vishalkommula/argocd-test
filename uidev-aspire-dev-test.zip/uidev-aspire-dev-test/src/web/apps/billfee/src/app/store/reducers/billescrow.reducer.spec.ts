// import { initialEscrowInfoState } from '../states/escrowinfo.state';
// import { escrowDetailsReducer } from './billescrow.reducer';
// import * as EscrowInfoActions from '../actions/billescrow.action';
// import { LnBilEscrwSrchResponse } from '../../models/loan-bill-escrow-response.model';


// describe('Escrow Reducer Test', ()=> {
//     it('escrowList returns default state', ()=>{
//         const state = escrowDetailsReducer(initialEscrowInfoState, EscrowInfoActions.escrowList({} as any));

//         expect(state).toEqual({
//             escrowDetailsResponse: {} as LnBilEscrwSrchResponse
//         });
//     });

//     it('EscrowSuccess returns the correct state', ()=> {
//         const responseModel = { this: 'Sample response model' };
//         const state = escrowDetailsReducer(initialEscrowInfoState, EscrowInfoActions.escrowListRetrived({response: responseModel as any}));
//         expect(state).toEqual(
//             {escrowDetailsResponse: responseModel}
//         );
//     });
// });


