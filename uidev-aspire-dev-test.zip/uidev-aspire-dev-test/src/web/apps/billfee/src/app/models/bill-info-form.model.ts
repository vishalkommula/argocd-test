// export interface BillInfoFormModel {
//     bilPaidDt: string;
//     bilPrincAmt: number;
//     bilIntAmt: number;
//     bilEscrwAmt: number;
//     bilLateChgAmt: number;
//     bilOtherChgAmt: number;
//     totalRemaining: number;
//     remBilPrincAmt: number;
//     remBilIntAmt: number;
//     remBilEscrwAmt: number;
//     remBilLateChgAmt: number;
//     remBilOtherChgAmt: number;
//     totalBilled: number;
//     bilDueDt: string;
//     nxtPayDt: string;
//     printbillingnotice: boolean;
//     addBilDueDt: string;
// }
