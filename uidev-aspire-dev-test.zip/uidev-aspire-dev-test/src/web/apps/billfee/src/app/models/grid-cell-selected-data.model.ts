export interface GridCellSelectedRecord <T>{
    selectedRecord: T;
    // selected status tracks if user is selected or deselected the row.
    selectedStatus: boolean;
}
