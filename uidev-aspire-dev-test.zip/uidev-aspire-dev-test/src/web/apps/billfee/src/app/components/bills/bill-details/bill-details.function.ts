import { FormlyFieldConfig } from '@ngx-formly/core';
import { FormDataTypeEnum } from '@uid/uid-angular-controls';
import { formatISODate } from '@uid/uid-utilities';
import { BillFeeFormDateTypeEnum, billFeeValueTypes, PageMode } from '../../../models/bill-fee-enums';
import { BillFormStateModel } from '../../../models/bill-info-formstate.model';
import { LnBilInfoRecItemModel } from '../../../models/loan-bill-info-record-item.model';

// to set input type for numbers field
// eslint-disable-next-line @typescript-eslint/naming-convention
const InputNumberModeEnum = {
  decimal : 'decimal',
  currency : 'currency'
};
// common fields for edit and add
export const isBillDetailView = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): boolean {
  return (formState.pageMode === PageMode.Edit || formState.pageMode === PageMode.Add) ? false : true;
};
// edit display form
export const isAddView = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): boolean {
  return formState.pageMode === PageMode.Add ? false : true;
};
// view dispaly fiels
export const isBillInfoView = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): boolean {
  return (formState.pageMode === PageMode.Inquiry || formState.pageMode === PageMode.Edit ) ? false : true;
};

// printno dispaly fields
export const isPrintNoDisplay = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): boolean {
  return (formState.pageMode === PageMode.Add || formState.pageMode === PageMode.Edit) ? false : true;
};

// disable field if bill due date is empty
export const isBillDueDtEmpty = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): boolean {
  return formState.pageMode === PageMode.Add ?
    (model.addBilDueDt!==undefined && model.addBilDueDt!==null && model.addBilDueDt!=='' && !formState?.billDueDtValidation ? false : true) : false;
};

export const tableWidth = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): string {
  return formState.pageMode === PageMode.Inquiry ? '368px' : '500px';
};

export const billInfoScreenStyle = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): any {
  return formState.pageMode === PageMode.Inquiry ?
  (field?.key === 'totalRemaining' || field?.key === 'totalBilled' ?
  { 'text-align': 'right', 'font-weight': '600' } : { 'text-align': 'right', 'font-weight': '400' }) : { 'text-align': 'right', 'font-weight': '600' };
};

export const prntLabelClass = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): string {
  return formState.pageMode === PageMode.Add ? 'col-md-4' : 'col-md-10';
};

export const prntValueClass = function (model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): string {
  return formState.pageMode === PageMode.Add ? 'col-md-3' : 'col-md-2';
};
export const isEditView = function(model: LnBilInfoRecItemModel, formState: BillFormStateModel, field?: FormlyFieldConfig): boolean{
  return formState.pageMode === PageMode.Edit ? false : true;
};

export const isDetailsView = function(model: LnBilInfoRecItemModel, formstate: BillFormStateModel, field?: FormlyFieldConfig): boolean{
  return formstate.pageMode === PageMode.Inquiry ? false : true;
};

// toggle input mode mode statement details
export const getInputMode = function(model: LnBilInfoRecItemModel, formstate: BillFormStateModel, field?: FormlyFieldConfig){
  return formstate.pageMode === PageMode.Edit ? InputNumberModeEnum.decimal : InputNumberModeEnum.currency;
};

// TODO: Use Common Function
// Comment : DateTime is part of common date formatter Type in Luxon
export function dateISOFormatter(date: string): string {
  return date !== undefined ? formatISODate(date,billFeeValueTypes.displayedDateFormatter) : date;
}

export function getBillDetailFormField(): FormlyFieldConfig[] {
  return [
    {
      templateOptions: { width: 'medium',hideLabel:true },
      wrappers: ['record-detail-block'],
      hideExpression: isBillInfoView,
      fieldGroup: [
        {
          key: 'nxtPayDt',
          type: BillFeeFormDateTypeEnum.displayRecord,
          parsers: [(value: string) => dateISOFormatter(value)],
          templateOptions: {
            label: 'Payment Due Date',
            attributes: {
              'data-test-id': 'billDetails-nxtPayDt-01'
            }
          },
        },
        {
          key: 'bilDueDt',
          type: BillFeeFormDateTypeEnum.displayRecord,
          parsers: [(value: string) => dateISOFormatter(value)],
          templateOptions: {
            label: 'Bill Due Date',
            attributes: {
              'data-test-id': 'billDetails-bilDueDt-01'
            }
          },
        },
        {
          key: 'bilPaidDt',
          type: BillFeeFormDateTypeEnum.displayRecord,
          parsers: [(value: string) => dateISOFormatter(value)],
          templateOptions: {
            label: 'Billed Date',
            attributes: {
              'data-test-id': 'billDetails-bilPaidDt-01'
            }
          },
        },
      ],
    },
    {
      fieldGroup: [
        {
          validators: {
            validation: [{ name: BillFeeFormDateTypeEnum.billDueDtInvalid, options: { errorPath: 'addBilDueDt' } }],
          },
          key: 'addBilDueDt',
          type: FormDataTypeEnum.datepicker,
          templateOptions: {
            label: 'Bill Due Date:',
            styleclass: 'styleclass',
            placeholder: 'MM/DD/YYYY',
            dateFormat: 'mm/dd/yy',
            labelClasses: 'col-md-4',
            valueClasses: 'col-md-4',
            showButtonBar: false,
            attributes: {
              'data-test-id': 'billDetails-addBilDueDt-01'
            }
          },
          hideExpression: isAddView,
        },
        {
          templateOptions: {
            label: 'Print Billing Notice',
            name:'printbillingnotice',
            id: 'printbillingnotice',
            inputid: 'printbillingnotice',
            attributes: {
              'data-test-id': 'billDetails-printBN-01'
            }
          },
          wrappers:['form-field'],
          hideExpression: isPrintNoDisplay,
          key: 'printbillingnotice',
          type: FormDataTypeEnum.toggleButton,
          expressionProperties: {
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.labelClasses': prntLabelClass,
            'templateOptions.valueClasses': prntValueClass,
          },
        },
      ],
    },
    {
      type: BillFeeFormDateTypeEnum.billTableType,
      expressionProperties: {
        'templateOptions.width': tableWidth,
      },
      fieldGroup: [
        {
          name: 'Principal',
          templateOptions:{
            attributes: {
              'data-test-id': 'billDetails-tableLabel-01'
            }
          }
        },
        {
          key: 'remBilPrincAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 15,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-remBilPrincAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          key: 'bilPrincAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 15,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-bilPrincAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          name: 'Interest',
          templateOptions:{
            attributes: {
              'data-test-id': 'billDetails-tableLabel-02'
            }
          }
        },
        {
          key: 'remBilIntAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 15,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-remBilIntAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          key: 'bilIntAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 15,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-bilIntAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          name: 'Escrow',
          templateOptions:{
            attributes: {
              'data-test-id': 'billDetails-tableLabel-03'
            }
          }
        },
        {
          key: 'remBilEscrwAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 13,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-remBilEscrwAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          key: 'bilEscrwAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 13,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-bilEscrwAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          name: 'Late Charge',
          templateOptions:{
            attributes: {
              'data-test-id': 'billDetails-tableLabel-04'
            }
          }
        },
        {
          key: 'remBilLateChgAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 13,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-remBilLateChgAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          key: 'bilLateChgAmt',
          type: FormDataTypeEnum.currencyUsd,
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 13,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-bilLateChgAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          name: 'Other Charges',
          templateOptions:{
            attributes: {
              'data-test-id': 'billDetails-tableLabel-05'
            }
          }
        },
        {
          key: 'remBilOtherChgAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 15,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-remBilOtherChgAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          key: 'bilOtherChgAmt',
          wrappers: [BillFeeFormDateTypeEnum.recordDetailNoRuiFormRenderer],
          type: FormDataTypeEnum.currencyUsd,
          templateOptions: {
            styleclass: 'rui-form-control',
            setwidth: 'setwidth',
            maxlength: 15,
            min: 0,
            screenMode: 'bill',
            attributes: {
              'data-test-id': 'billDetails-bilOtherChgAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.islabeldata': isBillDetailView,
            'templateOptions.disabled': isBillDueDtEmpty,
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          name: 'Totals',
          templateOptions:{
            attributes: {
              'data-test-id': 'billDetails-tableLabel-06'
            }
          }
        },
        {
          key: 'totalRemaining',
          templateOptions: {
            styleclass: 'rui-form-control',
            islabeldata: true,
            attributes: {
              'data-test-id': 'billDetails-label-01'
            }
          },
          expressionProperties: {
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
        {
          key: 'totalBilled',
          templateOptions: {
            styleclass: 'rui-form-control',
            islabeldata: true,
            attributes: {
              'data-test-id': 'billDetails-label-02'
            }
          },
          expressionProperties: {
            'templateOptions.billInfoScreenStyle': billInfoScreenStyle,
          },
        },
      ],
    },
  ];
}

// statement details fields
// as per mock in edit view the blocks are grouped and rearranged, so activity block code is alone repeated.
export function getStatementDetailFormField(): FormlyFieldConfig[]{
  return [
    {
      templateOptions: { label: 'Balance'},
      wrappers: ['record-detail-block'],
      fieldGroup: [
        {
          key: 'lnStmtInfoRec.crLineAmt',
          templateOptions:{
            label: 'Credit Line Amount',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 99999999999,
            maxlength: 17,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-crLineAmt-01'
            },
          },
          type: FormDataTypeEnum.currency,
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
        },
        {
          key: 'lnStmtInfoRec.avalBal',
          templateOptions:{
            label: 'Available Credit',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 99999999999,
            maxlength: 17,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-avalBal-01'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency
        },
        {
          key: 'lnStmtInfoRec.prevAmtStillPastDue',
          templateOptions:{
            label: 'Minimum Due Amount',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 99999999999,
            maxlength: 17,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-prevAmtStillPastDue-01'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          key: 'lnStmtInfoRec.curBal',
          templateOptions:{
            label: 'New Balance',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 99999999999,
            maxlength: 17,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-curBal-01'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          key: 'lnStmtInfoRec.balLstStmt',
          templateOptions:{
            label: 'Previous Statement Balance',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 99999999999,
            maxlength: 17,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-balLstStmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          key: 'lnStmtInfoRec.avgBal',
          templateOptions:{
            label: 'Average Daily Balance',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 99999999999,
            maxlength: 17,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-avgBal-01'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        // activity block for edit view
        {
          templateOptions: { label: 'Activity'},
          wrappers: ['record-detail-block'],
          hideExpression: isEditView,
          fieldGroup: [
            {
              key: 'lnStmtInfoRec.amtOfAdvas',
              templateOptions:{
                label: 'Checks and Advance Amount',
                labelClasses: 'col-md-7',
                valueClasses: 'col-md-5',
                inputStyleClass: 'rui-form-control',
                minFractionDigits: 2,
                maxFractionDigits: 2,
                max: 999999999,
                maxlength: 14,
                prefix: '$',
                attributes: {
                  'data-test-id': 'statementDetail-amtOfAdvas-01'
                }
              },
              expressionProperties: {
                'templateOptions.mode': getInputMode,
              },
              type: FormDataTypeEnum.currency,
            },
            {
              key: 'lnStmtInfoRec.amtOfPmts',
              templateOptions:{
                label: 'Payments and Credits',
                labelClasses: 'col-md-7',
                valueClasses: 'col-md-5',
                inputStyleClass: 'rui-form-control',
                minFractionDigits: 2,
                maxFractionDigits: 2,
                max: 999999999,
                maxlength: 14,
                prefix: '$',
                attributes: {
                  'data-test-id': 'statementDetail-amtOfPmts-01'
                }
              },
              expressionProperties: {
                'templateOptions.mode': getInputMode,
              },
              type: FormDataTypeEnum.currency,
            },
            {
              key: 'lnStmtInfoRec.aggDays',
              templateOptions:{
                label: 'Days in Cycle',
                labelClasses: 'col-md-7',
                valueClasses: 'col-md-5',
                inputStyleClass: 'rui-form-control',
                max: 999,
                min: 0,
                maxlength: 3,
                minFractionDigits: 0,
                maxFractionDigits: 0,
                attributes: {
                  'data-test-id': 'statementDetail-aggDays-01'
                }
              },
              type: FormDataTypeEnum.number,
            },
          ]
        },
      ]
    },
    // activity block for details view
    {
      templateOptions: { label: 'Activity'},
      wrappers: ['record-detail-block'],
      hideExpression: isDetailsView,
      fieldGroup: [
        {
          key: 'lnStmtInfoRec.amtOfAdvas',
          templateOptions:{
            label: 'Checks and Advance Amount',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-amtOfAdvas-02'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          key: 'lnStmtInfoRec.amtOfPmts',
          templateOptions:{
            label: 'Payments and Credits',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-amtOfPmts-02'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          key: 'lnStmtInfoRec.aggDays',
          templateOptions:{
            label: 'Days in Cycle',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            attributes: {
              'data-test-id': 'statementDetail-aggDays-02'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.number,
        },
      ]
    },
    {
      templateOptions: { label: 'Payment'},
      wrappers: ['record-detail-block'],
      fieldGroup: [
        {
          key: 'lnStmtInfoRec.nxtPmtDueDt',
          type: FormDataTypeEnum.datepicker,
          parsers: [(value: string) => dateISOFormatter(value)],
          templateOptions:{
            label: 'Payment Due Date',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            showButtonBar: false,
            attributes: {
              'data-test-id': 'statementDetail-nxtPmtDueDt-01'
            }
          },
        },
        {
          key: 'lnStmtInfoRec.pmtAmt',
          templateOptions:{
            label: 'Current Due Amount',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 999999999,
            maxlength: 14,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-pmtAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          key: 'lnStmtInfoRec.pastDuePmtAmt',
          templateOptions:{
            label: 'Past Due Amount',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 99999999999,
            maxlength: 17,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-pastDuePmtAmt-01'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          key: 'lnStmtInfoRec.othChgs',
          templateOptions:{
            label: 'Other Charges',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 999999999,
            maxlength: 14,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-currencyUsd-13'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          key: 'lnStmtInfoRec.fincChg',
          templateOptions:{
            label: 'Finance Charges',
            labelClasses: 'col-md-7',
            valueClasses: 'col-md-5',
            inputStyleClass: 'rui-form-control',
            minFractionDigits: 2,
            maxFractionDigits: 2,
            max: 999999999,
            maxlength: 14,
            prefix: '$',
            attributes: {
              'data-test-id': 'statementDetail-currencyUsd-14'
            }
          },
          expressionProperties: {
            'templateOptions.mode': getInputMode,
          },
          type: FormDataTypeEnum.currency,
        },
        {
          templateOptions: { label: 'Rate'},
          wrappers: ['record-detail-block'],
          expressionProperties: {
            'templateOptions.spacer': isEditView,
          },
          fieldGroup: [
            {
              key: 'lnStmtInfoRec.annPctRate',
              templateOptions:{
                label: 'Annual Percentage Rate',
                labelClasses: 'col-md-7',
                valueClasses: 'col-md-5',
                inputStyleClass: 'rui-form-control',
                minFractionDigits: 6,
                maxFractionDigits: 6,
                max: 99999,
                maxlength: 13,
                suffix: '%',
                attributes: {
                  'data-test-id': 'statementDetail-percentage-01'
                }
              },
              type: FormDataTypeEnum.percentage,
            },
            {
              key: 'lnStmtInfoRec.dlyPeriodicRate',
              templateOptions:{
                label: 'Daily Percentage Rate',
                labelClasses: 'col-md-7',
                valueClasses: 'col-md-5',
                inputStyleClass: 'rui-form-control',
                minFractionDigits: 8,
                maxFractionDigits: 8,
                maxlength: 10,
                max: 1,
                suffix: '%',
                attributes: {
                  'data-test-id': 'statementDetail-percentage-02'
                }
              },
              expressionProperties: {
                'templateOptions.mode': getInputMode,
              },
              type: FormDataTypeEnum.percentage,
            },
          ]
        }
      ]
    },
  ];
}
