jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

import { EscrowgridcoldefService } from './escrow-grid-coldef.service';

let service: EscrowgridcoldefService;

describe('EscrowgridcoldefService', () => {

  beforeEach(() => {
    service = new EscrowgridcoldefService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('currencyFormatter convert number to currency and returns currency format', () => {
    const params = { value: '2000' };
    expect(service.currencyFormatter(params as any)).toBe('$2,000.00');
  });
  it('amountFormatter convert number to currency and returns currency format', () => {
    const params = { value: '2000' };
    expect(service.amountFormatter(params as any)).toBe('$2,000.00');
  });
  it('amountFormatter convert number to currency and returns currency format', () => {
    const params = { value: undefined };
    expect(service.amountFormatter(params as any)).toBe('');
  });
});
