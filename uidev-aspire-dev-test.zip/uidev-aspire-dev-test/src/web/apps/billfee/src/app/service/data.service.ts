import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LuxonDateFormatterPipe } from '@uid/uid-pipes';
import { DateTime } from 'luxon';
import { Observable, of } from 'rxjs';
import billinfomockdata from '../mock-data/loanBillInqResponse.mock.json';
import mockdata from '../mock-data/loanBillSearchResponse.mock.json';

import feemockdata from '../mock-data/loanBillFeeResponse.mock.json';
import shadowfeemockdata from '../mock-data/shadowFeeResponse.mock.json';
import { LnBilDeleteRequestModel } from '../models/loan-bill-delete-request.model';
import { LnBilAddRequestModel } from '../models/loan-billI-add-request.model';
import { LnBilInfoRequestModel } from '../models/loan-bill-inq-request.model';
import { LnBilModRequestModel } from '../models/loan-bill-mod-request.model';
import { LnBilSrchResponseModel } from '../models/loan-bill-search-response.model';
import { LnBilSrchRequestModel } from '../models/loan-bill-search-request.model';
import { LnBillAddModResponse } from '../models/loan-bill-add-mod-response.model';
import { FaultMsgRec } from '../models/loan-bill-error.model';
import { LoanBillFeeResponseModel } from '../models/loan-bill-fee-response.model';
import { LoanBillFeeRequestModel } from '../models/loan-bill-fee-request.model';
import escrowmockdata from '../mock-data/loanBillescrowResponse.mock.json';
import editescrowmockdata from '../mock-data/loanBillescrowEditResponse.mock.json';
import { LnBilEscrwSrchRequest } from '../models/loan-bill-escrow-request.model';
import { LnBilEscrwSrchResponse } from '../models/loan-bill-escrow-response.model';
import { LnBilEscrwEditSrchRequest } from '../models/loan-bill-escrow-edit-request.model';
import { LnBilInfoResponseModel } from '../models/loan-bill-info-response.model';
import { LnFeeModResponse } from '../models/loan-bill-fee-mod-response.model';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  loanbillinfores!: LnBilInfoResponseModel;
  pipe: any;
  feedata: any;
  rsStat!: boolean;
  canOverride!: boolean;
  faultRec!: FaultMsgRec[];
  constructor(private httpClient: HttpClient) { }

    // to get the bill list
    getBills(request: LnBilSrchRequestModel): Observable<LnBilSrchResponseModel>{
      const clone = JSON.parse(JSON.stringify(mockdata));
      return of(clone);
    }

  // get bill details from billduedt.
  getBillDetailsbyBillduedt(request: LnBilInfoRequestModel): Observable<LnBilInfoResponseModel>{
    const billInfoModel = JSON.parse(JSON.stringify(billinfomockdata));
    // get loadnbill infor by billduedt
    const loanbillresponse=(billInfoModel as LnBilInfoResponseModel[]);
    const loanBillInfoResponseModel=loanbillresponse
    .filter(x=>x.lnbilInfoRec?.bilDueDt===request.bilDueDt)[0];
    return of(loanBillInfoResponseModel !== undefined ? loanBillInfoResponseModel : this.loanbillinfores);
  }
  // update the bill details.
  updatebilldetails(request: LnBilModRequestModel): Observable<LnBillAddModResponse>{
    const faultRec: FaultMsgRec[]=[{
      errCode:'200923',
      errCat:'Fault',
      errDesc:'Remaining billed amount cannot be greater than original billed amount',
      errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
      errElemVal:'88880/L/ 2022026',
      errLoc:'LNBILLMOD',
    },
    {
      errCode:'200923',
      errCat:'Fault',
      errDesc:'Total late charge fees do not equal remaining billed late charges.',
      errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
      errElemVal:'88880/L/ 2022026',
      errLoc:'LNBILLMOD',
    }];
    const modelValue: LnBillAddModResponse={
      srchMsgRqHdr:request.srchMsgRqHdr,
      acctId:request.acctId,
      acctType:request.acctType,
      lnBilInfoRec:request.lnBilInfoRec,
      rsStat:request.overrideFaultMsg,
      faultRecInfoArray: []
    };
    return of(modelValue);
  }
  // add bill details.
  addbilldetails(request: LnBilAddRequestModel): Observable<LnBillAddModResponse>{
    console.log(request,'bill info added');
    const faultRec: FaultMsgRec[]=[{
      errCode:'200923',
      errCat:'Fault',
      errDesc:'Remaining billed amount cannot be greater than original billed amount',
      errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
      errElemVal:'88880/L/ 2022026',
      errLoc:'LNBILLMOD',
    },
    {
      errCode:'200923',
      errCat:'Error',
      errDesc:'Total late charge fees do not equal remaining billed late charges.',
      errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
      errElemVal:'88880/L/ 2022026',
      errLoc:'LNBILLMOD',
    }];
    const modelValue: LnBillAddModResponse={
      srchMsgRqHdr:request.srchMsgRqHdr,
      acctId:request.acctId,
      acctType:request.acctType,
      lnBilInfoRec:request.lnBilInfoRec,
      rsStat:request.overrideFaultMsg,
      faultRecInfoArray: !request.overrideFaultMsg ? faultRec: []
    };
    return of(modelValue);
  }
    // delete bill details.
    deletebilldetails(request: LnBilDeleteRequestModel): Observable<LnBillAddModResponse>{
      const faultRec: FaultMsgRec[]=[{
        errCode:'200923',
        errCat:'Fault',
        errDesc:'Fee records attached to bill. Must reassign fees prior to deleting the bill',
        errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
        errElemVal:'88880/L/ 2022026',
        errLoc:'LNBILLMOD',
      }];
      const modelValue: LnBillAddModResponse={
        srchMsgRqHdr:request.srchMsgRqHdr,
        acctId:request.acctId,
        acctType:request.acctType,
        lnBilInfoRec:{},
        rsStat:true,
        faultRecInfoArray: []
      };
      return of(modelValue);
    }

    // to get loan bill fee list
  getLoanFees(request: LoanBillFeeRequestModel): Observable<LoanBillFeeResponseModel>{
   const data = JSON.parse(JSON.stringify(feemockdata));
   return of(data);
  }

  // get shadow fee list
  getShadowFees(request: LoanBillFeeRequestModel): Observable<LoanBillFeeResponseModel>{
    const shdwdata = JSON.parse(JSON.stringify(shadowfeemockdata));
    return of(shdwdata);
  }


  // update bill fee list
  setUpdatedBillFee(request: any): Observable<LnFeeModResponse>{

      this.feedata = JSON.parse(JSON.stringify(feemockdata));
      this.rsStat = true;
      // this.canOverride = true;
      this.faultRec =[
        {
         errCode:'200924',
         errCat:'Fault',
         errDesc:'Paid date may not be valid',
         errElem:'AcctId.AcctId AcctId.AcctType BilDueDt',
         errElemVal:'88880/L/ 2022026',
         errLoc:'LNBILLMOD',
        }];

    const loanFeeUpdatedResponse: LnFeeModResponse={
      srchMsgRqHdr:request.srchMsgRqHdr,
      acctId:request.acctId,
      acctType:request.acctType,
      rsStat: this.rsStat,
      faultRecInfoArray: this.faultRec,
      lnFeeInfo: this.feedata
    };
    return of(loanFeeUpdatedResponse);
  }
  // get escrow details
    getEscrowDetails(request: LnBilEscrwSrchRequest): Observable<LnBilEscrwSrchResponse>{
      const clone = JSON.parse(JSON.stringify(escrowmockdata));
      return of(clone);
    }
    // save method Escrow edit
    saveEscrowDetails(updaterecord: LnBilEscrwEditSrchRequest): Observable<LnBilEscrwSrchResponse>{
      // return this.http.put("here api path");
      const clone = JSON.parse(JSON.stringify(editescrowmockdata));
      return of(clone);
    }

  }
