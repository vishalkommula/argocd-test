import { DisplayRecordFieldComponent } from './display-record-field.component';

describe('DisplayRecordFieldComponent', () => {
    let sut: DisplayRecordFieldComponent;

    beforeEach(() => {
        sut = new DisplayRecordFieldComponent();
    });

    it('should create', () => {
        expect(sut).toBeTruthy();
    });
});
