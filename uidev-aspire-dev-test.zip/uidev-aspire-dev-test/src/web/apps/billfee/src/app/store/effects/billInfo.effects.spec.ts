import { LnBilSrchResponseModel} from '../../models/loan-bill-search-response.model';
import data from '../../mock-data/loanBillSearchResponse.mock.json';
import * as BillInfoActions from '../actions/billInfo.action';
import { of, throwError } from 'rxjs';
import { ActionsSubject } from '@ngrx/store';
import { BillInfoEffects } from './billInfo.effects';


// bill list mock data
const mockdata: LnBilSrchResponseModel = data;

// Get bill list service method success mock
const billListServiceSuccessMock = {
    getBills: ()=> of(mockdata),
    getBillDetailsbyBillduedt: ()=>of({}),
    updatebilldetails:()=>of(true),
    addbilldetails:()=>of(true),
    deletebilldetails:()=>of(true)
};

// Get bill list service method failure mock
const billListServiceFailureMock = {
    getBills: ()=> throwError('Error - getting the bill list'),
    getBillDetailsbyBillduedt:  ()=> throwError('Error - getting the bill Inq'),
    updatebilldetails:()=>throwError('Error - update bill error'),
    addbilldetails:()=>throwError('Error - add bill error'),
    deletebilldetails:()=>throwError('Error - add bill error')
};

let actions: ActionsSubject;

let effects: BillInfoEffects;

describe('Bill Info Effects Test',()=>{
    beforeEach(()=>{
        actions = new ActionsSubject();
    });


    // get bills info success response
    it('getBillList$ dispatch success action', ()=>{
        effects = new BillInfoEffects(billListServiceSuccessMock as any,actions);
        effects.loadBillListResponse$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.getBillListSuccess({} as any));
        });
            // dispatch the action method
    const action = BillInfoActions.getBillList({request:{} as any});
    actions.next(action);
    });

    // get bills info Error response
    it('getBillList$ dispatch error action', ()=>{
        effects = new BillInfoEffects(billListServiceFailureMock as any,actions);
        effects.loadBillListResponse$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.getBillDetailsError({error:{} as any}));
        });
            // dispatch the action method
    const action = BillInfoActions.getBillList({request:{} as any});
    actions.next(action);
    });

    // Get bill search success response
    it('loadbillinfo$ dispatch success action', ()=>{
        effects = new BillInfoEffects(billListServiceSuccessMock as any,actions);
        effects.loadbillinfo$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.getBillDetailsSuccess({} as any));
        });
            // dispatch the action method
    const action = BillInfoActions.getBillDetails({loanBillInfoRequest:{billduedt: '22/11/2022'} as any});
    actions.next(action);
    });

    // Get bill search failure response
    it('loadBillList$ dispatch failure action', ()=>{
        effects = new BillInfoEffects(billListServiceFailureMock as any,actions);
        effects.loadbillinfo$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.getBillDetailsError({} as any));
        });
            // dispatch the action method
            const action = BillInfoActions.getBillDetails({loanBillInfoRequest:{billduedt: '22/11/2022'} as any});
            actions.next(action);
    });

    // Update bill info success response
    it('updatebillinfo$ dispatch success action', ()=>{
        effects = new BillInfoEffects(billListServiceSuccessMock as any,actions);
        effects.updatebillinfo$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.updateBillDetails({billModRequest:{} as any}));
        });
            // dispatch the action method
    const action = BillInfoActions.updateBillDetails({billModRequest:{} as any});
    actions.next(action);
    });

    // Update bill info Error response
    it('updatebillinfo$ dispatch error action', ()=>{
        effects = new BillInfoEffects(billListServiceFailureMock as any,actions);
        effects.updatebillinfo$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.updateBillDetailsError({billModResponse:true}));
        });
            // dispatch the action method
    const action = BillInfoActions.updateBillDetails({billModRequest:{} as any});
    actions.next(action);
    });

    // Add bill info success response
    it('addbillinfo$ dispatch success action', ()=>{
        effects = new BillInfoEffects(billListServiceSuccessMock as any,actions);
        effects.addbillinfo$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.addBillDetailsSuccess({} as any));
        });
            // dispatch the action method
    const action = BillInfoActions.addBillDetails({billAddRequest:{} as any});
    actions.next(action);
    });

    // add bill info Error response
    it('addbillinfo$ dispatch error action', ()=>{
        effects = new BillInfoEffects(billListServiceFailureMock as any,actions);
        effects.addbillinfo$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.addBillDetailsSuccess({billAddResponse:{} as any}));
        });
            // dispatch the action method
    const action = BillInfoActions.addBillDetails({billAddRequest:{} as any});
    actions.next(action);
    });

    it('deletebilldetail$ dispatch success action', ()=>{
        effects = new BillInfoEffects(billListServiceSuccessMock as any,actions);
        effects.deletebilldetail$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.deleteBillDetailsSuccess({} as any));
        });
            // dispatch the action method
    const action = BillInfoActions.deleteBillDetails({deleteRequest:{} as any});
    actions.next(action);
    });

    it('deletebilldetail$ dispatch error action', ()=>{
        effects = new BillInfoEffects(billListServiceFailureMock as any,actions);
        effects.deletebilldetail$.subscribe((dispatchedaction)=>{
            expect(dispatchedaction).toEqual(BillInfoActions.deleteBillDetailsError({deleteResponse:{} as any}));
        });
            // dispatch the action method
    const action = BillInfoActions.deleteBillDetails({deleteRequest:{} as any});
    actions.next(action);
    });
});
