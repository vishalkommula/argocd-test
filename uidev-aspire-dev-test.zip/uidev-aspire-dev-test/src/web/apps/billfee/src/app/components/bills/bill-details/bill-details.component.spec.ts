import { billFeeValueTypes, PageMode } from '../../../models/bill-fee-enums';
import { GridCellSelectedRecord } from '../../../models/grid-cell-selected-data.model';
import { LnBilEscrwInfoRecModel } from '../../../models/loan-bill-escrow-info-record.model';
import { BillDetailsComponent } from './bill-details.component';

jest.mock('@jha/rui-wc/components/rui-layout/rui-layout-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports',()=>jest.fn());
jest.mock('@jha/rui-wc/components/rui-buttons/rui-buttons-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports', () => jest.fn());
jest.mock('@jha/rui-wc/components/rui-input/rui-input-imports', () => jest.fn());

const storeMock = {
  dispatch: jest.fn(),
  select: jest.fn(()=> ({
    subscribe:jest.fn()
    })),
};


const billInfoActionsMock = {
  billList: jest.fn(),
  billDueDate: jest.fn(),
  billListRetrived:jest.fn(),
  getBillDetails:jest.fn(),
  changePageMode:jest.fn(),
  updateBillInfoModel:jest.fn(),
  updateBillDetails:jest.fn(),
  addBillDetails:jest.fn(),
  deleteBillDetails:jest.fn()
};

const billFeeActionsMock={
  getLoanFees:jest.fn()
};

const billInfoSelectorMock = {
  selectFormState: jest.fn(),
  selectBillinfo: jest.fn(),
  selectBillsearchbybillduedt: jest.fn()
};
describe('BillDetailsComponent', () => {
  let component: BillDetailsComponent;

  beforeEach(()=>{
    component = new BillDetailsComponent(storeMock as any);
    component.billInfoActions = billInfoActionsMock as any;
    component.billInfoSelector=billInfoSelectorMock as any;
    component.billFeeActions=billFeeActionsMock as any;
    component.billFeeValues=billFeeValueTypes;
  });

  it('Component should be created',()=>{
    expect(component).toBeTruthy();
  });

    // editBill method test
    it('editBill call test',()=>{
      component.editBill();
      expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
      expect(billInfoActionsMock.changePageMode).toHaveBeenCalledTimes(1);
  });

  // delete method test
  it('deletebill call test',()=>{
    component.deleteBill();
    expect(component.dialogBoxType).toBe('Delete');
});

  // cancel method test
  it('cancel call test',()=>{
    component.cancelBill();
    expect(component.dialogBoxType).toBe('Cancel');
  });

  it('calTotalRemaining, calculate the total remaining',()=>{
    const model={remBilPrincAmt:100,totalRemaining:0,remBilIntAmt:0,remBilEscrwAmt:0,remBilLateChgAmt:0,remBilOtherChgAmt:0};
    component.calTotalRemaining(model as any);
    expect(model.totalRemaining).toBe(100);
  });

  it('calTotalBilled, calculate the total billed',()=>{
    const model={bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0};
    component.calTotalBilled(model as any);
    expect(model.totalBilled).toBe(1100);
  });

  it('billInfoModelChange, during edit store dispatch the action method to update date in store',()=>{
    const model={bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0,remBilPrincAmt:100,
    totalRemaining:0,remBilIntAmt:0,remBilEscrwAmt:0,remBilLateChgAmt:0,remBilOtherChgAmt:0,bilDueDt:'07/07/2007'};
    component.pageMode=PageMode.Edit;
    component.calTotalBilled=jest.fn();
    component.calTotalRemaining=jest.fn();
    component.billInfoModelChange(model as any);
    // expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
    expect(billInfoActionsMock.updateBillInfoModel).toHaveBeenCalledTimes(1);
    expect(billInfoActionsMock.updateBillInfoModel).toHaveBeenCalledWith({ updateBillInfoModel: model });
  });

  it('saveBill, event executed when user clicks on save button in edit',()=>{
    const model={lnbilInfoRec:{bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0}};
    const loanbillinforeq: any = {
      srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
      acctId: '12',
      acctType: 'A',
      lnBilInfoRec:model.lnbilInfoRec,
      overrideFaultMsg: false,
    };
    component.billDetails=model as any;
    component.pageMode=PageMode.Edit;
    component.saveBill();
    // expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
    expect(billInfoActionsMock.updateBillDetails).toHaveBeenCalledTimes(1);
    expect(billInfoActionsMock.updateBillDetails).toHaveBeenCalledWith({ billModRequest: loanbillinforeq });
  });

  it('saveBill, event executed when user clicks on save button in add',()=>{
    const model={lnbilInfoRec:{bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0,addBilDueDt:'07/07/2022'}};
    const loanbillinforeq: any = {
      srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
      acctId: '12',
      acctType: 'A',
      lnBilInfoRec:model,
      overrideFaultMsg: false,
    };
    component.pageMode=PageMode.Add;
    component.addBillInfoModel=model as any;
    component.saveBill();
    // expect(storeMock.dispatch).toHaveBeenCalledTimes(1);
    expect(billInfoActionsMock.addBillDetails).toHaveBeenCalledTimes(1);
    expect(billInfoActionsMock.addBillDetails).toHaveBeenCalledWith({ billAddRequest: loanbillinforeq });
  });
  it('bindBillInfoModelForAdd, binds the data for addBillInfoModel bill add screen',()=>{
    const model={
      bilPrincAmt: 0,
      remBilPrincAmt: 0,
      bilIntAmt: 0,
      remBilIntAmt: 0,
      bilEscrwAmt: 0,
      remBilEscrwAmt: 0,
      bilLateChgAmt: 0,
      remBilLateChgAmt: 0,
      bilOtherChgAmt: 0,
      remBilOtherChgAmt: 0,
      totalBilled: 0,
      totalRemaining: 0,
      printbillingnotice: false,
      bilDueDt: '',
      bilPaidDt: '',
      nxtPayDt: '',
      addBilDueDt: undefined,
      lnFeeInfoRec: [],
      lnBilEscrwInfoRec: {} as LnBilEscrwInfoRecModel,
    };;
    component.bindBillInfoModelForAdd();
    expect(component.addBillInfoModel).toStrictEqual(model);
  });

  it('overridedialogBoxClose,on click of override button save function called ',()=>{
    const event={detail:billFeeValueTypes.overrideMsg};
    component.saveBill=jest.fn();
    component.overridedialogBoxClose(event as any);
    expect(component.saveBill).toBeCalledTimes(1);
  });

  it('dialogBoxClose on click of delete button, store dispatches deleteBillDetails action',()=>{
    const event={detail:billFeeValueTypes.deleteMsg};
    const model={lnbilInfoRec:{bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0,bilDueDt:'07/07/2022'}};
    component.billDetails=model as any;
    const loanbilldelreq: any = {
      srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
      acctId: '12',
      acctType: 'A',
      billduedate: '2022-07-07',
      overrideFaultMsg: false,
    };
    component.dialogBoxClose(event);
    expect(billInfoActionsMock.deleteBillDetails).toHaveBeenCalledTimes(1);
    expect(billInfoActionsMock.deleteBillDetails).toHaveBeenCalledWith({ deleteRequest: loanbilldelreq });
  });

  it('dialogBoxClose on click of donot save button and page mode is edit store dispatches getBillDetails action',()=>{
    const event={detail:billFeeValueTypes.donotSave};
    const model={lnbilInfoRec:{bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0,bilDueDt:'07/07/2022'}};
    component.billDetails=model as any;
    component.pageMode=PageMode.Edit;
    const loanBillInfoReq: any = {
      srchMsgRqHdr: { jXLogTrackingId: '', instEnv: '1', maxRec: '10', cursor: '123' },
      acctId: '12',
      acctType: 'A',
      bilDueDt: '2022-07-07',
    };
    component.dialogBoxClose(event);
    expect(billInfoActionsMock.getBillDetails).toHaveBeenCalledTimes(1);
    expect(billInfoActionsMock.getBillDetails).toHaveBeenCalledWith({ loanBillInfoRequest: loanBillInfoReq });
  });
  it('dialogBoxClose on click of donot save button and page mode is add store dispatches changePageMode action',()=>{
    const event={detail:billFeeValueTypes.donotSave};
    const model={lnbilInfoRec:{bilPrincAmt:1000,bilIntAmt:0,bilEscrwAmt:100,bilLateChgAmt:0,bilOtherChgAmt:0,totalBilled:0,bilDueDt:'07/07/2022'}};
    component.billDetails=model as any;
    component.pageMode=PageMode.Add;
    component.dialogBoxClose(event);
    expect(billInfoActionsMock.changePageMode).toBeCalledTimes(2); // 1 more time include on dispatch of changepagemode on cancel button click.
  });
  it('ngOnChanges on pageMode change,executing the initialization of bindBillInfoModelForAdd and dispatching getLoanFees',()=>{
    const changes={pageMode:true};
    component.bindBillInfoModelForAdd=jest.fn();
    component.pageMode=PageMode.Add;
    component.ngOnChanges(changes as any);
    expect(component.bindBillInfoModelForAdd).toBeCalledTimes(1);
    expect(billFeeActionsMock.getLoanFees).toBeCalledTimes(1);
  });
  it('selectedFeeRecord update the addBillInfoModel when attached fee is selected',()=>{
    const feeRecord: GridCellSelectedRecord<any>={
      selectedRecord:{data:'1',lnFeeConcatDescription :billFeeValueTypes.lateCharge},
      selectedStatus:true
    };
    const model={lnFeeInfoRec:[],bilLateChgAmt :0,bilOtherChgAmt:0 };
    component.addBillInfoModel=model as any;
    component.selectedFeeRecord(feeRecord as any);
    expect(model.lnFeeInfoRec).toStrictEqual([feeRecord.selectedRecord]);
  });

  it('selectedFeeRecord update the addBillInfoModel when attached fee is selected and selected fee record is late charge',()=>{
    const feeRecord: GridCellSelectedRecord<any>={
      selectedRecord:{data:'1',lnFeeConcatDescription :billFeeValueTypes.lateCharge,lnFeeAmt:2000},
      selectedStatus:true
    };
    const model={lnFeeInfoRec:[],bilLateChgAmt :0,bilOtherChgAmt:0 };
    component.addBillInfoModel=model as any;
    component.selectedFeeRecord(feeRecord as any);
    expect(model.bilLateChgAmt).toStrictEqual(2000);
  });

  it('selectedFeeRecord remove the addBillInfoModel when attached fee is deSelected and selected fee record is late charge',()=>{
    const feeRecord: GridCellSelectedRecord<any>={
      selectedRecord:{data:'1',lnFeeConcatDescription :billFeeValueTypes.lateCharge,lnFeeAmt:2000},
      selectedStatus:false
    };
    const model={lnFeeInfoRec:[feeRecord.selectedRecord],bilLateChgAmt :2000,bilOtherChgAmt:0 };
    component.addBillInfoModel=model as any;
    component.selectedFeeRecord(feeRecord as any);
    expect(model.bilLateChgAmt).toStrictEqual(0);
  });

  it('selectedFeeRecord update the addBillInfoModel when attached fee is selected and selected fee record is other charge',()=>{
    const feeRecord: GridCellSelectedRecord<any>={
      selectedRecord:{data:'1',lnFeeConcatDescription :billFeeValueTypes.otherCharges,lnFeeAmt:2000},
      selectedStatus:true
    };
    const model={lnFeeInfoRec:[],bilLateChgAmt :0,bilOtherChgAmt:0 };
    component.addBillInfoModel=model as any;
    component.selectedFeeRecord(feeRecord as any);
    expect(model.bilOtherChgAmt).toStrictEqual(2000);
  });

  it('selectedFeeRecord remove the addBillInfoModel when attached fee is deSelected and selected fee record is other charge',()=>{
    const feeRecord: GridCellSelectedRecord<any>={
      selectedRecord:{data:'1',lnFeeConcatDescription :billFeeValueTypes.otherCharges,lnFeeAmt:2000},
      selectedStatus:false
    };
    const model={lnFeeInfoRec:[feeRecord.selectedRecord],bilLateChgAmt :2000,bilOtherChgAmt:2000 };
    component.addBillInfoModel=model as any;
    component.selectedFeeRecord(feeRecord as any);
    expect(model.bilOtherChgAmt).toStrictEqual(0);
  });
});
