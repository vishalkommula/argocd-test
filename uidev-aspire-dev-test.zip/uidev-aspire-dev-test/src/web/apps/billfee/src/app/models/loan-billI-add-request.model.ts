import { SearchMessageRequestHeaderModel } from '@uid/uid-models';
import { LnBilInfoRecItemModel } from './loan-bill-info-record-item.model';

export interface LnBilAddRequestModel{
    srchMsgRqHdr: SearchMessageRequestHeaderModel;
    acctId:       string;
    acctType:     string;
    lnBilInfoRec: LnBilInfoRecItemModel;
    overrideFaultMsg: boolean;
};
