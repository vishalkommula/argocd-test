/* eslint-disable @nrwl/nx/enforce-module-boundaries */
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, APP_INITIALIZER } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';
import { ShellEffects } from '@uid/uid-root-store';

// Responsive UI web components
import '@jha/rui-wc/components/rui-icon/rui-icon-imports';
import '@jha/rui-wc/components/rui-notifications/rui-notifications-imports';
import '@jha/rui-wc/components/rui-nav/rui-nav-imports';
import '@jha/rui-wc/components/rui-header/rui-header-imports';
import '@jha/rui-wc/components/rui-layout/rui-layout-imports';
import '@jha/rui-wc/components/rui-tooltip/rui-tooltip-imports';

import '@jha/rui-wc/components/rui-record-detail/rui-record-detail-imports';
import '@jha/rui-wc/components/rui-buttons/rui-buttons-imports';
import '@jha/rui-wc/components/rui-input/rui-input-imports';
import '@jha/rui-wc/components/rui-dialog-box/rui-dialog-box-imports';
import '@jha/rui-wc/components/rui-master-detail/rui-master-detail-imports';
import '@jha/rui-wc/components/rui-tabs/rui-tabs-imports';

// Responsive UI Angular Elements
import { JhaLayoutModule} from '@jha/rui-angular/jha-layout';
import { JhaResponsiveCoreModule } from '@jha/rui-angular/jha-responsive-core';

// Custom components
import { MainNavComponent } from './main-nav/main-nav.component';
import { MainHeaderComponent } from './main-header/main-header.component';
import { rootReducer } from '@uid/uid-root-store';
import '@uid/uid-root-store';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { JhaIndexedDbModule } from '@uid/jha-indexed-db';
import { AppRoutingModule } from './app.routing.module';
import { LoginComponent } from './login/login.component';
import { FormsModule } from '@angular/forms';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { CoreModule } from './core/core.module';
import { EnvironmentService } from './core/services/environment.service';
import { AppInitializerService } from './core/services/app-initializer.service';
import { Router } from '@angular/router';
import { UIDRoutes } from './shared/uid-routes';
import { AuthenticationService } from './core/services/authentication.service';

let storeExtModules: any[] = [];
if (!environment.production) {
  storeExtModules = [
    StoreDevtoolsModule.instrument({
      name: 'Shell Store',
    }),
  ];
}

export function configurationFactory(
  environmentService: EnvironmentService,
  appInitializerService: AppInitializerService,
  authenticationService: AuthenticationService,
  router: Router
): () => Promise<any> {
  return (): Promise<any> => new Promise((resolve) => {
      environmentService.fetchEnvironments()
        .then((env: any) => {
          const fetchedEnvironment = env['environment'];
          appInitializerService.setEnvironment(fetchedEnvironment);
          authenticationService.currentUserSubject.subscribe((user) => {
            if (user) {
              const userSessionFlag = sessionStorage.getItem('UserSessionCreated');
              if (userSessionFlag) {
                const userNameData = sessionStorage.getItem('token');
                if (userNameData) {
                  const userName = JSON.parse(userNameData);
                  authenticationService.populateUserName(userName.access_token);
                  appInitializerService.appInitialized.next(true);
                  resolve(true);
                }
              }
            } else {
              router.navigate([UIDRoutes.login]);
              resolve(true);
            }
          });
        }, () => {
          authenticationService.logout();
          appInitializerService.appInitialized.next(false);
          router.navigate([UIDRoutes.login]);
        });
    });
}

@NgModule({
  declarations: [AppComponent, MainNavComponent, MainHeaderComponent, LoginComponent, HomeComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    JhaLayoutModule,
    JhaResponsiveCoreModule.forRoot(),
    FlexLayoutModule,
    JhaIndexedDbModule,
    StoreModule.forRoot({}),
    StoreModule.forFeature('root', rootReducer),
    EffectsModule.forRoot([ShellEffects]),
    storeExtModules,
    AppRoutingModule,
    FormsModule,
    CoreModule.forRoot()
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: configurationFactory,
      multi: true,
      deps: [EnvironmentService, AppInitializerService, AuthenticationService, Router]
    },
    { provide: 'DB_OPTIONS', useValue: { dbName: 'test-db' }},
    { provide: LocationStrategy, useClass: HashLocationStrategy },
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppModule {}
