import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';
import { UIDRoutes } from '../shared/uid-routes';
import { AuthenticationService } from '../core/services/authentication.service';

@Component({
  selector: 'uid-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {
  public showPassword = false;
  public invalidLogin = false;
  public loggingIn = false;
  public userId = '';
  public password = '';
  private subscriptions: Subscription[] = [];
  private returnUrl;

  constructor(
    private authenticationService: AuthenticationService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || UIDRoutes.home;
  }

  public toggleShowPassword() {
    this.showPassword = !this.showPassword;
  }

  public logIn() {
    sessionStorage.setItem('CurrentUser', this.userId);
    this.loggingIn = true;
    this.subscriptions.push(this.authenticationService.login(this.userId, this.password)
      .pipe(first())
      .subscribe(
        () => {
          this.router.navigate([this.returnUrl]);
        },
        () => {
          this.invalidLogin = true;
          this.loggingIn = false;
        }
      ));
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}
