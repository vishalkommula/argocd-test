import { AuthGuard } from './auth.guard';

describe('AuthGuard', () => {
  it('should create an instance', () => {
      const router = { navigate: jest.fn() };
    expect(new AuthGuard(router as any)).toBeTruthy();
  });
});
