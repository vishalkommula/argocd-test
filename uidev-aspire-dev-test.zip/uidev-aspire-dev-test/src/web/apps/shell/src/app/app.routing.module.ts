import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { UIDRoutes } from './shared/uid-routes';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './guard/auth.guard';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: UIDRoutes.weatherforecastui,
        loadChildren: () => import('weatherforecast/Module').then((m) => m.RemoteEntryModule),
        canActivate: [AuthGuard],
      },
      {
        path: UIDRoutes.stopsholdsui,
        loadChildren: () => import('stopsholds/Module').then((m) => m.HomeModule),
        canActivate: [AuthGuard],
      },
      {
        path: UIDRoutes.billfeeui,
        loadChildren: () => import('billfee/Module').then((m) => m.HomeModule),
        canActivate: [AuthGuard],
      },
      {
        path: UIDRoutes.atmdebitcardinquiryui,
        loadChildren: () => import('atmdebitcardinquiry/Module').then((m) => m.HomeModule),
        canActivate: [AuthGuard],
      },
      {
        path: UIDRoutes.inquirytrackingui,
        loadChildren: () => import('inquirytracking/Module').then((m) => m.HomeModule),
        canActivate: [AuthGuard],
      },
      {
        path: UIDRoutes.accountaccessui,
        loadChildren: () => import('accountaccess/Module').then((m) => m.HomeModule),
        canActivate: [AuthGuard],
      },
      {
        path: UIDRoutes.associateddemandaccountsui,
        loadChildren: () => import('associateddemandaccounts/Module').then((m) => m.HomeModule),
        canActivate: [AuthGuard],
      },
      {
        path: UIDRoutes.home,
        component: HomeComponent,
        canActivate: [AuthGuard],
      },
      {
        path: UIDRoutes.login,
        component: LoginComponent,
      },
      {
        path: '**',
        redirectTo: UIDRoutes.home,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
