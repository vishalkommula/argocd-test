import { TestBed } from '@angular/core/testing';

import { AuthenticationService } from './authentication.service';
import { HttpClient, HttpHandler } from '@angular/common/http';
import { AppInitializerService } from './app-initializer.service';
import { MessageBusService } from './message-bus.service';
import { Router } from '@angular/router';

describe('AuthenticationService', () => {
  let service: AuthenticationService;

  beforeEach(() => {
    const router = { navigate: jest.fn() };
    TestBed.configureTestingModule({
      providers: [
        HttpClient,
        HttpHandler,
        AppInitializerService,
        MessageBusService,
        {
          provide: Router,
          useValue: router
        }
      ]
    });
    service = TestBed.inject(AuthenticationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
