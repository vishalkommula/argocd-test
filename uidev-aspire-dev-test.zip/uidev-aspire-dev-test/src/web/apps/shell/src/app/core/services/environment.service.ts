import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EnvironmentService {

  constructor(
    private httpClient: HttpClient
  ) { }

  public fetchEnvironments = (): Promise<any> => new Promise((resolve, reject) => {
      const env = sessionStorage.getItem('environment');
      if(env) {
        resolve(JSON.parse(env));
      } else{
        this.getEnvironments().subscribe((e) => {
          if(e){
            sessionStorage.setItem('environment', JSON.stringify(e));
            resolve(e);
          }
        }, () => {
          reject();
        });
      }
    });

  public getEnvironments = ((): Observable<any> => {
    const environmentFile = '../../../../assets/environments/environment.json';
    return this.httpClient.get(environmentFile)
      .pipe(map(this.extractData));
  });

  private extractData = ((response: Response | any) => response);
}
