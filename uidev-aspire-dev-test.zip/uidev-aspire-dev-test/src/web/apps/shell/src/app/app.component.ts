import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, Observer, fromEvent, merge } from 'rxjs';
import { map } from 'rxjs/operators';
import * as fromRootStore from '@uid/uid-root-store';

@Component({
  selector: 'uid-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = 'Shell';
  myHeader = 'Hey There';
  doSearch = true;
  isLoggedIn = true;
  public storageTestValue: any;
  public showOfflinePopupNotification: boolean;
  topicList = [
    { name: 'Home', routerLink: '/' },
    { name: 'Stops/Holds', routerLink: '/ui/stopsholds' },
    { name: 'Weather Forecast', routerLink: '/ui/weatherforecast' },
  ];

  constructor(private store: Store) {

      this.showOfflinePopupNotification = false;
      window.addEventListener('offline', () => {
          this.showOfflineBanner();
      });
  }

  ngOnInit(): void {
    let intervalId: any;
    this.store.dispatch(fromRootStore.institutionSelectedAction({ institution: '2021510' }));
    // this.checkOnline().subscribe(isOnline => isOnline? this.showOnlineBanner() : this.showOfflineBanner() );
    this.checkOnline().subscribe(
       (isOnline) => {
         if(isOnline){
           this.showOnlineBanner();
           clearInterval(intervalId);
         }else{
           intervalId = setInterval(() => {
           this.showOfflineBanner();
       }, 20000);
     }
   });
  }

  search(event: any): any {
    console.log(event);
  }

  backButtonClicked($event: any): void {
    console.log($event);
  }

  headerButtonClicked($event: any): void {
    console.log($event);
  }

  // make observable to monitor online/offline status
 checkOnline(){
   return merge<boolean>(
     fromEvent(window, 'offline').pipe(map(()=>false)),
     fromEvent(window, 'online').pipe(map(()=>true)),
     new Observable((sub: Observer<boolean>) => {
       sub.next(navigator.onLine);
       sub.complete();
     })
   );
 }

 showOfflineBanner(){
     const bannerDetail = {
         bannerType: 'information',
         bannerText: 'You are offline',
     };

     const showBannerEvent = new CustomEvent('rui-show-banner-notification', {
         detail: JSON.stringify(bannerDetail),
         bubbles: true,
         cancelable: false,
         composed: true
     });
     dispatchEvent(showBannerEvent);
   }

 showOnlineBanner(){
     const bannerDetail = {
         bannerType: 'success',
         bannerText: 'You are back online!',
     };

     const showBannerEvent = new CustomEvent('rui-show-banner-notification', {
       detail: JSON.stringify(bannerDetail),
       bubbles: true,
       composed: true
     });
     dispatchEvent(showBannerEvent);
   }

}
