import { LoginComponent } from './login.component';
import { ActivatedRoute } from '@angular/router';
import { AuthenticationService } from '../core/services/authentication.service';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let authenticationService: AuthenticationService;
  let route: ActivatedRoute;

  beforeEach(async () => {
    const router = { navigate: jest.fn() };
    component = new LoginComponent(authenticationService, router as any, route);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
