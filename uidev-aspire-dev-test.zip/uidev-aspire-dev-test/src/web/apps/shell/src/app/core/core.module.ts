import { ModuleWithProviders, NgModule } from '@angular/core';
import { EnvironmentService } from './services/environment.service';
import { AppInitializerService } from './services/app-initializer.service';
import { MessageBusService } from './services/message-bus.service';
import { AuthenticationService } from './services/authentication.service';

@NgModule({
  declarations: [],
  imports: [
  ]
})
export class CoreModule {
  public static forRoot(): ModuleWithProviders<CoreModule> {
    return {
      ngModule: CoreModule,
      providers: [EnvironmentService, AppInitializerService, MessageBusService, AuthenticationService]
    };
  }
}
