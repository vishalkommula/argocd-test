export const appConstants = {
  userName: 'User'
};
