import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, Observable, Subscription } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import jwt_decode from 'jwt-decode';
import { Router } from '@angular/router';
import { User } from '../../models/user';
import { AppInitializerService } from './app-initializer.service';
import { MessageBusService } from './message-bus.service';
import { UIDRoutes } from '../../shared/uid-routes';
import { appConstants } from '../app.constants';
import { ExtJwtPayload } from '../../models/ext-jwt-payload';


@Injectable({ providedIn: 'root' })

export class AuthenticationService implements OnDestroy{
  currentUserSubject: BehaviorSubject<User | null>;
  public currentUser: Observable<User | null>;
  environment: object = {};
  private subscriptions: Subscription[] = [];

  constructor(
    private http: HttpClient,
    private appInitializerService: AppInitializerService,
    private messageBusService: MessageBusService,
    private router: Router
  ) {
    const user = sessionStorage.getItem('token');
    if (user) {
      this.currentUserSubject = new BehaviorSubject<User | null>(JSON.parse(user));
    } else {
      this.currentUserSubject = new BehaviorSubject<User | null>(null);
    }

    this.currentUser = this.currentUserSubject.asObservable();

    this.subscriptions.push(this.appInitializerService.environment.subscribe((env: object) => {
      if (env) {
        this.environment = env;
      }
    }));
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  public login = (username: string, password: string): Observable<any> => {
    const encoded: string = encodeURIComponent(password);
    const data: string = 'grant_type=password&username=' + username + '&password=' + encoded + '&client_id=uid-ux&client_secret=' + this.environment['Identity-JHA-UID-UX-Client-Secret'];
    return this.http.post<any>(this.environment['loginBaseUrl'] + 'connect/token', data,
      {
        headers: new HttpHeaders()
          .set('Content-Type', 'application/x-www-form-urlencoded')
      })
      .pipe(map(user => {
        this.setCurrentUser(user);
        return user;
      }));
  };

  private setCurrentUser = (user: User) => {
    if (user && user.access_token) {
      // store user details and jwt token in session storage to keep user logged in between page refreshes
      sessionStorage.setItem('token', JSON.stringify(user));
      if (this.currentUserSubject) {
        this.currentUserSubject.next(user);
        this.populateUserName(user.access_token);
        sessionStorage.setItem('UserSessionCreated', 'true');
        this.appInitializerService.appInitialized.next(true);
        this.router.navigate([UIDRoutes.home]);
      }
    } else {
      console.log('failed');
    }
  };

  public populateUserName = ((token: string): void => {
    const decodedToken = jwt_decode<ExtJwtPayload>(token);
    this.messageBusService.pub('UserName', decodedToken.name);
  });

  public logout(): void {
    sessionStorage.clear();
    this.currentUserSubject.next(null);
    this.messageBusService.pub('UserName', appConstants.userName);
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach(s => s.unsubscribe());
  }
}
