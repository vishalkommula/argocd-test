import { Injectable } from '@angular/core';
import { BehaviorSubject, ReplaySubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MessageBusService {

  event: Record<string, any> = {};

  constructor() { }

  public pub = ((eventName: string, eventData: any, type?: string): void => {
    if (this.event[eventName]) {
      this.event[eventName].next(eventData);
    } else {
      if(type === 'Replay'){
        this.event[eventName] = new ReplaySubject<any>(15, 15000);
      } else{
        this.event[eventName] = new BehaviorSubject<any>(null);
      }
      this.event[eventName].next(eventData);
    }
  });

  public sub = ((eventName: string, type?: string): any => {
    if (this.event[eventName]) {
      return this.event[eventName];
    } else {
      if(type === 'Replay'){
        this.event[eventName] = new ReplaySubject<any>(15, 15000);
      } else{
        this.event[eventName] = new BehaviorSubject<any>(null);
      }
      return this.event[eventName];
    }
  });

  public clean = ((): void => {
    this.event = {};
  });

  public destroy = ((eventName: string): void => {
    this.event[eventName].unsubscribe();
    this.event[eventName] = null;
  });
}
